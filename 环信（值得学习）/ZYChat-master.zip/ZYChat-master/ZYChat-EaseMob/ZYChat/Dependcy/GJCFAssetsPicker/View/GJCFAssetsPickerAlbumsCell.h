//
//  GJAssetsPickerAlbumsCell.h
//  GJAssetsPickerViewController
//
//  Created by ZYVincent QQ:1003081775 on 14-9-10.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJCFAlbums.h"

/*
 * 自定义的相册Cell必须继承这个Cell
 */
@interface GJCFAssetsPickerAlbumsCell : UITableViewCell

/*
 *设定一行的高度
 */
@property (nonatomic,assign)CGFloat cellHeight;

/*
 * 自定义cell重载这个方法来自定义内容，否则就调用系统的
 */
- (void)setAlbums:(GJCFAlbums*)aAlbums;

@end
