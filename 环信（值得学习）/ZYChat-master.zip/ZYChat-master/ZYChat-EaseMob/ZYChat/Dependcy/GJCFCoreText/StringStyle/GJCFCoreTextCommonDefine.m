//
//  GJCFCoreTextCommonDefine.m
//  GJCommonFoundation
//
//  Created by ZYVincent QQ:1003081775 on 14-9-27.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJCFCoreTextCommonDefine.h"

NSString * const kGJCFCoreTextKeywordBackgroundColorAttributedName = @"kGJCFCoreTextKeywordBackgroundColorAttributedName";

NSString * const kGJCFCoreTextKeywordBackgroundCornerRadiusAttributedName = @"kGJCFCoreTextKeywordBackgroundCornerRadiusAttributedName";

@implementation GJCFCoreTextCommonDefine

@end
