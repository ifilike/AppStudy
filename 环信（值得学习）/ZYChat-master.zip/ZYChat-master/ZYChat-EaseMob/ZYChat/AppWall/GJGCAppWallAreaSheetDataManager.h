//
//  GJGCAppWallAreaSheetDataManager.h
//  ZYChat
//
//  Created by ZYVincent on 15/11/26.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "BTActionSheetDataManager.h"

@interface GJGCAppWallAreaSheetDataManager : BTActionSheetDataManager

@end
