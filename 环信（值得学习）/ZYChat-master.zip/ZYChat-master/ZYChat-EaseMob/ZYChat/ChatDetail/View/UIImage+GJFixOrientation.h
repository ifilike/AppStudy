//
//  UIImage+GJFixOrientation.h
//  IMChat
//
//  Created by ZYVincent QQ:1003081775 on 14-9-28.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (GJFixOrientation)
- (UIImage *)fixOrietationWithScale:(CGFloat)scale;
@end
