//
//  GJGCDrfitBottleDetailViewController.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 15/7/1.
//  Copyright (c) 2015年 ZYProSoft.  QQ群:219357847  All rights reserved.
//

#import "GJGCBaseViewController.h"

@interface GJGCDrfitBottleDetailViewController : GJGCBaseViewController

- (instancetype)initWithThumbImage:(UIImage *)aImage withImageUrl:(NSString *)aImageUrl withContentString:(NSString *)aString;

@end
