//
//  GJGCChatFriendTimeCell.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 14-12-26.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatBaseCell.h"

/**
 *  用来展示时间块的cell
 */

@interface GJGCChatFriendTimeCell : GJGCChatBaseCell

@end
