//
//  GJGCChatPostSystemNotiCell.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 14-12-14.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatSystemNotiBaseCell.h"

@interface GJGCChatSystemPostNotiCell : GJGCChatSystemNotiBaseCell

@end
