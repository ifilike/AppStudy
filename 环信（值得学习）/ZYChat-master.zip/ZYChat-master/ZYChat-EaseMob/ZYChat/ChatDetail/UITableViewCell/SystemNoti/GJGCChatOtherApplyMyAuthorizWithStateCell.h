//
//  GJGCChatOtherApplyMyAuthorizWithStateCell.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 14-11-5.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatAuthorizAskCell.h"

@interface GJGCChatOtherApplyMyAuthorizWithStateCell : GJGCChatAuthorizAskCell

@end
