> Swift 興趣交流群：`305014012`，307017261（已滿）
> [Swift 開發者社區](http://swiftist.org)

<!-- -->
> 如果你覺得這個項目不錯，請[點擊Star一下](https://github.com/numbbbbb/the-swift-programming-language-in-chinese)，您的支持我們最大的動力。

# The Swift Programming Language 中文版

###這一次，讓中國和世界同步

現在是6月12日凌晨4:38，我用了整整一晚上的時間來進行最後的校對，終於可以在12日拿出一個可以發佈的版本。

9天時間，1317個 Star，310個 Fork，超過30人參與翻譯和校對工作，項目最高排名GitHub總榜第4。

設想過很多遍校對完成時的場景，仰天大笑還是淚流滿面？真正到了這一刻才發現，疲倦已經不允許我有任何情緒。

說實話，剛開始發起項目的時候完全沒想到會發展成今天這樣，我一度計劃自己一個人翻譯完整本書。萬萬沒想到，會有這麼多的人願意加入並貢獻出自己的力量。

coverxit發給我最後一份文檔的時候說，我要去背單詞了，我問他，週末要考六級？他說是的。

pp-prog告訴我，這幾天太累了，校對到一半睡著了，醒來又繼續做。2點17分，發給我校對完成的文檔。

lifedim說他平時12點就會睡，1點47分，發給我校對後的文檔。

團隊裡每個人都有自己的事情，上班、上學、創業，但是我們只用了9天就完成整本書的翻譯。我不知道大家付出了多少，犧牲了多少，但是我知道，他們的付出必將被這些文字記錄下來，即使再過10年，20年，依然熠熠生輝，永不被人遺忘。

全體人員名單（排名不分先後）：

- [numbbbbb](https://github.com/numbbbbb)
- [stanzhai](https://github.com/stanzhai)
- [coverxit](https://github.com/coverxit)
- [wh1100717](https://github.com/wh1100717)
- [TimothyYe](https://github.com/TimothyYe)
- [honghaoz](https://github.com/honghaoz)
- [lyuka](https://github.com/lyuka)
- [JaySurplus](https://github.com/JaySurplus)
- [Hawstein](https://github.com/Hawstein)
- [geek5nan](https://github.com/geek5nan)
- [yankuangshi](https://github.com/yankuangshi)
- [xielingwang](https://github.com/xielingwang)
- [yulingtianxia](https://github.com/yulingtianxia)
- [twlkyao](https://github.com/twlkyao)
- [dabing1022](https://github.com/dabing1022)
- [vclwei](https://github.com/vclwei)
- [fd5788](https://github.com/fd5788)
- [siemenliu](https://github.com/siemenliu)
- [youkugems](https://github.com/youkugems)
- [haolloyin](https://github.com/haolloyin)
- [wxstars](https://github.com/wxstars)
- [IceskYsl](https://github.com/IceskYsl)
- [sg552](https://github.com/sg552)
- [superkam](https://github.com/superkam)
- [zac1st1k](https://github.com/zac1st1k)
- [bzsy](https://github.com/bzsy)
- [pyanfield](https://github.com/pyanfield)
- [ericzyh](https://github.com/ericzyh)
- [peiyucn](https://github.com/peiyucn)
- [sunfiled](https://github.com/sunfiled)
- [lzw120](https://github.com/lzw120)
- [viztor](https://github.com/viztor)
- [wongzigii](https://github.com/wongzigii)
- [umcsdon](https://github.com/umcsdon)
- [zq54zquan](https://github.com/zq54zquan)
- [xiehurricane](https://github.com/xiehurricane)
- [Jasonbroker](https://github.com/Jasonbroker)
- [tualatrix](https://github.com/tualatrix)
- [pp-prog](https://github.com/pp-prog)
- [088haizi](https://github.com/088haizi)
- [baocaixiong](https://github.com/baocaixiong)
- [yeahdongcn](https://github.com/yeahdongcn)
- [shinyzhu](https://github.com/shinyzhu)
- [lslxdx](https://github.com/lslxdx)
- [Evilcome](https://github.com/Evilcome)
- [zqp](https://github.com/zqp)
- [NicePiao](https://github.com/NicePiao)
- [LunaticM](https://github.com/LunaticM)
- [menlongsheng](https://github.com/menlongsheng)
- [lifedim](https://github.com/lifedim)
- [happyming](https://github.com/happyming)
- [bruce0505](https://github.com/bruce0505)
- [Lin-H](https://github.com/Lin-H)
- [takalard](https://github.com/takalard)
- [dabing1022](https://github.com/dabing1022)
- [marsprince](https://github.com/marsprince)
