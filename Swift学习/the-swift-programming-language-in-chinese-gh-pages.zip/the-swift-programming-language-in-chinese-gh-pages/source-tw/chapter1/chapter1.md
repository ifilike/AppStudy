# 歡迎使用 Swift

在本章中您將瞭解 Swift 的特性和開發歷史，並對 Swift 有一個初步的瞭解。

