//
//  CustomCollectionViewCell.m
//  WidgetTest
//
//  Created by maqinjun on 15/10/19.
//  Copyright © 2015年 maqj. All rights reserved.
//

#import "CustomCollectionViewCell.h"

@implementation CustomCollectionViewCell

@end
