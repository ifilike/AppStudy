//
//  CustomCollectionViewCell.h
//  WidgetTest
//
//  Created by maqinjun on 15/10/19.
//  Copyright © 2015年 maqj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *itemImage;

@end
