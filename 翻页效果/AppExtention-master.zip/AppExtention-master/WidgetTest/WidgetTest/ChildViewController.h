//
//  ChildViewController.h
//  WidgetTest
//
//  Created by maqj on 15/9/19.
//  Copyright (c) 2015年 maqj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildViewController : UIViewController
@property (nonatomic)   NSString *name;

@end
