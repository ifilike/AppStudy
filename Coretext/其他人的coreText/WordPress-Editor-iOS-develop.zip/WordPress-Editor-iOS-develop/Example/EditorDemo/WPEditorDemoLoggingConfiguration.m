#import "WPEditorDemoLoggingConfiguration.h"

const DDLogLevel ddLogLevel = DDLogLevelError;