#import <Foundation/Foundation.h>

extern const DDLogLevel ddLogLevel;
