//
//  main.m
//  EditorDemo
//
//  Created by Matt Bumgardner on 6/3/14.
//  Copyright (c) 2014 Automattic, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([WPAppDelegate class]));
    }
}
