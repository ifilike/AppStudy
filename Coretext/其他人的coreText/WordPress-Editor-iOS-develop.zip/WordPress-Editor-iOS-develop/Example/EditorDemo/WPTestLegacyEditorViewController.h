#import <UIKit/UIKit.h>
#import <WordPressEditor/WPLegacyEditorViewController.h>

@interface WPTestLegacyEditorViewController : WPLegacyEditorViewController

@end
