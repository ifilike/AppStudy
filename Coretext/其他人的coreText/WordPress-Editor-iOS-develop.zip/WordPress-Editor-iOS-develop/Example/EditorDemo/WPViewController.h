#import <UIKit/UIKit.h>
#import <WordPressEditor/WPEditorViewController.h>

@interface WPViewController : WPEditorViewController <WPEditorViewControllerDelegate>

@end
