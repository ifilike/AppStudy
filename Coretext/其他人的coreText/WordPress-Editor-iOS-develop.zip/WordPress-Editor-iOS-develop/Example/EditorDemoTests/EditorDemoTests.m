//
//  EditorDemoTests.m
//  EditorDemoTests
//
//  Created by Matt Bumgardner on 6/3/14.
//  Copyright (c) 2014 Automattic, Inc. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface EditorDemoTests : XCTestCase

@end

@implementation EditorDemoTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

@end
