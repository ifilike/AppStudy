#import "WPEditorLoggingConfiguration.h"

const DDLogLevel kEditorLogLevel = DDLogLevelError;