//
//  HomeViewCell.h
//  XZMultiFunctionCell
//
//  Created by xiazer on 15/1/5.
//  Copyright (c) 2015年 xiazer. All rights reserved.
//

#import "MultiFunctionCell.h"

@interface HomeViewCell : MultiFunctionCell

- (void)configCell:(id)model index:(NSIndexPath*)index;

@end
