//
//  main.m
//  Tan_PanTableViewCell
//
//  Created by PX_Mac on 16/3/27.
//  Copyright © 2016年 PX_Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
