//
//  AppDelegate.h
//  Tan_PanTableViewCell
//
//  Created by PX_Mac on 16/3/27.
//  Copyright © 2016年 PX_Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

