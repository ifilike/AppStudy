## Tan_UITableViewCellLeftSwipe： 自定义UITableViewCell， 实现左滑动多菜单功能，先上图：

![image](https://github.com/xiaotanit/Tan_UITableViewCellLeftSwipe/blob/master/swipeDelegate.gif)

#### 工作空间里面有三个工程项目， 分别使用：
- 1、自定义UITableViewCell + UISwipeGestureRecognizer + 代理 来实现；
- 2、自定义UITableViewCell + UIPanGestureRecognizer + 代理 来实现；
- 3、自定义UITableViewCell + UISwipeGestureRecognizer + block 来实现
![image](https://github.com/xiaotanit/Tan_UITableViewCellLeftSwipe/blob/master/swipeBlock.gif)


