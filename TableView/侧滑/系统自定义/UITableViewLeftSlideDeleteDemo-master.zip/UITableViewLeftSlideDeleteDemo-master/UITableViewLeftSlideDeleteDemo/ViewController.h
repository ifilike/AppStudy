//
//  ViewController.h
//  UITableViewLeftSlideDeleteDemo
//
//  Created by admin on 16/3/29.
//  Copyright © 2016年 AlezJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

