//
//  CLLockVC.m
//  CoreLock
//
//  Created by 成林 on 15/4/21.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "CLLockVC.h"
#import "CoreLockConst.h"
//#import "CoreArchive.h"
#import "CLLockLabel.h"
#import "CLLockNavVC.h"
#import "CLLockView.h"
#import "ENavigationViewController.h"
#import "ETabBarViewController.h"
#import "SLAlertView.h"
#import "LogInViewController.h"
@interface CLLockVC ()
/** 操作成功：密码设置成功、密码验证成功 */
@property (nonatomic,copy) void (^successBlock)(CLLockVC *lockVC,NSString *pwd);

@property (nonatomic,copy) void (^forgetPwdBlock)();

@property (weak, nonatomic) IBOutlet CLLockLabel *label;

@property (nonatomic,copy) NSString *msg;

@property (weak, nonatomic) IBOutlet CLLockView *lockView;

@property (nonatomic,weak) UIViewController *vc;

@property (nonatomic,strong) UIBarButtonItem *resetItem;


@property (nonatomic,copy) NSString *modifyCurrentTitle;
@property (nonatomic,assign) int often;

@property (weak, nonatomic) IBOutlet UIView *actionView;

@property (weak, nonatomic) IBOutlet UIButton *modifyBtn;



/** 直接进入修改页面的 */
@property (nonatomic,assign) BOOL isDirectModify;



@end

@implementation CLLockVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
 
#pragma mark --修改是否是最小化的状态
  //  [[NSUserDefaults standardUserDefaults] setObject:@" " forKey:@"backapp"];
    //控制器准备
    [self vcPrepare];
    
    //数据传输
    [self dataTransfer];
    
    //事件
    [self event];
    
}
-(void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:YES];
    self.often = 0;
}
/*
 *  事件
 */
-(void)event{
    
    
    /*
     *  设置密码
     */
    
    /** 开始输入：第一次 */
    self.lockView.setPWBeginBlock = ^(){
        
        [self.label showNormalMsg:CoreLockPWDTitleFirst];
    };
    
    /** 开始输入：确认 */
    self.lockView.setPWConfirmlock = ^(){
        
        [self.label showNormalMsg:CoreLockPWDTitleConfirm];
    };
    
    
    /** 密码长度不够 */
    self.lockView.setPWSErrorLengthTooShortBlock = ^(NSUInteger currentCount){
        
        [self.label showWarnMsg:[NSString stringWithFormat:@"请连接至少%@个点",@(CoreLockMinItemCount)]];
        [self.label setTextColor:[UIColor whiteColor]];
    };
    
    /** 两次密码不一致 */
    self.lockView.setPWSErrorTwiceDiffBlock = ^(NSString *pwd1,NSString *pwdNow){
        
        [self.label showWarnMsg:CoreLockPWDDiffTitle];
        [self.label setTextColor:[UIColor whiteColor]];
        self.navigationItem.rightBarButtonItem = self.resetItem;
    };
    
    /** 第一次输入密码：正确 */
    self.lockView.setPWFirstRightBlock = ^(){
        
        [self.label showNormalMsg:CoreLockPWDTitleConfirm];
    };
    
    /** 再次输入密码一致 */
    self.lockView.setPWTwiceSameBlock = ^(NSString *pwd){
        
        [self.label showNormalMsg:CoreLockPWSuccessTitle];
        NSLog(@"----type:%d",_type);
#pragma mark ----- 储存手势密码
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        NSString *user_phone = [userdefault objectForKey:USER_PHONE];
        NSString *hand_password = [userdefault objectForKey:HAND_PASSWORD ];
        NSString *token = [userdefault objectForKey:TOKEN];
        NSString *user_id = [userdefault objectForKey:USER_ID];
        if (_type == CoreLockTypeSetPwd) {
//            NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"hand_password\":\"%@\",\"token\":\"%@\"}",user_phone,pwd,token];
//            [IKHttpTool postWithURL:@"setHandPassword" params:@{@"json":param} success:^(id json) {
                [userdefault setObject:pwd forKey:HAND_PASSWORD];
                [SLAlertView showAlertWithStatusString:@"手势密码设置成功"];
              //  [MBProgressHUD showSuccess:@"手势密码设置成功"];
//            } failure:^(NSError *error) {
//                
//            }];
        }else if(_type == CoreLockTypeModifyPwd){
        
//            NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"hand_password\":\"%@\",\"new_handPassword\":\"%@\",\"token\":\"%@\"}",user_phone,hand_password,pwd,token];
//            [IKHttpTool postWithURL:@"changeHandword" params:@{@"json":param} success:^(id json) {
                [userdefault setObject:pwd forKey:HAND_PASSWORD];
                [SLAlertView showAlertWithStatusString:@"手势密码修改成功"];
               // [MBProgressHUD showSuccess:@"手势密码修改成功"];
//            } failure:^(NSError *error) {
//            }];
//            
        }
       
        //存储密码
        // [CoreArchive setStr:pwd key:CoreLockPWDKey];
        NSLog(@"-------pwd%@",pwd);
        //禁用交互
        self.view.userInteractionEnabled = NO;
        
        if(_successBlock != nil) _successBlock(self,pwd);
        
        if(CoreLockTypeModifyPwd == _type){
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(.5f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self.navigationController popViewControllerAnimated:YES];
            });
        }
    };
    
    
    
    /*
     *  验证密码
     */
    
    /** 开始 */
    self.lockView.verifyPWBeginBlock = ^(){
        
        [self.label showNormalMsg:CoreLockVerifyNormalTitle];
    };
    
    /** 验证 */
    self.lockView.verifyPwdBlock = ^(NSString *pwd){
#pragma mark -- 取出本地密码
        //取出本地密码
        // NSString *pwdLocal = [CoreArchive strForKey:CoreLockPWDKey];
        //        NSLog(@"--------------pwdLocal%@",pwdLocal);
        NSString *pwdLocal = [[NSUserDefaults standardUserDefaults] objectForKey:HAND_PASSWORD];
        
        BOOL res = [pwdLocal isEqualToString:pwd];
        
        if(res){//密码一致
            
            [self.label showNormalMsg:CoreLockVerifySuccesslTitle];
            
            if(CoreLockTypeVeryfiPwd == _type){
                
                //禁用交互
                self.view.userInteractionEnabled = NO;
                
            }else if (CoreLockTypeModifyPwd == _type){//修改密码
                
                [self.label showNormalMsg:CoreLockPWDTitleFirst];
                
                self.modifyCurrentTitle = CoreLockPWDTitleFirst;
            }
            
            if(CoreLockTypeVeryfiPwd == _type) {
                if(_successBlock != nil) _successBlock(self,pwd);
            }
            
        }else{//密码不一致
            
            NSLog(@" aaaaaaa");
            [self.label showWarnMsg:CoreLockVerifyErrorPwdTitle];
            [self.label setTextColor:[UIColor whiteColor]];
            self.often++;
            if (self.often==5) {
                void(^block)() = ^(){
                    [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];
                };
                NSLog(@"----绘制次数：5%d",self.often);
                [SLAlertView showAlertWithStatusString:@"您的绘制次数已达上限，请重新登录" withButtonTitles:@[@"返回登录"] andBlocks:@[block]];
            }
        }
        return res;
    };
    
    /*
     *  修改
     */
    
    /** 开始 */
    self.lockView.modifyPwdBlock =^(){
        
        [self.label showNormalMsg:self.modifyCurrentTitle];
    };
    
    
}






/*
 *  数据传输
 */
-(void)dataTransfer{
    
    [self.label showNormalMsg:self.msg];
    
    //传递类型
    self.lockView.type = self.type;
}







/*
 *  控制器准备
 */
-(void)vcPrepare{
    
    UIImage *image = [UIImage imageNamed:@"shoushiback"];
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    UIImageView *backView = [[UIImageView alloc]init];
    backView.image = [UIImage imageNamed:@"shoushiback.jpg"];
    backView.frame = CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT);
    
    //self.view.backgroundColor = [UIColor purpleColor];
    //初始情况隐藏
    self.navigationItem.rightBarButtonItem = nil;
#warning mark -- 修改过
    NSString *backApp = [[NSUserDefaults standardUserDefaults]objectForKey:@"backapp"];
    if (![backApp isEqualToString:@"back"]) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back"] style:(UIBarButtonItemStyleDone) target:self action:@selector(back:)];    }
    //self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
    
    
//    if (self.judge==1) {
//        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"忽略" style:(UIBarButtonItemStyleDone) target:self action:@selector(overLook:)];
//    }
    //默认标题
    self.modifyCurrentTitle = CoreLockModifyNormalTitle;
    
    if(CoreLockTypeModifyPwd == _type ) {
        
        _actionView.hidden = YES;
        
        [_actionView removeFromSuperview];
        
        if(_isDirectModify) return;
        
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"关闭" style:UIBarButtonItemStylePlain target:self action:@selector(dismiss)];
    }
    if (CoreLockTypeSetPwd == _type) {
        
            [_modifyBtn removeFromSuperview];
            _actionView.hidden = YES;
            
            [_actionView removeFromSuperview];
          //  if(_isDirectModify) return;
            NSString *lockVolue = [[NSUserDefaults standardUserDefaults] objectForKey:@"lock"];
            if ([lockVolue intValue]==100) {
                NSLog(@"----100lock:%@",lockVolue);
                self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"忽略" style:(UIBarButtonItemStyleDone) target:self action:@selector(overLook:)];

            }else{
                self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"back"] style:(UIBarButtonItemStyleDone) target:self action:@selector(back:)];

                NSLog(@"----lock:%@",lockVolue);
            }
       
        }
   
}
#pragma mark -- barbuttonItem 的事件
-(void)overLook:(UIBarButtonItem *)sender{
    
    [self login];
    [[NSUserDefaults standardUserDefaults] setObject:@"200" forKey:@"lock"];
    
}
-(void)login{
    
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *phone = [userDefault objectForKey:USER_PHONE];
    NSString *password = [userDefault objectForKey:PASSWORD];
   // NSString *repre = [userDefault objectForKey:@""];
    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"password\":\"%@\"}",phone,password];
    [SLAlertView showAlertWithMessageString:@"正在登录..."];
   // [MBProgressHUD showMessage:@"正在登陆..."];
    [IKHttpTool postWithURL:@"login" params:@{@"json":str} success:^(id json) {
        
        NSLog(@"login-----:%@",json);
        [SLAlertView hide];
//        [MBProgressHUD hideHUD];
        
        [userDefault setObject:phone forKey:@"user_phone"];
        [userDefault setObject:password forKey:@"password"];
        [userDefault setObject:json[@"data"][@"user_id"] forKey:USER_ID];
        [userDefault setObject:json[@"data"][@"token"] forKey:TOKEN];
//        NSString *handword = [NSString stringWithFormat:@"%@",json[@"data"][@"hand_password"]];
//        NSLog(@"---hand:%@ %ld",handword,(unsigned long)handword.length);
//        if(handword.length<4||[handword intValue]<100){//存手势密码
//            [userDefault setObject:@"1" forKey:HAND_PASSWORD];
//        }else {
//            [userDefault setObject:handword forKey:HAND_PASSWORD];
//        }
        NSString *paypassword = [NSString stringWithFormat:@"%@",json[@"data"][@"paypassword"]];
        if([paypassword isEqualToString:@"<null>"]){
            [userDefault setObject:@"1" forKey:PAYPASSWORD];
        }else{
            NSLog(@"------payPassword:%@",json[@"data"][@"paypassword"]);
            [userDefault setObject:json[@"data"][@"paypassword"] forKey:PAYPASSWORD];
        }
        // [UIApplication sharedApplication].keyWindow.rootViewController = [[ETabBarViewController alloc]init];
        [SLAlertView showAlertWithStatusString:@"登陆成功"];
        //[self.prompt showPromptWithTitle:@"tishi" message:@"登录成功" buttonleft:nil buttonright:nil];
        [self dismiss:0.2];
        UIWindow *winow = [UIApplication sharedApplication].keyWindow;
        winow.rootViewController = [[ETabBarViewController alloc]init];

    } failure:^(NSError *error) {
        [SLAlertView hide];
//        [MBProgressHUD hideHUD];
        NSLog(@"--------error logIN:%@",error);
    }];

}
-(void)back:(UIBarButtonItem *)sender{
    
    [self dismiss:0.5];
}
-(void)dismiss{
    [self dismiss:0.5];
}



/*
 *  密码重设
 */
-(void)setPwdReset{
    
    [self.label showNormalMsg:CoreLockPWDTitleFirst];
    
    //隐藏
    self.navigationItem.rightBarButtonItem = nil;
    
    //通知视图重设
    [self.lockView resetPwd];
}


/*
 *  忘记密码
 */
-(void)forgetPwd{
    NSLog(@"我把密码给忘了======");
    
}

/*
 *  修改密码
 */
-(void)modiftyPwd{
    
    NSLog(@"修改密码");
}




/*
 *  是否有本地密码缓存？即用户是否设置过初始密码？
 */
+(BOOL)hasPwd{
#pragma mark ---  判断是否有本地缓存
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *gesture = [userdefault objectForKey:HAND_PASSWORD];
    //  NSString *pwd = [CoreArchive strForKey:CoreLockPWDKey];
    //  NSLog(@"------pwd:%@sec",pwd);
    if (gesture.length<4) {
        //[SLAlertView showAlertWithStatusString:@"没设置过密码"];
        //[MBProgressHUD showError:@"没设置过密码"];
    }
    return gesture.length>3;
}




/*
 *  展示设置密码控制器
 */
+(instancetype)showSettingLockVCInVC:(UIViewController *)vc successBlock:(void(^)(CLLockVC *lockVC,NSString *pwd))successBlock{
    
    CLLockVC *lockVC = [self lockVC:vc];
    
    lockVC.title = @"设置密码";
    
    //设置类型
    lockVC.type = CoreLockTypeSetPwd;
    
    //保存block
    lockVC.successBlock = successBlock;
    
    return lockVC;
}




/*
 *  展示验证密码输入框
 */
+(instancetype)showVerifyLockVCInVC:(UIViewController *)vc forgetPwdBlock:(void(^)())forgetPwdBlock successBlock:(void(^)(CLLockVC *lockVC, NSString *pwd))successBlock{
    
    
    CLLockVC *lockVC = [self lockVC:vc];
    
    lockVC.title = @"手势解锁";
    
    //设置类型
    lockVC.type = CoreLockTypeVeryfiPwd;
    
    //保存block
    lockVC.successBlock = successBlock;
    lockVC.forgetPwdBlock = forgetPwdBlock;
    
    return lockVC;
}




/*
 *  展示验证密码输入框
 */
+(instancetype)showModifyLockVCInVC:(UIViewController *)vc successBlock:(void(^)(CLLockVC *lockVC, NSString *pwd))successBlock{
    
    CLLockVC *lockVC = [self lockVC:vc];
    
    lockVC.title = @"修改密码";
    
    //设置类型
    lockVC.type = CoreLockTypeModifyPwd;
    
    //记录
    lockVC.successBlock = successBlock;
    
    return lockVC;
}





+(instancetype)lockVC:(UIViewController *)vc{
    
    CLLockVC *lockVC = [[CLLockVC alloc] init];
    
    lockVC.vc = vc;
    
    ENavigationViewController *nava = [[ENavigationViewController alloc]initWithRootViewController:lockVC];;
    nava.navigationBarHidden = YES;
    CLLockNavVC *navVC = [[CLLockNavVC alloc] initWithRootViewController:lockVC];
    navVC.navigationBar.backgroundColor = [UIColor clearColor];
    [vc presentViewController:navVC animated:YES completion:nil];
    
    return lockVC;
}



-(void)setType:(CoreLockType)type{
    
    _type = type;
    
    //根据type自动调整label文字
    [self labelWithType];
}



/*
 *  根据type自动调整label文字
 */
-(void)labelWithType{
    
    if(CoreLockTypeSetPwd == _type){//设置密码
        
        self.msg = CoreLockPWDTitleFirst;
        
    }else if (CoreLockTypeVeryfiPwd == _type){//验证密码
        
        self.msg = CoreLockVerifyNormalTitle;
        
    }else if (CoreLockTypeModifyPwd == _type){//修改密码
        
        self.msg = CoreLockModifyNormalTitle;
    }
}




/*
 *  消失
 */
-(void)dismiss:(NSTimeInterval)interval{
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(interval * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}


/*
 *  重置
 */
-(UIBarButtonItem *)resetItem{
    
    if(_resetItem == nil){
        //添加右按钮
        _resetItem= [[UIBarButtonItem alloc] initWithTitle:@"重设" style:UIBarButtonItemStylePlain target:self action:@selector(setPwdReset)];
    }
    
    return _resetItem;
}


- (IBAction)forgetPwdAction:(id)sender {

    void(^block)() = ^(){    
};
    void(^block2)() = ^(){
        [self dismiss:0.2];
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setObject:@"" forKey:PASSWORD];
        [userDefault setObject:@"" forKey:USER_ID];
        [userDefault setObject:@"" forKey:TOKEN];
        [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];
    };
    [SLAlertView showAlertWithStatusString:@"您需要重新登录" withButtonTitles:@[@"取消",@"重新登录"] andBlocks:@[block,block2]];
    NSLog(@"忘记密码--------");
    NSLog(@"-----===");
    if(_forgetPwdBlock != nil) _forgetPwdBlock();
}


- (IBAction)modifyPwdAction:(id)sender {
    
    CLLockVC *lockVC = [[CLLockVC alloc] init];
    
    lockVC.title = @"修改密码";
    
    lockVC.isDirectModify = YES;
    
    //设置类型
    lockVC.type = CoreLockTypeModifyPwd;
    
    [self.navigationController pushViewController:lockVC animated:YES];
}






@end
