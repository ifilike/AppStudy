//
//  ERenYiPuHeader.h
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#ifndef ERenYiPuHeader_h
#define ERenYiPuHeader_h

#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define IWColor(x,y,z) [UIColor colorWithRed:x/255.0 green:y/255.0 blue:z/255.0 alpha:1]

#define SIZE [UIScreen mainScreen].bounds.size
#define WINSIZEHEIGHT [UIScreen mainScreen].bounds.size.height
#define WINSIZEWIDTH [UIScreen mainScreen].bounds.size.width

//邮天下的三种颜色
//红
#define YRedColor [UIColor colorWithHexString:@"ff6054"]
//黑
#define YBlackColor [UIColor colorWithHexString:@"333333"]
//灰
#define YGrayColor [UIColor colorWithHexString:@"666666"]
#define YShawGrayColor [UIColor colorWithHexString:@"999999"]//浅灰
#define YBackGrayColor [UIColor colorWithHexString:@"e9e5e5"]//背景的灰色
//设置字体大小
#define YFont(x)  [UIFont fontWithName:@"Helvetica Neue" size:x];
//设置字体大小
#define YBFont(x) [UIFont boldSystemFontOfSize:x];

//新闻滚动速度
#define kSpeed 0.05

//截取小数点后两位
#define yTwoPointFloat(str) floor([str floatValue]*100)/100

#define yTwoPointDouble(str) floor([str doubleValue]*100)/100

//定义菜单栏的高度
#define YMenuHeight [UIScreen mainScreen].bounds.size.width / 10

//数据请求相关
//check_code
#define CHECKCODE @"db974238714ca8de634a7ce1d083a14f"

//192.168.0.19   115.28.143.129   ERenYiPu 120.27.138.247    多服务器: 120.27.184.210  121.41.46.161
#define ebaseURL @"http://120.27.184.210:8089/EREP/index.php/Api/"

//#define ebaseURL @"http://120.27.138.247:8089/EREP/index.php/Api/"

//图片路径
#define IMGURL @"http://120.27.184.210:8089/EREP/upload/imgs/"
//头像路径
#define HEADURL @"http://120.27.184.210:8089/EREP/upload/hends/"
#define USER_PHONE @"user_phone"
#define PASSWORD @"password"
#define USER_ID @"user_id"
#define PAYPASSWORD  @"paypassword"
#define HAND_PASSWORD @"hand_password"
#define TOKEN @"token"
//手势状态
#define HANDSTATUS @"handstatus" /*1表示开启 0表示关闭*/

#endif /* ERenYiPuHeader_h */
