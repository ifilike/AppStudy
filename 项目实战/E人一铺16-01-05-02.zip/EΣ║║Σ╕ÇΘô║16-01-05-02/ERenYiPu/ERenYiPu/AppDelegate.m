//
//  AppDelegate.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AppDelegate.h"
#import "EControllerTool.h"
#import "CLLockVC.h"
#import "ETabBarViewController.h"
#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"
#import "LogInViewController.h"
#import "SLAlertView.h"

@interface AppDelegate ()
{
    NSString *downloadUrl;
}
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self getVersion];
    
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    [EControllerTool chooseRootViewController];
    //友盟
    [UMSocialData setAppKey:@"5652bc2567e58e75e0003108"];
    //微信
    [UMSocialWechatHandler setWXAppId:@"wx1f948662080fe1aa" appSecret:@"9dbea548bbe68c696f371f154984bfb0" url:@"http://www.erenepu.com/appdown/index.html"];
   // [UMSocialData defaultData].extConfig.wxMessageType = UMSocialWXMessageTypeImage;
    //
    //[UMSocialData defaultData].extConfig.qqData.qqMessageType = UMSocialQQMessageTypeImage;

    [UMSocialQQHandler setQQWithAppId:@"1104921719" appKey:@"KBP4Jx98ng3qAJgj" url:@"http://www.erenepu.com/appdown/index.html"];
//    [UMSocialData defaultData].extConfig.qqData.qqMessageType = UMSocialQQMessageTypeImage;
//    BOOL result = [UMSocialSnsService handleOpenURL:[NSURL URLWithString:@"http://www.umeng.com/social"]];
//    if (result == FALSE) {
//        [UMSocialWechatHandler setWXAppId:@"5652bc2567e58e75e0003108" appSecret:@"d4624c36b6795d1d99dcf0547af5443d" url:@"http://www.umeng.com/social"];
//
//        //调用其他SDK，例如支付宝SDK等
//    }
//    return result;
    
   return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    NSLog(@"这是------");
    NSString *handpassword = [[NSUserDefaults standardUserDefaults]objectForKey:HAND_PASSWORD];
    NSLog(@"----passord:%@",handpassword);
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    [userdefault setObject:@"back" forKey:@"backapp"];

    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    NSLog(@"这是-----------二");
   


//    [CLLockVC showVerifyLockVCInVC:self forgetPwdBlock:^{
//        NSLog(@"忘记密码");
//    } successBlock:^(CLLockVC *lockVC, NSString *pwd) {
//        NSLog(@"密码正确");
//        [lockVC dismiss:1.0f];
//    }];
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    NSLog(@"这是-----------三");
    NSString *token = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    if (token.length>10) {
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        NSString *handpassword = [userdefault objectForKey:HAND_PASSWORD];
        NSString *handstatus = [userdefault objectForKey:HANDSTATUS];
        if (handpassword.length>3&&[handstatus intValue]==1) {
            [CLLockVC showVerifyLockVCInVC:self.window.rootViewController forgetPwdBlock:^{
                
                
            } successBlock:^(CLLockVC *lockVC, NSString *pwd) {
                NSLog(@"密码正确appdelegate");
                NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                [userdefault setObject:@" " forKey:@"backapp"];
                [lockVC dismiss:1.0f];
            }];
        }

    }
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    NSLog(@"这是-----------四");
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *handpassword = [userdefault objectForKey:HAND_PASSWORD];
    NSString *handstatus = [userdefault objectForKey:HANDSTATUS];
    NSString *token = [userdefault objectForKey:TOKEN];
    if (token.length>10) {
        if (handpassword.length>3&&[handstatus intValue]==1) {
            [CLLockVC showVerifyLockVCInVC:self.window.rootViewController forgetPwdBlock:^{
                
                
            } successBlock:^(CLLockVC *lockVC, NSString *pwd) {
                NSLog(@"密码正确appdelegate");
                NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                [userdefault setObject:@" " forKey:@"backapp"];
                [lockVC dismiss:1.0f];
            }];
        }

        
    }

    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    NSLog(@"这是-----------五");
    NSString *handpassword = [[NSUserDefaults standardUserDefaults]objectForKey:HAND_PASSWORD];
    NSLog(@"----passord:%@",handpassword);
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    [userdefault setObject:@"back" forKey:@"backapp"];
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void)getVersion
{
    NSURL *url = [NSURL URLWithString:[ebaseURL stringByAppendingString:@"getVersion"]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@"data = %@ , ",[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
        
        if (!data) {
            return ;
        }
        
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        if (![dic isKindOfClass:[NSDictionary class]]) {
            return;
        }
        
        NSString *versionCode = dic[@"data"][@"code"];
        downloadUrl = dic[@"data"][@"path"];
        NSString *str = [NSString stringWithFormat:@"%@",downloadUrl];
        str = [str stringByReplacingOccurrencesOfString:@"\\\"" withString:@"\""];
        NSLog(@"------------str:%@",str);
        // 1.当前软件的版本号
        NSString *key = (__bridge NSString *)kCFBundleVersionKey;
        NSString *currentVersion = [NSBundle mainBundle].infoDictionary[key];
        
        if ([currentVersion intValue] < [versionCode intValue]) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
               
                UIView *view = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
                view.backgroundColor = [UIColor colorWithWhite:1 alpha:0.8];
                
                UIButton *bt = [UIButton buttonWithType:(UIButtonTypeCustom)];
                bt.frame = CGRectMake(0, 0, 200, 49);
                bt.backgroundColor = YRedColor;
                
                [bt setTitle:@"请更新到最新版本" forState:UIControlStateNormal];
                [bt setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [bt setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
                [view addSubview:bt];
                [bt addTarget:self action:@selector(btAction:) forControlEvents:UIControlEventTouchUpInside];
                bt.layer.cornerRadius = 3;
                
                bt.center = view.center;
                
                [[UIApplication sharedApplication].keyWindow addSubview:view];
                
            });
            
        }
        
    }] resume];
    
    
}

- (void)btAction:(UIButton *)bt
{
    NSString *str = [NSString stringWithFormat:@"%@",downloadUrl];
    str = [str stringByReplacingOccurrencesOfString:@"\\\"" withString:@"\""];
    NSLog(@"------------str:%@",str);
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
}

@end
