//
//  MyCateCell.h
//  MyCateViewController
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCateCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *itemLabel;
@property (weak, nonatomic) IBOutlet UILabel *awardLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UIButton *immdicatyUseButton;

@property (weak, nonatomic) IBOutlet UIView *maskView;

@property (nonatomic,strong)NSDictionary *dic ;

@end
