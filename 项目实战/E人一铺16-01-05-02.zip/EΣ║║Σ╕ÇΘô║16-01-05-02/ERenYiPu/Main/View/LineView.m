//
//  LineView.m
//  TestDrawLineChart1
//
//  Created by mac on 15/10/14.
//  Copyright (c) 2015年 SHIYAN. All rights reserved.
//

#define KLabelW (self.bounds.size.width - 10) / 5
//#define WINSIZEWIDTH [UIScreen mainScreen].bounds.size.width
//#define WINSIZEHEIGHT [UIScreen mainScreen].bounds.size.height
//#define kTableTopH 20       //表顶部 分时图 （字样）的高度
#define KTableBottomH 20    //表底部，分量图 （字样） 的高度
#define KLongitudeWidth self.bounds.size.width / 4     //经度之间的宽度
#define KLatitudeHtight (self.bounds.size.height - 42 ) / 6      //纬度直间的宽度

#define kPointCount 241  //点的总数

#import "LineView.h"

@interface LineView ()
{
    NSInteger pointCount;   //点的总数
    CGFloat disX;   //点与点之间横坐标距离
    CGFloat disY;   //点与点之间纵坐标距离
    
    UIView *v1;
    UIView *v2;
    
    NSMutableArray *linesArr;
    //展示数据的view
    UIView *showDetailView;
    //5个显示的label
    UILabel *xianL;
    UILabel *shiL;
    UILabel *avgL;
    UILabel *rateL;
    UILabel *numL;
    
    //左边显示的label
    UILabel *_leftOpenL; //左边开盘价
    UILabel *_leftHighL; //左边最高价
    UILabel *_leftLowL;  //左边最低价
    
    //右边显示的Label
    UILabel *_rightZeroL;    //0.0
    UILabel *_rightHighRateL;    //右边最高涨幅
    UILabel *_rightLowRateL;     //右边最高跌幅
    
    //经线
    UIBezierPath *longitudePath;
    //纬线
    UIBezierPath *latitudePath;
    //现价
    UIBezierPath *newestPath;
    //均价
    UIBezierPath *avgPath;
    //分量图
    UIBezierPath *fenlPath;
    
    //记住实际开始划线的点是第几个点（现价图）
    NSInteger firstPoint;
    
    CGFloat nowY;   //当前点应该处在的位置
}
@end

@implementation LineView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        linesArr = [NSMutableArray array];
        firstPoint = 0;
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    
    //展示数据的view
    showDetailView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 22)];
    showDetailView.backgroundColor = [UIColor whiteColor];
    showDetailView.layer.borderWidth = 0.5;
    //showDetailView.hidden = YES;
    [self addSubview:showDetailView];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(5 + KLabelW , 2, 18, showDetailView.bounds.size.height - 4)];
    label.text = @"投资收益走势图";
    label.font = [UIFont systemFontOfSize:9];
    label.textColor = [UIColor blackColor];
    [showDetailView addSubview:label];
    
//    //展示数据的5个Label
//    NSArray *showLabelData = @[@"时：",@"现：",@"均：",@"幅：",@"量："];
//    for (int i = 0; i < 5; i ++) {
//        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(5 + KLabelW * i, 2, 18, showDetailView.bounds.size.height - 4)];
//        label.text = [showLabelData objectAtIndex:i];
//        label.font = [UIFont systemFontOfSize:9];
//        label.textColor = [UIColor blackColor];
//        [showDetailView addSubview:label];
//        
//        switch (i) {
//            case 0:
//                shiL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame) , CGRectGetMinY(label.frame), KLabelW - label.bounds.size.width, label.bounds.size.height)];
//                shiL.font = [UIFont systemFontOfSize:9];
//                shiL.textColor = [UIColor blackColor];
//                [showDetailView addSubview:shiL];
//                break;
//            case 1:
//                xianL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame) , CGRectGetMinY(label.frame), KLabelW - label.bounds.size.width, label.bounds.size.height)];
//                xianL.font = [UIFont systemFontOfSize:9];
//                xianL.textColor = [UIColor blackColor];
//                [showDetailView addSubview:xianL];
//                break;
//            case 2:
//                avgL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame) , CGRectGetMinY(label.frame), KLabelW - label.bounds.size.width, label.bounds.size.height)];
//                avgL.font = [UIFont systemFontOfSize:9];
//                avgL.textColor = [UIColor blackColor];
//                [showDetailView addSubview:avgL];
//                break;
//            case 3:
//                rateL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame) , CGRectGetMinY(label.frame), KLabelW - label.bounds.size.width, label.bounds.size.height)];
//                rateL.font = [UIFont systemFontOfSize:9];
//                rateL.textColor = [UIColor blackColor];
//                [showDetailView addSubview:rateL];
//                break;
//            case 4:
//                numL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame) , CGRectGetMinY(label.frame), KLabelW - label.bounds.size.width, label.bounds.size.height)];
//                numL.font = [UIFont systemFontOfSize:9];
//                numL.textColor = [UIColor blackColor];
//                [showDetailView addSubview:numL];
//                break;
//            default:
//                break;
//        }
//        
//    }
    
//    //分量图 Label
//    UILabel *fenliangL = [[UILabel alloc]initWithFrame:CGRectMake(5, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * 4 + 1, self.bounds.size.width - 20, KTableBottomH - 2)];
//    fenliangL.font = [UIFont systemFontOfSize:10];
//    fenliangL.textColor = [UIColor blackColor];
//    fenliangL.text = @"分量图";
//    fenliangL.backgroundColor = [UIColor whiteColor];
//    [self addSubview:fenliangL];
#pragma mark - 左边的三个Label
    //左边的三个Label
    //最高价
    _leftHighL = [[UILabel alloc]initWithFrame:CGRectMake(2, CGRectGetMaxY(showDetailView.frame), 50, 19)];
    _leftHighL.textColor = YRedColor;
    _leftHighL.font = [UIFont systemFontOfSize:9];
    _leftHighL.text = [NSString stringWithFormat:@"%.1f",_maxPoint];
    [self addSubview:_leftHighL];
    //开盘价
    _leftOpenL = [[UILabel alloc]initWithFrame:CGRectMake(2, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * 2 - 19, 50, 19)];
    _leftOpenL.textColor = [UIColor blackColor];
    _leftOpenL.font = [UIFont systemFontOfSize:9];
    _leftOpenL.text = [NSString stringWithFormat:@"%.1f",_openPoint];
    [self addSubview:_leftOpenL];
    //最低价
//    _leftLowL = [[UILabel alloc]initWithFrame:CGRectMake(2, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * 4 - 19, 50, 19)];
//    _leftLowL.textColor = [UIColor colorWithHexString:@"228b22"];
//    _leftLowL.font = [UIFont systemFontOfSize:9];
//    _leftLowL.text = [NSString stringWithFormat:@"%.1f",_minPoint];
//    [self addSubview:_leftLowL];
#pragma mark - 右边的三个Label
    //最高涨幅
    _rightHighRateL = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width - 51, CGRectGetMaxY(showDetailView.frame), 50, 19)];
    _rightHighRateL.textColor = [UIColor redColor];
    _rightHighRateL.font = [UIFont systemFontOfSize:9];
    _rightHighRateL.textAlignment = NSTextAlignmentRight;
    _rightHighRateL.text = [NSString stringWithFormat:@"%.2f%%",(_maxRate )];
    [self addSubview:_rightHighRateL];
    
    //开盘时 0
    _rightZeroL = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width - 51, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * 2 - 19, 50, 19)];
    _rightZeroL.textAlignment = NSTextAlignmentRight;
    _rightZeroL.font = [UIFont systemFontOfSize:9];
    _rightZeroL.textColor = [UIColor blackColor];
    _rightZeroL.text = [NSString stringWithFormat:@"0"];
    [self addSubview:_rightZeroL];
    
    //最低涨幅
//    _rightLowRateL = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width - 51, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * 4 - 19, 50, 19)];
//    _rightLowRateL.textColor = [UIColor colorWithHexString:@"228b22"];
//    _rightLowRateL.font = [UIFont systemFontOfSize:9];
//    _rightLowRateL.textAlignment = NSTextAlignmentRight;
//    _rightLowRateL.text = [NSString stringWithFormat:@"-%.2f%%",(_maxRate )];
//    [self addSubview:_rightLowRateL];
    
#pragma mark - 经纬度 线
    //经度 线
    for (int i = 0; i < 5; i ++) {
        
        if (i == 0 ) {   //左边界
            longitudePath = [UIBezierPath bezierPath];
            [longitudePath moveToPoint:CGPointMake(0 + KLongitudeWidth * i , CGRectGetMaxY(showDetailView.frame))];
            [longitudePath addLineToPoint:CGPointMake(0 + KLongitudeWidth * i , self.bounds.size.height)];
            [longitudePath setLineWidth:1.0];
            [[UIColor blackColor] setStroke];
            [longitudePath stroke];
        }
//        else if (i > 0 && i < 4){
//            longitudePath = [UIBezierPath bezierPath];
//            [longitudePath moveToPoint:CGPointMake(0 + KLongitudeWidth * i, CGRectGetMaxY(showDetailView.frame))];
//            [longitudePath addLineToPoint:CGPointMake(0 + KLongitudeWidth * i, self.bounds.size.height)];
//            const CGFloat f = 3;
//            [longitudePath setLineDash:&f count:1 phase:0];
//            [longitudePath setLineWidth:0.5];
//            [[UIColor lightGrayColor] setStroke];
//            [longitudePath stroke];
//        }
    }
    
    //纬度 线
    for (int i = 0; i < 7; i ++) {
//        if (i == 0 || i == 2 || i == 4) {     //上表上下边界
//            latitudePath = [UIBezierPath bezierPath];
//            [latitudePath moveToPoint:CGPointMake(0, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * i - 1)];
//            [latitudePath addLineToPoint:CGPointMake(self.bounds.size.width, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * i)];
//            [latitudePath setLineWidth:0.7];
//            [[UIColor blackColor] setStroke];
//            [latitudePath stroke];
//        }else if(i == 1 || i == 3){
//            latitudePath = [UIBezierPath bezierPath];
//            [latitudePath moveToPoint:CGPointMake(0, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * i)];
//            [latitudePath addLineToPoint:CGPointMake(self.bounds.size.width, CGRectGetMaxY(showDetailView.frame) + KLatitudeHtight * i)];
//            const CGFloat f = 3;
//            [latitudePath setLineDash:&f count:1 phase:0];
//            [latitudePath setLineWidth:0.5];
//            [[UIColor lightGrayColor] setStroke];
//            [latitudePath stroke];
//        }else if(i == 5 ){
//            latitudePath = [UIBezierPath bezierPath];
//            [latitudePath moveToPoint:CGPointMake(0, CGRectGetMaxY(showDetailView.frame) + KTableBottomH + KLatitudeHtight * (i - 1) )];
//            [latitudePath addLineToPoint:CGPointMake(self.bounds.size.width, CGRectGetMaxY(showDetailView.frame) + KTableBottomH + KLatitudeHtight * (i -1) )];
//            [latitudePath setLineWidth:0.7];
//            [[UIColor blackColor] setStroke];
//            [latitudePath stroke];
//        }else
            if (i == 6){
            latitudePath = [UIBezierPath bezierPath];
            [latitudePath moveToPoint:CGPointMake(0, CGRectGetMaxY(showDetailView.frame) + KTableBottomH + KLatitudeHtight * i )];
            [latitudePath addLineToPoint:CGPointMake(self.bounds.size.width, CGRectGetMaxY(showDetailView.frame) + KTableBottomH + KLatitudeHtight * i )];
            [latitudePath setLineWidth:1];
            [[UIColor blackColor] setStroke];
            [latitudePath stroke];
        }
    }
    
#pragma mark - 现价图  
    //newest avg_price  gid time rate sales
    disX = (self.bounds.size.width - 5) / kPointCount;  //每个点的横向距离
    
    newestPath = [UIBezierPath bezierPath];
    NSMutableArray *newArray = [NSMutableArray array];
    for (NSArray *array in _pointValueArr) {
        [newArray addObject:array[0]];
    }

    CGFloat topTableHeight = KLatitudeHtight * 4 - 5;
    
    for (int i = 0; i < newArray.count; i ++) {
        if ([newArray[i] floatValue ] == 0) {
            firstPoint ++;
            continue;
        }
        //计算当前数值应该在视图上的Y轴上的哪个位置
        if (_maxPoint == _minPoint) {
            nowY = topTableHeight - ([newArray[i] floatValue] - _minPoint + 0.01) / (_maxPoint - _minPoint + 1) * (topTableHeight - 2) + showDetailView.bounds.size.height  - 2;
        }else{
            nowY = topTableHeight - ([newArray[i] floatValue] - _minPoint + 0.01) / (_maxPoint - _minPoint + 1) * (topTableHeight - 2) + showDetailView.bounds.size.height - 2;
        }

        if (i == firstPoint ) {
            [newestPath moveToPoint:CGPointMake(2, nowY)];
            NSDictionary *d = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:2], @"x",[NSNumber numberWithDouble:nowY],@"y", [_pointValueArr objectAtIndex:i][2], @"pointValue", nil];
            [linesArr addObject:d];
            firstPoint = 0;
        }else{
            [newestPath addLineToPoint:CGPointMake(2 + disX * i, nowY)];
            NSDictionary *d = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithDouble:2 + disX * i], @"x",[NSNumber numberWithDouble:nowY],@"y", [_pointValueArr objectAtIndex:i][2], @"pointValue", nil];
            [linesArr addObject:d];
        }
    }
    [newestPath setLineWidth:0.5];
    [_lineColor setStroke];
    [newestPath stroke];


    
}

#pragma mark - 实现block方法
- (void)returnStrValue:(TouchYesBlock)block
{
    self.touchYesBlock = block;
}

//touchBegin
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    v1.hidden = NO;
    v2.hidden = NO;
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self];
    
    v1.frame = CGRectMake(1, location.y, self.bounds.size.width, 0.5);
    v2.frame = CGRectMake(location.x, showDetailView.height, 0.5, self.bounds.size.height - showDetailView.height);
}

//touch
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    //当前触摸位置
    CGPoint location = [touch locationInView:self];
    //NSLog(@"location.x %f ----  location.y --- %f",location.x,location.y);
    
    for (int i = 0; i < linesArr.count; i ++) {
        if (location.x - 0.5 <= [[linesArr[i] valueForKey:@"x"] floatValue]  && location.x + 0.5 >= [[linesArr[i] valueForKey:@"x"] floatValue] ) {
            
            //关闭滑动
            if (self.touchYesBlock != nil) {
                //NSLog(@"传值前 ==== %@",[linesArr[i]valueForKey:@"pointValue"]);
                self.touchYesBlock();
            }
            
            v1.frame = CGRectMake(1, [[linesArr[i] valueForKey:@"y"] floatValue], self.bounds.size.width, 0.5);
            v2.frame = CGRectMake(location.x, showDetailView.height, 0.5, self.bounds.size.height - showDetailView.height);
            
            //给showDetailView 的Label赋值
            //newest avg_price  gid time rate sales
            shiL.text = [[_pointValueArr objectAtIndex:i][3] substringWithRange:NSMakeRange(11, 5)];
            xianL.text = [_pointValueArr objectAtIndex:i][0];
            avgL.text = [NSString stringWithFormat:@"%.2f",[[_pointValueArr objectAtIndex:i][1] floatValue]] ;
            rateL.text = [NSString stringWithFormat:@"%.2f%%" ,[[_pointValueArr objectAtIndex:i][4] floatValue] ];
            numL.text = [NSString stringWithFormat:@"%.0f",[[_pointValueArr objectAtIndex:i][5] floatValue]] ;
        }
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    v1.hidden = YES;
    v2.hidden = YES;
    self.touchEndBlock();
}

@end
