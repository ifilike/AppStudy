//
//  MyCateCell.m
//  MyCateViewController
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "MyCateCell.h"
#import "SLAlertView.h"

@interface MyCateCell ()


@end

@implementation MyCateCell


- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        self.immdicatyUseButton.layer.cornerRadius = 5;
    }
    return self;
}

- (IBAction)immdicatyUseButtonClick:(UIButton *)sender {
    self.immdicatyUseButton.enabled = false;
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\",\"card_id\":\"%@\"}",user_phone,token,[self.dic valueForKey:@"card_id"]];
    [IKHttpTool postWithURL:@"useIcards" params:@{@"json":param} success:^(id json) {
        
        [SLAlertView showAlertWithStatusString:@"使用成功!"];
        
        [sender setTitle:@"使用中" forState:UIControlStateNormal];
        [self.immdicatyUseButton setBackgroundColor:[UIColor colorWithHexString:@"#228B22"]];
        self.immdicatyUseButton.enabled = false;
        
    } failure:^(NSError *error) {
        self.immdicatyUseButton.enabled = true;
        [SLAlertView showAlertWithStatusString:@"使用失败"];
        
        
        
    }];
}

- (void)setDic:(NSDictionary *)dic
{
    _dic = dic;
    self.itemLabel.text = dic[@"name"];
    self.awardLabel.text = [NSString stringWithFormat:@"+%@",dic[@"rate"]];
    self.dateLabel.text = dic[@"end_time"];
    
    NSLog(@"%@", dic);
    

    
    if ([dic[@"is_effective"] intValue] == 1) {
        if ([dic[@"is_use"] intValue] == 1) {
            [self.immdicatyUseButton setTitle:@"使用中" forState:UIControlStateNormal];
            [self.immdicatyUseButton setBackgroundColor:[UIColor colorWithHexString:@"#228B22"]];
            self.immdicatyUseButton.enabled = false;
        }else {
            [self.immdicatyUseButton setTitle:@"立即使用" forState:UIControlStateNormal];
            [self.immdicatyUseButton setBackgroundColor:YRedColor];
            self.immdicatyUseButton.enabled = true;
        }
    }else{
        [self.immdicatyUseButton setTitle:@"已过期" forState:UIControlStateNormal];
        [self.immdicatyUseButton setBackgroundColor:[UIColor colorWithHexString:@"#dbdbdb"]];
        self.immdicatyUseButton.enabled = false;
    }

}

@end
