//
//  LineView.h
//  TestDrawLineChart1
//
//  Created by mac on 15/10/14.
//  Copyright (c) 2015年 SHIYAN. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^TouchYesBlock)(void);

typedef void(^TouchEndBlock)(void) ;

@interface LineView : UIView

@property (nonatomic,copy)NSArray *pointValueArr; //划线所需的数值

@property (nonatomic)CGFloat openPoint;     //开盘价

@property (nonatomic)CGFloat maxSales;      //最大的出入量

@property (nonatomic)CGFloat maxPoint;   //最大值

@property (nonatomic)CGFloat minPoint;   //最小值

@property (nonatomic)CGFloat maxRate;   //最大涨幅

@property (nonatomic)CGFloat minrate;   //最小涨幅

@property (nonatomic)UIColor *lineColor; //线的颜色

@property (nonatomic)UIColor *fillColor; //填充色

@property (nonatomic,strong)NSString *newestValue;  //用来传值给Controller的

@property (nonatomic,copy)TouchYesBlock touchYesBlock;    //block属性

@property (nonatomic,copy)TouchEndBlock touchEndBlock;

- (void)returnStrValue:(TouchYesBlock)block;   //传值方法

@end
