//
//  IWBadgeButton.m
//  ChaoGu
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 潘俊霞. All rights reserved.
//

#import "IWBadgeButton.h"

@implementation IWBadgeButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.titleLabel.font = [UIFont systemFontOfSize:10];
        
       // [self setBackgroundImage:[UIImage imageNamed:@"main_badge"] forState:UIControlStateNormal];
        self.backgroundColor = YRedColor;
        self.size = self.currentBackgroundImage.size;
        self.userInteractionEnabled = NO;
    }
    return self;
}

- (void)setBadgeValue:(NSString *)badgeValue
{
    _badgeValue = [badgeValue copy];
    
    int value = badgeValue.intValue;
    if (value == 0) { // 没有值可以显示
        self.hidden = YES;
    } else {
        self.hidden = NO;
        if (value >= 100) {
            [self setTitle:@"N" forState:UIControlStateNormal];
        } else {
            [self setTitle:badgeValue forState:UIControlStateNormal];
        }
    }
}


@end
