//
//  DrawView.m
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#define KHeight self.bounds.size.width / 2
#define KWidth self.bounds.size.width / 16 * 13

#import "DrawView.h"

@interface DrawView ()
{
    UILabel *titleLabel;
}
@end


@implementation DrawView
-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        //_lineArr = @[@2.4,@4.5,@6.5,@13.5,@2.3,@5.0];
    }
    return self;
}

-(void)drawRect:(CGRect)rect{
    
    //_dateArr = @[@"151204",@"151205"];
    
    titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, WINSIZEWIDTH - 10, 25)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = YGrayColor;
    titleLabel.font = YFont(WINSIZEWIDTH / 20);
    titleLabel.text = @"投资收益走势图";
    
    [self addSubview:titleLabel];
    
    //纵坐标轴 名称
    UILabel *YLabel = [[UILabel alloc] initWithFrame:CGRectMake(WINSIZEWIDTH / 8 - 18, CGRectGetMaxY(titleLabel.frame) , 15, 10)];
    YLabel.text = @"¥";
    YLabel.font = YFont(11);
    YLabel.textColor = YGrayColor;
    YLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:YLabel];
    
    //横坐标轴 名称
    UILabel *XLabel = [[UILabel alloc] initWithFrame:CGRectMake(WINSIZEWIDTH / 16 * 15, CGRectGetMaxY(titleLabel.frame) + KHeight - 10, 15, 10)];
    XLabel.text = @"D";
    XLabel.font = YFont(10);
    XLabel.textColor = YGrayColor;
    XLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:XLabel];
    
    //左边的线
    UIBezierPath *leftViewPath = [UIBezierPath bezierPath];
    [leftViewPath moveToPoint:CGPointMake(WINSIZEWIDTH / 8, CGRectGetMaxY(titleLabel.frame) + 5)];
    [leftViewPath addLineToPoint:CGPointMake(WINSIZEWIDTH / 8, CGRectGetMaxY(titleLabel.frame) + KHeight)];
    [leftViewPath addLineToPoint:CGPointMake(WINSIZEWIDTH / 16 * 15, CGRectGetMaxY(titleLabel.frame) + KHeight)];
    
    [YRedColor setStroke];
    [leftViewPath setLineWidth:2];
    [leftViewPath stroke];
    
    //左边的Label
    UILabel *leftL1 = [[UILabel alloc]initWithFrame:CGRectMake(5, CGRectGetMaxY(titleLabel.frame) + 5, WINSIZEWIDTH / 6, 20)];
    leftL1.textAlignment = NSTextAlignmentCenter;
    leftL1.textColor = YGrayColor;
    leftL1.font = YFont(WINSIZEWIDTH / 26);
    [self addSubview:leftL1];
    leftL1.text = [NSString stringWithFormat:@"%.2f",self.maxPrice];
    
    UILabel *leftL2 = [[UILabel alloc]initWithFrame:CGRectMake(5, CGRectGetMaxY(titleLabel.frame)  + KHeight - 5, WINSIZEWIDTH / 8 - 8, 20)];
    leftL2.textAlignment = NSTextAlignmentCenter;
    leftL2.textColor = YGrayColor;
    leftL2.font = YFont(WINSIZEWIDTH / 26);
    [self addSubview:leftL2];
    leftL2.text = @"0";
    
    //下面的label
    UILabel *bottomL1 = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH / 8 - 10, CGRectGetMaxY(titleLabel.frame) + KHeight + 10, WINSIZEWIDTH / 6 , 20)];
    bottomL1.textAlignment = NSTextAlignmentCenter;
    bottomL1.textColor = YGrayColor;
    bottomL1.font = YFont(WINSIZEWIDTH / 26);
    [self addSubview:bottomL1];
    bottomL1.text = _dateArr[0];
    
    
    UILabel *bottomL2 = [[UILabel alloc]initWithFrame:CGRectMake(KWidth - 10, CGRectGetMaxY(titleLabel.frame) + KHeight + 10, WINSIZEWIDTH / 6 , 20)];
    bottomL2.textAlignment = NSTextAlignmentCenter;
    bottomL2.textColor = YGrayColor;
    bottomL2.font = YFont(WINSIZEWIDTH / 26);
    [self addSubview:bottomL2];
    
    if (_dateArr.count <= 1) {
//        bottomL2.frame = CGRectMake(KWidth / 2 - 10, CGRectGetMaxY(titleLabel.frame) + KHeight + 10, WINSIZEWIDTH / 6 , 20);
        //bottomL2.text = _dateArr[0];
    }else{
//        bottomL2.frame = CGRectMake(KWidth - 10, CGRectGetMaxY(titleLabel.frame) + KHeight + 10, WINSIZEWIDTH / 6 , 20);
        bottomL2.text = _dateArr[1];
    }
    
    
    //画折线图
    
    //如果最大价格为0 ,就不画图了
    if (_maxPrice <= 0 ) {
        return;
    }
    
    //计算X 的位置
    CGFloat disX ;
    if (_lineArr.count > 1) {
        disX = KWidth / (_lineArr.count );
    }else{
        disX = 30;
    }
    
    //disX = 20;
    CGFloat width = 0;
    if (_lineArr.count <= 1) {
        width = WINSIZEWIDTH / 8 + KWidth / 2;
    }else{
        width = (WINSIZEWIDTH / 8 + 5);
    }
    
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    
    //原点
    [linePath moveToPoint:CGPointMake(WINSIZEWIDTH / 8, CGRectGetMaxY(titleLabel.frame) + KHeight)];
    
    for (int i = 0; i < _lineArr.count; i ++) {
        
        CGFloat disY = KHeight - ([_lineArr[i] floatValue] / _maxPrice) * (KHeight - 5) + CGRectGetMaxY(titleLabel.frame) ;
        
        [linePath addLineToPoint:CGPointMake(width + disX * i, disY)];
        
    }
    [linePath setLineWidth:1.6];
    [[UIColor colorWithHexString:@"f6c859"] setStroke];
    //linePath.lineJoinStyle = kCGLineCapRound;
    linePath.lineCapStyle = kCGLineCapRound;
    [linePath stroke];
    

}
-(void)redraw
{
    [self setNeedsDisplay];
}



@end
