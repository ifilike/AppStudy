//
//  DrawView.h
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawView : UIView

@property (nonatomic,strong)NSArray *dateArr;   //日期数组
@property (nonatomic,strong)NSArray *lineArr;
@property (nonatomic)CGFloat maxPrice;   //最大收益

- (void)redraw;

@end
