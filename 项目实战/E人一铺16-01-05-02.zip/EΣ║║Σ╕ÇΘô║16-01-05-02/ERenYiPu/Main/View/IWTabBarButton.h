//
//  IWTabBarButton.h
//  ChaoGu
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 潘俊霞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IWTabBarButton : UIButton
@property (nonatomic, strong) UITabBarItem *item;
@end
