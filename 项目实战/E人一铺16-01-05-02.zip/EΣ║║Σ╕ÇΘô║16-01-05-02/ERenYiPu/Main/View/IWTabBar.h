//
//  IWTabBar.h
//  ChaoGu
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 潘俊霞. All rights reserved.
//

#import <Foundation/Foundation.h>
@class IWTabBar;
@protocol IWTabBarDelegate <NSObject>
@optional
- (void)tabBar:(IWTabBar *)tabBar didSelectButtonFrom:(int)from to:(int)to;
- (void)tabBarDidClickPlusButton:(IWTabBar *)tabBar;

@end
@interface IWTabBar : UIView
/**
 *  添加一个选项卡按钮
 *
 *  @param item 选项卡按钮对应的模型数据(标题\图标\选中的图标)
 */
- (void)addTabBarButton:(UITabBarItem *)item;

@property (nonatomic, weak) id<IWTabBarDelegate> delegate;
@end



