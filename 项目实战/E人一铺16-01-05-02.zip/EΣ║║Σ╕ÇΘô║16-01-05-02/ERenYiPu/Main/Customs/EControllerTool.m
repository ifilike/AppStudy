//
//  EControllerTool.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "EControllerTool.h"
#import "EWelcomeViewController.h"
#import "ETabBarViewController.h"
#import "LogInViewController.h"
#import "ENavigationViewController.h"
#import "DontLoginViewController.h"
#import "SLWelcomeViewController.h"

@implementation EControllerTool
+(void)chooseRootViewController{

    NSString *key = (__bridge NSString *)kCFBundleVersionKey;
    
    // 1.当前软件的版本号
    NSString *currentVersion = [NSBundle mainBundle].infoDictionary[key];
    
    NSLog(@"currentVersion%@",currentVersion);
    
    UIApplication *application = [UIApplication sharedApplication];
    UIWindow *window = application.keyWindow;
    
    // 2.沙盒中的版本号
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *sandBoxVersion = [defaults stringForKey:key];
    
    BOOL versionStatus = [currentVersion compare:sandBoxVersion] == NSOrderedDescending;
    NSLog(@"versionStatus = %d",versionStatus);
    
    // 3.比较  当前软件的版本号  和  沙盒中的版本号
    if ([currentVersion compare:sandBoxVersion] == NSOrderedDescending) {
//    if (1) {
        // 存储当前软件的版本号
        [defaults setObject:currentVersion forKey:key];
        [defaults synchronize];
#warning 修改引导vc
       window.rootViewController = [[SLWelcomeViewController alloc] init];
       // window.rootViewController = [[LogInViewController alloc]init];
    } else {
       // window.rootViewController = [[LogInViewController alloc]init];

        //window.rootViewController = [[EWelcomeViewController alloc] init];
        
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        NSString *user_id = [userDefault objectForKey:USER_ID];
        if (!user_id||[user_id intValue]<1) {
            window.rootViewController = [[ENavigationViewController alloc]initWithRootViewController:[DontLoginViewController new]];
        }else{
            window.rootViewController = [[ETabBarViewController alloc]init];
        }
    }

}
@end
