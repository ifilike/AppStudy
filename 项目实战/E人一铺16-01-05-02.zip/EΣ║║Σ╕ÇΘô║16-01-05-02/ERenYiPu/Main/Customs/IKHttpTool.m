//
//  IWHttpTool.m

//
//  Created by teacher on 14-6-16.
//  Copyright (c) 2014年 itcast. All rights reserved.
//


#import "IKHttpTool.h"
#import "AFNetworking.h"
#import "Reachability.h"
#import "LogInViewController.h"
#import "SLAlertView.h"
#import <CommonCrypto/CommonDigest.h>

#define kMySign @"1234567890abcdefghijklmnopqrstuvwxyz"

@implementation IKHttpTool


+ (void)getWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    // 1.获得请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    // 2.发送一个GET请求
    [mgr GET:url parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) { // 请求成功后会调用
        if (success) {
            success(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) { // 请求失败后会调用
        if (failure) {
            failure(error);
        }
    }];
}

+ (void)postWithURL:(NSString *)url params:(NSDictionary *)params success:(void (^)(id))success failure:(void (^)(NSError *))failure
{
    // 0.检测网络连接状况
    Reachability *r = [Reachability reachabilityWithHostName:@"www.baidu.com"];
    if ([r currentReachabilityStatus] == NotReachable) {
        NSDictionary *dic = @{@"error":[NSString stringWithFormat:@"%ld",(long)NotReachable]};
        if ([url isEqualToString:@"validateCode"]||[url isEqualToString:@"bingdingCard"]) {
            success(dic);
        }
        
        NSLog(@"++++%@",dic);
        [SLAlertView showAlertWithStatusString:@"没有网络请稍后再试"];
        
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"没有网络,请稍后再试" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        //        [alert show];
        return;
    }
    
    // 1.获得请求管理者
    AFHTTPRequestOperationManager *mgr = [AFHTTPRequestOperationManager manager];
    
    mgr.requestSerializer = [AFHTTPRequestSerializer serializer];
    mgr.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    mgr.requestSerializer.timeoutInterval = 10.0;
    
    // 1.1封装参数
    NSMutableDictionary *p = nil;
    if (params) {
        p = [NSMutableDictionary dictionaryWithDictionary:params];
    }
    else {
        p = [NSMutableDictionary dictionary];
    }
    NSLog(@"%@",p);
#pragma mark - 签证
    //签证
    NSString *mySign = [IKHttpTool getSign:p[@"json"]];
    [p setObject:mySign forKey:@"json"];
    
    //192.168.0.19   115.28.143.129   ERenYiPu 120.27.138.247    多服务器: 120.27.184.210  121.41.46.161
    //NSString *URL = [@"http://120.27.184.210:8089/EREP/index.php/Api/" stringByAppendingString:url];
    NSString *URL = [ebaseURL stringByAppendingString:url];

    NSLog(@"URL ====  %@   Params ==== %@",URL,p);
    // 2.发送一个POST请求
    [mgr POST:URL parameters:p success:^(AFHTTPRequestOperation *operation, id responseObject) { // 请求成功后会调用
        
        NSLog(@"statusCode = %@", @(operation.response.statusCode));
        NSString *dataStr = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"%@:----%@",url,dataStr);
        //NSLog(@"stautsstautsstautsstautsstautsstautsstauts   %@",operation.response);
        NSError *error = nil;
        NSDictionary *dictData = [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:&error];
        
        if (error) {//判断是否解析成功
            [SLAlertView hide];
            //            [MBProgressHUD hideHUD];
            //            UIAlertView *alt = [[UIAlertView alloc]initWithTitle:@"提示:" message:@"数据解析失败" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            //            [alt show];
            NSLog(@"----数据解析失败");
            return ;
        }
        
        int status = [dictData[@"status"] intValue];
        
        
        // 2.1 判断状态 1表示正确 其他则表示有错误
        if (status == 1) {
            [SLAlertView hide];
            // 告诉外界(外面):我们请求成功了
            if (success) {
                success(dictData);
            }
        }else if(status == 110){//异地登陆
            [SLAlertView hide];
            //            [MBProgressHUD hideHUD];
            NSString *dataStr = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            NSLog(@"%@",dataStr);

            void(^block2)() = ^(){
                
                [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];
            };
            
            [SLAlertView showAlertWithStatusString:dictData[@"msg"] withButtonTitles:@[@"返回登录"] andBlocks:@[block2]];
//            [SLAlertView showAlertWithStatusString:@"您的账户已在其它地方登陆，请重新登陆" withButtonTitles:@[@"返回登录"] andBlocks:@[block2]];
            
            // [SLAlertView showAlertWithStatusString:dictData[@"msg"]];
            // [MBProgressHUD showError:dictData[@"msg"]];
        }else {
            [SLAlertView hide];
            //       [MBProgressHUD hideHUD];
            NSString *dataStr = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            
            NSLog(@"%@",dataStr);
            if([url isEqualToString:@"unbindingBankCard"]||[url isEqualToString:@"handleWithholdAuthority"]||[url isEqualToString:@"createHostingCollectTrade"]||[url isEqualToString:@"sign"]||[url isEqualToString:@"Certification"]||[url isEqualToString:@"changePassword"]||[url isEqualToString:@"regist"]||[url isEqualToString:@"forgetPassword"]||[url isEqualToString:@"setPaypassword"] || [url isEqualToString:@"bingdingCardVerify"]  || [url isEqualToString:@"allowTixian"]  || [url isEqualToString:@"modifyWithholdAuthority"]){
                // ||[url isEqualToString:@"createSingleHostingPayTrade"]
                [SLAlertView showAlertWithStatusString:dictData[@"msg"]];
            }

            if ([url isEqualToString:@"bingdingCard"] ) {
                success(dictData);
            }
            
            //是否参加活动
            if ([url isEqualToString:@"iCanUseThisActive"]) {
                success(dictData);
                //[SLAlertView showAlertWithStatusString:dictData[@"msg"]];
            }
            
            //登录  验证码发送失败
            if ([url isEqualToString:@"login"]||[url isEqualToString:@"validateCode"]) {
                success(dictData);
            }
            //赎回失败
            if ([url isEqualToString:@"createSingleHostingPayTrade"]) {
                success(dictData);
                [SLAlertView showAlertWithStatusString:dictData[@"msg"]];
            }
            
            //查看是否设置新浪支付密码
            if ([url isEqualToString:@"modifyPaypassword"]||[url isEqualToString:@"findPaypassword"]) {
                success(dictData);
            }
        
            NSLog(@"----------网络错误信息：%@",dictData[@"msg"]);
            //            [prompt showPromptWithTitle:@"error" message:dictData[@"msg"] buttonleft:nil buttonright:nil];
            // [SLAlertView showAlertWithStatusString:dictData[@"msg"]];
            //[MBProgressHUD showError:dictData[@"msg"]];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) { // 请求失败后会调用
        // 告诉外界(外面):我们请求失败了
        if (failure) {
            failure(error);
        }
        
        [SLAlertView hide];
        //[SLAlertView showAlertWithStatusString:@"服务器繁忙,请稍后再试..."];
        //        [MBProgressHUD hideHUD];
        NSString *errorStr = [NSString stringWithFormat:@"%@",error];
       // [SLAlertView showAlertWithStatusString:errorStr];
        
        
        
        NSLog(@"------%@",error.userInfo);
    }];
}

//MD5加密
+ (NSString *)md5:(NSString *)str {
    
//    const char* md5Str = [str UTF8String];
//        unsigned char result[CC_MD5_DIGEST_LENGTH];     CC_MD5(md5Str, strlen(md5Str), result);     NSMutableString *ret = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
//         
//        for(int i = 0; i<CC_MD5_DIGEST_LENGTH; i++) {
//            [ret appendFormat:@"%02X",result];
//        }
//        return ret;
    
    const char *cStr = [str UTF8String];//转换成utf-8
    unsigned char result[16];//开辟一个16字节（128位：md5加密出来就是128位/bit）的空间（一个字节=8字位=8个二进制数）
    CC_MD5( cStr, strlen(cStr), result);
    /*
     extern unsigned char *CC_MD5(const void *data, CC_LONG len, unsigned char *md)官方封装好的加密方法
     把cStr字符串转换成了32位的16进制数列（这个过程不可逆转） 存储到了result这个空间中
     */
    return [NSString stringWithFormat:
            @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
    /*
     x表示十六进制，%02X  意思是不足两位将用0补齐，如果多余两位则不影响
     NSLog("%02X", 0x888);  //888
     NSLog("%02X", 0x4); //04
     */
}

//  {"user_phone":"18611889629","token":"702FF827A219A1E0A17178553698708C"}
//签名
+ (NSString *)getSign:(NSString *)str
{
    NSLog(@"%@",str);
    NSString *signStr = @"";
    
    //将传进来的字符串变成字典
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:[NSJSONSerialization JSONObjectWithData:[str dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil]];
    NSLog(@"%@", dict);
    
    // 字典排序 并 拼接成  key=value&key=value
    NSString *paramStr = [IKHttpTool queryBySortedKeysWithDictionary:dict];

    NSLog(@"paramStr ======== %@",paramStr);

    //user_phone=18611889629&token=054947C4762766AB98D3C11ADDB8597C1234567890abcdefghijklmnopqrstuvwxyz
    
    //拼接  mKey
    paramStr = [NSString stringWithFormat:@"%@&%@",paramStr, kMySign];
    NSLog(@"添加mKey  之后的字符串   =====    %@",paramStr);
    
    //将拼接好的 order URLLender 编码一次
//    NSString *encodeStr = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,(CFStringRef)paramStr,NULL,NULL,kCFStringEncodingUTF8));
    
    NSString *encodeStr = [paramStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet characterSetWithCharactersInString:@"!*'();:@& =+$,/?%#[]%"].invertedSet];
    
    NSLog(@"encodeStrencodeStrencodeStr  ================  %@",encodeStr);
    
    // MD5 加密
    signStr = [IKHttpTool md5:encodeStr];
    NSLog(@"我的签证 ============ %@",signStr);
    signStr = [signStr lowercaseString];
    
    //将签证拼接到最后
    [dict setObject:signStr forKey:@"sign"];
    
    NSLog(@"dictdictdict   ========    %@",dict);
    
    //将字典转化为json格式传回去
    NSData *data = [NSJSONSerialization dataWithJSONObject:dict options:0 error:nil];
    NSString *jsonStr = [[NSString alloc]initWithData:data encoding:(NSUTF8StringEncoding)];
    NSLog(@"jsonStrjsonStr   =======   %@",jsonStr);
    
    return jsonStr;
}

// 将字典 按key  从小到大排序 并 按 key=value&key=value  返回字符串
+ (NSString *)queryBySortedKeysWithDictionary:(NSDictionary *)dict {
    NSMutableArray * parameters = [NSMutableArray array];
    
    for (id key in [[dict allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)]) {
        
        NSString * value = [NSString stringWithFormat:@"%@", dict[key]];
        
        [parameters addObject:[NSString stringWithFormat:@"%@=%@", key, value]];
    }
    
    return [parameters componentsJoinedByString:@"&"];
}






@end
