//
//  EWelcomeViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "EWelcomeViewController.h"
#import "ETabBarViewController.h"
#import "ENavigationViewController.h"
#import "DontLoginViewController.h"
@interface EWelcomeViewController ()<UIScrollViewDelegate>
@property (nonatomic,strong) UIScrollView *scrollView;
@end

@implementation EWelcomeViewController
-(UIScrollView *)scrollView{

    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
        _scrollView.delegate = self;
        _scrollView.backgroundColor = [UIColor whiteColor];
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.bounces = NO;
    }
    return _scrollView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self createUI];
    // Do any additional setup after loading the view.
}
-(void)createUI{

    NSArray *array = @[@"引导页1.jpg",@"引导页2.jpg",@"引导页3.jpg"];
    self.scrollView.contentSize = CGSizeMake(WINSIZEWIDTH*array.count, WINSIZEHEIGHT);
    for (int i = 0; i<array.count; i++) {
        UIImageView *imageVIew = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH*i, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
        imageVIew.image = [UIImage imageNamed:array[i]];
        [self.scrollView addSubview:imageVIew];
        
        if (i==array.count-1) {
            UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(imageVIew.x, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
            [button addTarget:self action:@selector(makeView:) forControlEvents:(UIControlEventTouchUpInside)];
            button.backgroundColor = [UIColor clearColor];
            [self.scrollView addSubview:button];
        }
        NSLog(@"欢迎界面实现了");
    }
    [self.view addSubview:self.scrollView];
}
-(void)makeView:(UIButton *)sender{

    NSLog(@"我能跳转");
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userDefault objectForKey:USER_ID];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (!user_id||[user_id intValue]<10) {
        window.rootViewController = [[ENavigationViewController alloc]initWithRootViewController:[DontLoginViewController new]];
    }else{
        window.rootViewController = [[ETabBarViewController alloc]init];
    }
}


@end
