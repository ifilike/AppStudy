//
//  SLWelComeImageCell.m
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SLWelComeImageCell.h"

@implementation SLWelComeImageCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.imageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.imageView];
        
        self.contentView.translatesAutoresizingMaskIntoConstraints = false;
        self.imageView.translatesAutoresizingMaskIntoConstraints = false;
        
        NSDictionary *dict = @{
                               @"width" : @(WINSIZEWIDTH),
                               @"height" : @(WINSIZEHEIGHT)
                               };
        
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[imageView(width)]|" options:0 metrics:dict views:@{@"imageView" : self.imageView}]];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[imageView(height)]|" options:0 metrics:dict views:@{@"imageView" : self.imageView}]];
        
        
    }
    return self;
}

@end
