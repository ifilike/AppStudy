//
//  ShareViewController.m
//  ajkafhkajf
//
//  Created by mac on 15/12/5.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "ShareViewController.h"
@interface ShareViewController ()

@end

@implementation ShareViewController
@synthesize image = _image;
+ (instancetype)sharedViewController {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (UIImage *)image {

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [NSString stringWithFormat:@"%@",[userdefault objectForKey:USER_ID]];
    NSData *headData = [userdefault objectForKey:user_id];
    UIImage *temp = [UIImage imageWithData:headData];
    if (temp != nil) {
        return temp;
    } else {
        UIImage *temp = [UIImage imageNamed:@"touxiang"];
        return temp;
    }    
}
-(void)setImage:(UIImage *)image{

    if (image==nil) {
        return ;
    }
    _image = image;
}

@end
