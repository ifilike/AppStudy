//
//  ShareViewController.h
//  ajkafhkajf
//
//  Created by mac on 15/12/5.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareViewController : UIViewController
@property(nonatomic,weak)UIViewController *VC;
@property(nonatomic,strong)UIImage *image;
@property (nonatomic,strong)NSString *rateStr; //年化收益率
+ (instancetype)sharedViewController;

@end
