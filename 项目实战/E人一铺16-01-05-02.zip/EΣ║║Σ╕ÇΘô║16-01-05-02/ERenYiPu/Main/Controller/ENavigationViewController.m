//
//  ENavigationViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ENavigationViewController.h"
#import "UIBarButtonItem+CG.h"
@interface ENavigationViewController ()

@end

@implementation ENavigationViewController

+ (void)initialize
{
    // 1.设置导航栏主题
    [self setupNavTheme];
    
    // 1.设置导航栏按钮主题
    [self setupItemTheme];
}

/**
 * 设置导航栏主题
 */
+ (void)setupNavTheme
{
    //     1.获得appearance对象, 就能修改主题
    UINavigationBar *navBar = [UINavigationBar appearance];
    
    navBar.alpha = 0;
    // 2.设置背景
    [navBar setBackgroundImage:[UIImage imageNamed:@"background"] forBarMetrics:UIBarMetricsDefault];
    //[navBar setBackgroundColor:YRedColor];
    navBar.backgroundColor = YRedColor;
    
    // 1.3.设置状态栏背景
    //[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    // 1.4.设置导航栏的文字
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    // 设置文字颜色
    textAttrs[UITextAttributeTextColor] = [UIColor whiteColor];
    // 去掉阴影
    textAttrs[UITextAttributeTextShadowOffset] = [NSValue valueWithUIOffset:UIOffsetZero];
    // 设置文字字体
    textAttrs[UITextAttributeFont] = [UIFont boldSystemFontOfSize:20];
    [navBar setTitleTextAttributes:textAttrs];
    
}

/**
 * 设置导航栏按钮主题
 */
+ (void)setupItemTheme
{
    // 1.获得appearance对象, 就能修改主题
    UIBarButtonItem *item = [UIBarButtonItem appearance];
    
    // 2.设置背景
    // 按钮文字
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    // 设置文字颜色
    textAttrs[UITextAttributeTextColor] = [UIColor whiteColor];
    // 去掉阴影
    textAttrs[UITextAttributeTextShadowOffset] = [NSValue valueWithUIOffset:UIOffsetZero];
    // 设置文字字体
    textAttrs[UITextAttributeFont] = [UIFont systemFontOfSize:17];
    [item setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    
    
    NSMutableDictionary *highTextAttrs = [NSMutableDictionary dictionary];
    highTextAttrs.dictionary = textAttrs;
    // 设置文字颜色
    highTextAttrs[UITextAttributeTextColor] = [UIColor whiteColor];
    [item setTitleTextAttributes:highTextAttrs forState:UIControlStateHighlighted];
    
    
    NSMutableDictionary *disableTextAttrs = [NSMutableDictionary dictionary];
    disableTextAttrs.dictionary = textAttrs;
    // 设置文字颜色
    disableTextAttrs[UITextAttributeTextColor] = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:0.3];
    [item setTitleTextAttributes:disableTextAttrs forState:UIControlStateDisabled];
    
    
         //  [item setBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // 清空手势识别器的代理, 就能恢复以前滑动移除控制器的功能
    self.interactivePopGestureRecognizer.delegate = nil;
    
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if (self.viewControllers.count > 0) { // 如果push的不是根控制器(不是栈底控制器)
        viewController.hidesBottomBarWhenPushed = YES;
      //  viewController.navigationController.navigationBar.backgroundColor = YRedColor;
        // 左上角的返回
        viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:@"back" highImage:@"navigationbar_back_highlighted" target:self action:@selector(back)];
    }
    [super pushViewController:viewController animated:animated];
}

- (void)back
{
    [self popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
