//
//  SLWelcomeViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SLWelcomeViewController.h"
#import "ENavigationViewController.h"
#import "DontLoginViewController.h"
#import "ETabBarViewController.h"
#import "SLWelComeImageCell.h"

@interface SLWelcomeViewController () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@property (strong, nonatomic) NSArray *images;
@property (strong, nonatomic) UIButton *accessButton;
@property (strong, nonatomic) UICollectionView *collectionView;
@property (strong, nonatomic) UICollectionViewFlowLayout *flowLayout;
@property (assign, nonatomic) NSInteger index;

@end

@implementation SLWelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.images = @[@"引导页1.jpg",@"引导页2.jpg",@"引导页3.jpg"];
    [self.view addSubview:self.collectionView];
    
    UIView *maskView = [[UIView alloc] init];
    maskView.frame = self.view.frame;
    [self.view addSubview:maskView];
    maskView.userInteractionEnabled = true;
    maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0];
    
    UIButton *accessButton = [[UIButton alloc] init];
    accessButton.frame = CGRectMake((WINSIZEWIDTH - 150) * 0.5, WINSIZEHEIGHT * 0.87, 150, 50);
    accessButton.backgroundColor = [UIColor colorWithWhite:0.95 alpha:0.5];
    [maskView addSubview:accessButton];
    [accessButton setTitle:@"立即进入" forState:UIControlStateNormal];
    accessButton.alpha = 0;
    accessButton.layer.cornerRadius = 5;
    [accessButton addTarget:self action:@selector(accessButtonClick:) forControlEvents:UIControlEventTouchDown];
    self.accessButton = accessButton;
    
    
    UISwipeGestureRecognizer *swipe = [[UISwipeGestureRecognizer alloc] init];
    swipe.direction = UISwipeGestureRecognizerDirectionLeft;
    [swipe addTarget:self action:@selector(swipeGestureRecognizer:)];
    [self.view addGestureRecognizer:swipe];
    
}

- (UICollectionViewFlowLayout *)flowLayout {
    if (_flowLayout == nil) {
        _flowLayout = [[UICollectionViewFlowLayout alloc] init];
        _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _flowLayout.itemSize = CGSizeMake(WINSIZEWIDTH, WINSIZEHEIGHT);
        _flowLayout.minimumInteritemSpacing = 0;
        _flowLayout.minimumLineSpacing = 0;
    }
    return _flowLayout;
}

- (UICollectionView *)collectionView {
    if (_collectionView == nil) {
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:self.flowLayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.pagingEnabled = true;
        [_collectionView registerClass:[SLWelComeImageCell class] forCellWithReuseIdentifier:@"welcomeCell"];
    }
    return _collectionView;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.images.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SLWelComeImageCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"welcomeCell" forIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:self.images[indexPath.item]];
    return cell;
}

- (void)setIndex:(NSInteger)index {
    if (index == 2) {

        [UIView animateWithDuration:0.5 delay:0.25 options:0 animations:^{
            self.accessButton.alpha = 1;
        } completion:nil];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!self.accessButton.selected) {
                [self.accessButton sendActionsForControlEvents:UIControlEventTouchDown];
            }
        });
    }
    _index = index;
}

- (void)swipeGestureRecognizer:(UISwipeGestureRecognizer *)sender {
    
    if (self.index != 2) {
        self.index++;
    } else {
        return;
    }
    
    NSIndexPath *indexpath = [NSIndexPath indexPathForItem:self.index inSection:0];
    
    [self.collectionView selectItemAtIndexPath:indexpath animated:true scrollPosition:UICollectionViewScrollPositionLeft];
    
}





- (void)accessButtonClick:(UIButton *)sender {
    sender.selected = true;
    
    [UIView animateWithDuration:0.25 animations:^{
        sender.alpha = 0;
    }];
    UIImage *image = [self windowMaskWithAlphaLineChange];
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userDefault objectForKey:USER_ID];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (!user_id||[user_id intValue]<10) {
        window.rootViewController = [[ENavigationViewController alloc]initWithRootViewController:[DontLoginViewController new]];
    }else{
        window.rootViewController = [[ETabBarViewController alloc]init];
    }
    
    UIWindow *mwindow = [UIApplication sharedApplication].keyWindow;
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.image = image;
    [mwindow addSubview:imageView];
    imageView.frame = mwindow.frame;
    
    [UIView animateWithDuration:3 animations:^{
        imageView.alpha = 0;
    } completion:^(BOOL finished) {
        [imageView removeFromSuperview];
    }];
    
    
}

- (UIImage *)windowMaskWithAlphaLineChange {
    
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(WINSIZEWIDTH, WINSIZEHEIGHT), YES, 0);     //设置截屏大小
    [[self.view layer] renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    CGImageRef imageRef = viewImage.CGImage;
    
    CGFloat i = 2;
    if (WINSIZEWIDTH > 40) {
        i = 3;
    }
    
    CGRect rect = CGRectMake(0, 0, WINSIZEWIDTH * i, WINSIZEHEIGHT * i);//这里可以设置想要截图的区域
    CGImageRef imageRefRect =CGImageCreateWithImageInRect(imageRef, rect);
    UIImage *sendImage = [[UIImage alloc] initWithCGImage:imageRefRect];
    
    return sendImage;
    
}


@end
