//
//  MyIconImageView.m
//  ERenYiPu
//
//  Created by babbage on 15/12/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MyIconImageView.h"

@implementation MyIconImageView

- (void)setImage:(UIImage *)image {
    [super setImage:image];
    [self setNeedsLayout];
}

@end
