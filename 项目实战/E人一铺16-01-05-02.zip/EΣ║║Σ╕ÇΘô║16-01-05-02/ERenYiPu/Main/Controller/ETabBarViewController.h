//
//  ETabBarViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ETabBarViewController : UITabBarController

@end
