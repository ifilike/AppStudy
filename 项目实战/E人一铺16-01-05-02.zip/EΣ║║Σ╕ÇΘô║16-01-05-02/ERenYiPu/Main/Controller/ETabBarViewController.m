//
//  ETabBarViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ETabBarViewController.h"
#import "IWTabBar.h"
#import "ENavigationViewController.h"

#import "MySelfViewController.h"
#import "ManageViewController.h"
#import "TEActionViewController.h"
#import "SafeViewController.h"
#import "ShareViewController.h"
@interface ETabBarViewController ()<IWTabBarDelegate>
@property (nonatomic,weak) IWTabBar *customTabBar;
@end

@implementation ETabBarViewController

- (IWTabBar *)customTabBar
{
    if (!_customTabBar) {
        // 创建一个新的tabbar
        IWTabBar *customTabBar = [[IWTabBar alloc] init];
        customTabBar.frame = self.tabBar.bounds;
        
        customTabBar.frame = CGRectMake(0, 0, WINSIZEWIDTH, 55);
        
        customTabBar.delegate = self;
        [self.tabBar addSubview:customTabBar];
        self.customTabBar = customTabBar;
        
    }
    return _customTabBar;
}
#pragma mark init方法内部会调用这个
/**
 *  init方法内部会调用这个
 */
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // 初始化自己的所有子控制器
        [self setupAllChildVCs];
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    // 移除系统自动产生的UITabBarButton
    for (UIView *child in self.tabBar.subviews) {
        // 私有API  UITabBarButton
        if ([child isKindOfClass:[UIControl class]]) {
            [child removeFromSuperview];
        }
    }
}
- (void)setupAllChildVCs
{
    //self.tabBarController.view.backgroundColor = YRedColor;
    //self.view.backgroundColor = YRedColor;
    // 1 理财
    ManageViewController *first = [[ManageViewController alloc] init];
    [self setupOneChildVC:first title:@"理财" imageName:@"licaiBt" selectedImageName:@"culicaiBt"];
    
    //2 活动
    TEActionViewController *topic = [[TEActionViewController alloc] init];
    [self setupOneChildVC:topic title:@"活动" imageName:@"huodong" selectedImageName:@"cuhuodong"];
    //3 保障
    SafeViewController *manager = [[SafeViewController alloc]init];
    [self setupOneChildVC:manager title:@"保障" imageName:@"baozhang" selectedImageName:@"cubaozhang"];
    
    // 4 我的
    MySelfViewController *chat = [[MySelfViewController alloc]init];
    [self setupOneChildVC:chat title:@"我的" imageName:@"wode" selectedImageName:@"cuwode"];
    [ShareViewController sharedViewController].VC = chat;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, 1)];
    view.backgroundColor = YBackGrayColor;
    [self.customTabBar addSubview:view];
}

#pragma mark 初始化一个子控制器
/**
 *  初始化一个子控制器
 *
 *  @param child             需要初始化的子控制器
 *  @param title             标题
 *  @param imageName         图标
 *  @param selectedImageName 选中的图标
 */
- (void)setupOneChildVC:(UIViewController *)child title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    // 1.设置tabBarItem
    // 设置标题
    child.title = title;
    //    child.navigationItem.title = title;
    //    child.tabBarItem.title = title;
    
    // 设置图片
    child.tabBarItem.image = [UIImage imageNamed:imageName];
    UIImage *selectedImage = [UIImage imageNamed:selectedImageName];
    // 设置选中的图片
    child.tabBarItem.selectedImage = selectedImage;
    
    // 2.添加子控制器
    ENavigationViewController *nav = [[ENavigationViewController alloc] initWithRootViewController:child];
    [self addChildViewController:nav];
    
    // 3.往tabbar里面添加选项卡按钮
    [self.customTabBar addTabBarButton:child.tabBarItem];
    self.customTabBar.backgroundColor = [UIColor whiteColor];
}

#pragma mark -IWTabBarDelegate
- (void)tabBar:(IWTabBar *)tabBar didSelectButtonFrom:(int)from to:(int)to
{
    NSUserDefaults *userIdDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userId = [userIdDefaults valueForKey:@"user_id"];
    //if (userId != nil) {
    self.selectedIndex = to;
    //}
    //    else{
    //        self.selectedIndex = 0;
    //        UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"查看更多内容，请先登录！" delegate:self cancelButtonTitle:@"残忍拒绝" otherButtonTitles:@"幸福登录", nil];
    //        alter.delegate=self;
    //        [alter show];
    //    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        
        //        [self presentViewController:[[SigninViewController alloc]init] animated:YES completion:nil];
        
    }
    if (buttonIndex==0) {
        
    }
    
}


- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self.tabBar bringSubviewToFront:self.customTabBar];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    //屏幕截图方法 用模拟器 shift + command + M
    // 1242, 2208 750, 1334  640, 1136  640, 960
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(640, 960), YES, 0);     //设置截屏大小
    [[self.view layer] renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    CGImageRef imageRef = viewImage.CGImage;
    //    CGRect rect = CGRectMake(166, 211, 426, 320);//这里可以设置想要截图的区域
    CGRect rect = CGRectMake(0, 0, 640, 960);//这里可以设置想要截图的区域
    CGImageRef imageRefRect =CGImageCreateWithImageInRect(imageRef, rect);
    UIImage *sendImage = [[UIImage alloc] initWithCGImage:imageRefRect];
    UIImageWriteToSavedPhotosAlbum(sendImage, nil, nil, nil);//保存图片到照片库
    NSData *imageViewData = UIImagePNGRepresentation(sendImage);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *pictureName = [NSString stringWithFormat:@"screenShow_%@.png",[NSProcessInfo processInfo].globallyUniqueString];
    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:pictureName];
    NSLog(@"截屏路径打印: %@", savedImagePath);
    //这里我将路径设置为一个全局String，这里做的不好，我自己是为了用而已，希望大家别这么写
    
    [imageViewData writeToFile:[NSString stringWithFormat:@"/Users/mac/Desktop/%@", pictureName] atomically:YES];//保存照片到沙盒目录
    CGImageRelease(imageRefRect);
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
