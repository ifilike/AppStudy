//
//  activityModel.h
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ActivityModel : NSObject

@property (nonatomic,strong)NSString *active_id;
@property (nonatomic,strong)NSString *active_title;
@property (nonatomic,strong)NSString *active_logo;
@property (nonatomic,strong)NSString *active_url;
@property (nonatomic,strong)NSString *active_status;
@property (nonatomic,strong)NSString *active_endtime;
@property (nonatomic,strong)NSString *base;
@property (nonatomic,strong)NSString *ward;
@property (nonatomic,strong)NSString *min_profit;
@property (nonatomic,strong)NSString *is_auth;

@property (nonatomic,strong)NSString *min_balance;

@end
