//
//  activityModel.m
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "activityModel.h"

@implementation ActivityModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    [super setValue:value forUndefinedKey:key];
}

@end
