//
//  ActiveDetailViewController.h
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ActivityModel.h"

@interface ActiveDetailViewController : UIViewController

@property (nonatomic,strong)ActivityModel *activeModel; //活动 Model类
@property (nonatomic,strong)NSString *userPhone;    //用户手机号

@end
