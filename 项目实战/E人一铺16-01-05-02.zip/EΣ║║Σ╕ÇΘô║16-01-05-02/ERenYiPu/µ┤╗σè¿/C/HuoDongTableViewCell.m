//
//  HuoDongTableViewCell.m
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "HuoDongTableViewCell.h"

@interface HuoDongTableViewCell ()

@property (strong, nonatomic) UIView *maskView;

@end

@implementation HuoDongTableViewCell



- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.actionView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/20, WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/2)];
        [self.contentView addSubview:self.actionView];
        
        self.maskView = [UIView new];
        self.maskView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:self.maskView];
        self.maskView.frame = self.actionView.frame;

        
    }
    return self;
}

- (void)setCellAlpha:(CGFloat)cellAlpha {
    _cellAlpha = cellAlpha;
    self.maskView.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:cellAlpha];
}

@end
