//
//  ActiveDetailViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ActiveDetailViewController.h"
#import "SLAlertView.h"

@interface ActiveDetailViewController ()<UIWebViewDelegate>
{
    UIWebView *_webView;
}
@property(nonatomic,assign)NSInteger length;//判断
@end

@implementation ActiveDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
#pragma mark -- 测试晚点删掉
    
    
    //self.navigationItem.title = @"收益翻翻翻";
    
    self.view.backgroundColor = [UIColor whiteColor];

    
    

        // Do any additional setup after loading the view.
    
    
    
   //    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    NSString *dateString = [userDefaults stringForKey:@"myCateDateString"];
//    
//    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
//    fmt.dateFormat = @"yyyy-MM-dd";
//    NSDate *date = [NSDate date];
//    NSString *tmpDateString = [fmt stringFromDate:date];
//    
//    if ([dateString isEqualToString:tmpDateString]) {
    
    
    


}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    NSString *user_phone = [[NSUserDefaults standardUserDefaults]objectForKey:USER_PHONE];
    NSString *token = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"active_id\":\"%@\",\"token\":\"%@\"}",user_phone,_activeModel.active_id,token];
    [IKHttpTool postWithURL:@"iCanUseThisActive" params:@{@"json":param} success:^(id json) {
        
        if ([json[@"status"] intValue] == 1) {
            
        }else if([json[@"status"] intValue] == 0){
            void(^block)() = ^(){
                [self.navigationController popViewControllerAnimated:true];
            };
            
            [SLAlertView showAlertWithStatusString:json[@"msg"] withButtonTitles:@[@"好的"] andBlocks:@[block]];
            
        }
        
//        self.length = constr.length;
//
//        NSLog(@"----------%@---%ld",constr,self.length);
//        
//        //NSLog(@"-------%ld",self.length);
//        if (self.length<10) {
//            void(^block)() = ^(){
//                [self.navigationController popViewControllerAnimated:true];
//            };
//            
//            [SLAlertView showAlertWithStatusString:@"亲！您今天已参与过活动了,明天再来吧！" withButtonTitles:@[@"好的"] andBlocks:@[block]];
//        }
        
        _webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height )];
        //_webView.scrollView.scrollEnabled = NO;
        _webView.scalesPageToFit = FALSE;
        _webView.delegate = self;
        
        NSString *urlStr = [NSString stringWithFormat:@"%@?active_id=%@&user_phone=%@",_activeModel.active_url,_activeModel.active_id,_userPhone];
        
        NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
        
        [self.view addSubview:_webView];
        [_webView loadRequest:request];
        
        
        
    } failure:^(NSError *error) {
        
    }];

}



- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *requestString = [[request URL]absoluteString];//获取请求的绝对路径.
    requestString = [requestString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSArray *components = [requestString componentsSeparatedByString:@":"];//提交请求时候分割参数的分隔符
    
    if ([components count] >1 && [(NSString *)[components objectAtIndex:0]isEqualToString:@"testapp"]) {
        
        NSLog(@"isWard : %@",[components objectAtIndex:1]);
        NSLog(@"show : %@",[components objectAtIndex:2]);
        NSLog(@"rate : %@",[components objectAtIndex:3]);
        
       NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSDate *date = [NSDate date];
        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"yyyy-MM-dd"; 
        NSString *dateString = [fmt stringFromDate:date];
        NSLog(@"%@", dateString);
        [userDefaults setObject:dateString forKey:@"myCateDateString"];
        [userDefaults synchronize];
        
        
        return NO;
    }
    
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    //修改服务器页面的meta的值
    NSString *meta;
    if ([_activeModel.active_id isEqualToString:@"2"]) {
        meta = [NSString stringWithFormat:@"document.getElementsByName(\"viewport\")[0].content = \"width=%f, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no\"", webView.frame.size.width];
    }else{
        meta = [NSString stringWithFormat:@"document.getElementsByName(\"viewport\")[0].content = \"width=%f, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no\"", webView.frame.size.width];
    }
    
    [webView stringByEvaluatingJavaScriptFromString:meta];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [SLAlertView showAlertWithStatusString:@"请稍候..."];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
