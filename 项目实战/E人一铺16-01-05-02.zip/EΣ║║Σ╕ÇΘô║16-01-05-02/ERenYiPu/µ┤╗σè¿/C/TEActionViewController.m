//
//  TEActionViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "TEActionViewController.h"


#import "ActivityModel.h"
#import "UIImageView+WebCache.h"
#import "ActiveDetailViewController.h"
#import "HuoDongTableViewCell.h"
#import "SLAlertView.h"
//活动ID
//大转盘   1
//翻翻翻   2
//掉金币   3


@interface TEActionViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    double _zongshouyi; //总收益
    double _zhanghuyue; //账户余额
}
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *activeArr;

@end

@implementation TEActionViewController
-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT-CGRectGetMaxY(self.navigationController.navigationBar.frame)-self.tabBarController.tabBar.height)];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];

    _activeArr = [NSMutableArray array];
    
    [self.view addSubview:self.tableView];
    
//    [self getData];
//    [self getData2];
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSString *nowDateStr = [self getNowDateInterval];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    NSString *oldDateStr = [userDefaults objectForKey:@"activityTime"];
    if ([nowDateStr longLongValue] - [oldDateStr longLongValue] > 15) {
        [userDefaults setObject:nowDateStr forKey:@"activityTime"];
        [self getData];
        [self getData2];
    }else{
        //[userDefaults setObject:nowDateStr forKey:kNowDate];
        
        return;
    }
    
}

#pragma mark - UITableView 代理方法
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _activeArr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH-WINSIZEWIDTH/3-WINSIZEWIDTH/9;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    HuoDongTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"huoDongCell"];
    if (!cell) {
        cell = [[HuoDongTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"huoDongCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

    }
    if (self.activeArr.count < 1) {
        return cell;
    }
    ActivityModel *active = [self.activeArr objectAtIndex:indexPath.row];
    
    NSString *headStr = [NSString stringWithFormat:@"%@%@",IMGURL,active.active_logo];
    [cell.actionView sd_setImageWithURL:[NSURL URLWithString:headStr] placeholderImage:[UIImage imageNamed:@"moren"]];
    
//    UIImageView *actionView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/20, WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/2)];
    //NSString *imageStr = [NSString stringWithFormat:@"action%ld",indexPath.row%3+1];

//    [actionView setImageWithURLRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:headStr]] placeholderImage:[UIImage imageNamed:@"head"] success:nil failure:nil];
//    actionView.backgroundColor = YRedColor;
//    [cell.contentView addSubview:actionView];
    
    //赋值
    
    if ([active.active_status isEqualToString:@"0"]) {
        cell.cellAlpha = 0.5;
//        cell.backgroundColor = [UIColor colorWithHexString:@"dbdbdb"];
        
    } else {
        cell.cellAlpha = 0;
    }
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (self.activeArr.count < 1) {
        return;
    }
    
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    
    ActivityModel *active = [self.activeArr objectAtIndex:indexPath.row];
    if ([active.active_status isEqualToString:@"0"]) {
        
    }else if ([active.active_status isEqualToString:@"1"]){
#pragma mark - 如果活动可以玩,要判断  收益 , 余额 , 是否需要认证 ,(这三个是活动数据传过来的,需要跟当前用户比较)
        //
        
        NSString *userName = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_name"];
        if ([userName isEqualToString:@"未认证"]) {
            if ([active.is_auth isEqualToString:@"1"]) {
                [SLAlertView showAlertWithStatusString:@"您还未认证，不能参加该活动"];
                return;
            }
        }
        if ([active.min_profit floatValue] > _zongshouyi ) {
            [SLAlertView showAlertWithStatusString:@"您的总收益不足，不能参加该活动"];
            return;
        }
        if ([active.min_balance floatValue] > _zhanghuyue ) {
            [SLAlertView showAlertWithStatusString:@"您的账户余额不足，不能参加该活动"];
            return;
        }
        
        ActiveDetailViewController *activeDetailVC = [[ActiveDetailViewController alloc]init];
        activeDetailVC.activeModel = active;
        activeDetailVC.userPhone = userPhone;
        activeDetailVC.title = active.active_title;
        [self.navigationController pushViewController:activeDetailVC animated:YES];
    }
}

- (void)getData
{
    [_activeArr removeAllObjects];
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\"}",tokoen];
    [IKHttpTool postWithURL:@"fetchActiveList" params:@{@"json":param} success:^(id json) {
        
        NSArray *arr = json[@"data"];
        NSMutableArray *array = [NSMutableArray array];
        for (NSDictionary *dic in arr) {
            ActivityModel *model = [[ActivityModel alloc]init];
            model = [ActivityModel objectWithKeyValues:dic];
            
            if([model.active_status isEqualToString:@"1"]){
                [_activeArr addObject:model];
            }else{
                [array addObject:model];
            }
            
        }
        [_activeArr addObjectsFromArray:array];
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

//获取用户资金列表
-(void)getData2{
    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param} success:^(id json) {
        NSString *capitilMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"base_investment"]];
        //self.allcount = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_capital"]];
        NSString *allProft = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_profit"]];//总收益
        NSString *avalibleMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"sina_balance"]];//可用金额

        _zongshouyi = [allProft doubleValue];
        _zhanghuyue = [avalibleMoney doubleValue];
        
    } failure:^(NSError *error) {
        
    }];

}

#pragma mark - 获取当前时间的时间戳
- (NSString *)getNowDateInterval
{
    NSDate *date = [NSDate date];
    long timeSp = (long)[date timeIntervalSince1970];
    return [NSString stringWithFormat:@"%ld",(long)timeSp];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
