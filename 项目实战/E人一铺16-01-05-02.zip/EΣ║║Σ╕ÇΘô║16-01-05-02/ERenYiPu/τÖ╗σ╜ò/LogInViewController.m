//
//  LogInViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/11.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "LogInViewController.h"
#import "RegisViewController.h"
#import "ForgetViewController.h"
#import "ETabBarViewController.h"
#import "DontLoginViewController.h"
#import "ENavigationViewController.h"
#import "SLAlertView.h"
@interface LogInViewController () <UITextFieldDelegate>
@property(nonatomic,strong)UITextField *phoneField;
@property(nonatomic,strong)UITextField *keyField;
@property(nonatomic,strong)UIButton *loginBtn;

@end

@implementation LogInViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self createUI];
    //键盘即将出现
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShow:) name:UIKeyboardWillShowNotification object:nil];
    //键盘即将消失
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    self.view.backgroundColor = YRedColor;
    // Do any additional setup after loading the view.
    
}
-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    self.phoneField.text = [[NSUserDefaults standardUserDefaults]objectForKey:USER_PHONE];
}
-(void)createUI{
    UIImageView *backView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
    backView.image = [UIImage imageNamed:@"loginbackgai"];
    //logo
    UIImageView *logoView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/7, WINSIZEWIDTH/3+WINSIZEWIDTH/15, WINSIZEWIDTH-WINSIZEWIDTH/3.5, WINSIZEWIDTH/5)];
    logoView.image = [UIImage imageNamed:@"logo"];
    //手机号
    UIImageView *phoneView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, CGRectGetMaxY(logoView.frame)+WINSIZEWIDTH/8, WINSIZEWIDTH-WINSIZEWIDTH/4.5, WINSIZEWIDTH/8+WINSIZEWIDTH/100)];
    phoneView.image = [UIImage imageNamed:@"backg"];
   
    
    //输入的北背景
    UIView *inputView = [[UIView alloc]initWithFrame:CGRectMake(phoneView.x, WINSIZEHEIGHT/1.66, WINSIZEWIDTH-phoneView.x*2, phoneView.height*2+2)];
    inputView.backgroundColor = [UIColor whiteColor];
    inputView.layer.cornerRadius = WINSIZEWIDTH/60;
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, inputView.height/2-1, inputView.width, 2)];
    lineView.backgroundColor = YBackGrayColor;
    [inputView addSubview:lineView];
    
    UIImageView *phoneImage = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, 0, WINSIZEWIDTH/30, phoneView.height)];
    phoneImage.contentMode = UIViewContentModeScaleAspectFit;
    phoneImage.image = [UIImage imageNamed:@"gaishouji"];
    self.phoneField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, inputView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
    self.phoneField.placeholder = @"请输入手机号";
    self.phoneField.font = YBFont(WINSIZEWIDTH/22);
    self.phoneField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    self.phoneField.delegate = self;
    [inputView addSubview:phoneImage];
    self.phoneField.placeholder = @"请输入手机号";
    self.phoneField.font = YBFont(WINSIZEWIDTH/22);
    self.phoneField.tag = 7770;
    self.phoneField.keyboardType = UIKeyboardTypePhonePad;
  //  [inputView addSubview:phoneView];
  //  [inputView addSubview:self.phoneField];
    //密码
    UIImageView *keyView = [[UIImageView alloc]initWithFrame:CGRectMake(phoneView.x, CGRectGetMaxY(phoneView.frame)+WINSIZEWIDTH/25, phoneView.width, phoneView.height)];
    keyView.image = [UIImage imageNamed:@"backg"];
    UIImageView *keyImage = [[UIImageView alloc]initWithFrame:CGRectMake(phoneImage.x+inputView.x, inputView.y+inputView.height/2+2, phoneImage.width, phoneImage.height)];
    keyImage.contentMode = UIViewContentModeScaleAspectFit;
    
    keyImage.image = [UIImage imageNamed:@"gaimima123"];
    self.keyField = [[UITextField alloc]initWithFrame:CGRectMake(self.phoneField.x, keyImage.y, self.phoneField.width, self.phoneField.height)];
    self.keyField.placeholder = @"请输入密码";
    self.keyField.font = self.phoneField.font;
    self.keyField.secureTextEntry = YES;
   // [keyView addSubview:keyImage];
    self.keyField.delegate = self;
    self.keyField.tag = 7771;
  //  [inputView addSubview:self.keyField];
    [self.phoneField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.keyField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    //登录
    UIButton *loginBtn = [[UIButton alloc]initWithFrame:CGRectMake(keyView.x, CGRectGetMaxY(inputView.frame)+WINSIZEWIDTH/10, keyView.width, keyView.height)];
    [loginBtn setBackgroundColor:[UIColor colorWithHexString:@"d84343"]];
    self.loginBtn = loginBtn;
    [loginBtn setTitle:@"登  录" forState:(UIControlStateNormal)];
    [loginBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    [loginBtn addTarget:self action:@selector(login:) forControlEvents:(UIControlEventTouchUpInside)];
    loginBtn.layer.cornerRadius = WINSIZEWIDTH/80;
    loginBtn.titleLabel.font = YBFont(WINSIZEWIDTH/16);
    [loginBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [self.view addSubview:backView];

    //[self.view addSubview:phoneView];
    //[self.view addSubview:keyView];
    //[inputView addSubview:keyImage];

    [self.view addSubview:inputView];
    [self.view addSubview:keyImage];
    [self.view addSubview:loginBtn];
    [self.view addSubview:self.keyField];
    [self.view addSubview:self.phoneField];
#pragma mark -- 获取本地的账号和密码
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    self.phoneField.text = [userDefault objectForKey:USER_PHONE];
    self.keyField.text = [userDefault objectForKey:PASSWORD];
//注册
    UIButton *regisn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, WINSIZEHEIGHT-WINSIZEWIDTH/6, WINSIZEWIDTH/4, WINSIZEWIDTH/9)];
  //  regisn.backgroundColor = YRedColor;
    [regisn setTitle:@"注 册" forState:(UIControlStateNormal)];
    [regisn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [regisn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    regisn.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [regisn addTarget:self action:@selector(resign:) forControlEvents:(UIControlEventTouchUpInside)];
    //忘记密码
    UIButton *forgetBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-CGRectGetMaxX(regisn.frame), regisn.y, regisn.width, regisn.height)];
   // forgetBtn.backgroundColor = YRedColor;
    [forgetBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [forgetBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    [forgetBtn setTitle:@"重置密码" forState:(UIControlStateNormal)];
    forgetBtn.titleLabel.font = regisn.titleLabel.font;
    [forgetBtn addTarget:self action:@selector(forget:) forControlEvents:(UIControlEventTouchUpInside)];
    
    //[self.view addSubview:logoView];
    [self.view addSubview:regisn];
    [self.view addSubview:forgetBtn];
    
    
}
//登录
-(void)login:(UIButton *)sender{
    // [self.prompt showPromptWithTitle:@"tishi" message:@"登录成功s上来看大佛； 看看了；上岛咖啡了；看来是；都快疯了；看了；扣扣上东方卡紧迫方式" buttonleft:nil buttonright:nil];
    
    // [UIApplication sharedApplication].keyWindow.rootViewController = [[ENavigationViewController alloc]initWithRootViewController:[DontLoginViewController new]];
    
    if(self.phoneField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"手机号不能为空"];
        //        [MBProgressHUD showError:@"手机号不能为空"];
        return;
    }else if(self.phoneField.text.length != 11){
        [SLAlertView showAlertWithStatusString:@"请输入正确的手机号"];
        //        [MBProgressHUD showError:@"请输入正确的手机号"];
        return;
    }else if(self.keyField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"密码不能为空"];
        //        [MBProgressHUD showError:@"密码不能为空"];
        return;
    }
    [self.view endEditing:YES];
    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"password\":\"%@\"}",self.phoneField.text,self.keyField.text];
    [SLAlertView showAlertWithMessageString:@"登录中"];
    //  [MBProgressHUD showMessage:@"登录中..."];
    
    [IKHttpTool postWithURL:@"login" params:@{@"json":str} success:^(id json) {
        [SLAlertView hide];
        
        int status = [json[@"status"] intValue];
        if (status==1) {
            [SLAlertView showAlertWithStatusString:@"登录成功"];
            //        [MBProgressHUD showSuccess:@"登录成功"];
            
            NSLog(@"login-----:%@",json);
            NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
            [userDefault setObject:self.phoneField.text forKey:@"user_phone"];
            [userDefault setObject:self.keyField.text forKey:@"password"];
            [userDefault setObject:json[@"data"][@"user_id"] forKey:USER_ID];
            [userDefault setObject:@"0" forKey:HANDSTATUS];
            [userDefault setObject:json[@"data"][@"token"] forKey:TOKEN];
            [userDefault setObject:json[@"data"][@"uuid"] forKey:@"uuid"];
            [userDefault setObject:json[@"data"][@"user_name"] forKey:@"user_name"];
            [userDefault setObject:@"" forKey:HAND_PASSWORD];
            //        NSString *handword = [NSString stringWithFormat:@"%@",json[@"data"][@"hand_password"]];
            //        NSLog(@"---hand:%@ %li",handword,handword.length);
            //        if(handword.length<4||[handword intValue]<100){//存手势密码
            //            [userDefault setObject:@"1" forKey:HAND_PASSWORD];
            //        }else {
            //            [userDefault setObject:handword forKey:HAND_PASSWORD];
            //        }
            NSString *paypassword = [NSString stringWithFormat:@"%@",json[@"data"][@"paypassword"]];
            NSLog(@"------paypassword:%@",paypassword);
            if([paypassword isEqualToString:@"<null>"]){
                [userDefault setObject:@"1" forKey:PAYPASSWORD];
            }else{
                NSLog(@"------payPassword:%@",json[@"data"][@"paypassword"]);
                [userDefault setObject:json[@"data"][@"paypassword"] forKey:PAYPASSWORD];
            }
            
            //if ([NSString stringWithFormat:@"%@",json[@"data"][@"paypassword"]].length==6) {
            
            //存支付密码
            
            //        }else{
            //            [userDefault setObject:@"1" forKey:PAYPASSWORD];
            //        }
            [self dismissViewControllerAnimated:NO completion:nil];
            [UIApplication sharedApplication].keyWindow.rootViewController = [[ETabBarViewController alloc]init];
            [SLAlertView showAlertWithStatusString:@"登录成功"];
        }else{
            
            [SLAlertView showAlertWithStatusString:json[@"msg"]];
//            self.phoneField.text = @"";
//            self.keyField.text = @"";
        }
        
        
    } failure:^(NSError *error) {
        [SLAlertView hide];
        //        [MBProgressHUD hideHUD];
        [SLAlertView showAlertWithStatusString:@"登录失败"];
        NSLog(@"--------error logIN:%@",error);
    }];
}
//注册
-(void)resign:(UIButton *)sender{
    
    [self presentViewController:[[RegisViewController alloc]init] animated:YES completion:nil];
}
//忘记密码
-(void)forget:(UIButton *)sender{

   // UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:[[ForgetViewController alloc]init]];
    //[nav pushViewController:[[ForgetViewController alloc]init] animated:YES];
    //[self.navigationController pushViewController:[[ForgetViewController alloc]init] animated:YES];
    [self presentViewController:[[ForgetViewController alloc]init] animated:YES completion:nil];
}
//键盘出现
-(void)keyboardShow:(NSNotificationCenter *)notification{

    [UIView animateWithDuration:0.5f animations:^{
        self.view.y = -(self.keyField.y-WINSIZEWIDTH/2-WINSIZEWIDTH/15);
    }];
}
//键盘消失
-(void)keyboardHide:(NSNotificationCenter *)notification{

    self.view.y = 0;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (textField.tag == 7770) {
        [textField resignFirstResponder];
        [((UITextField *)[self.view viewWithTag:7771]) resignFirstResponder];
    } else {
        [self.loginBtn sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
    return true;
}

@end
