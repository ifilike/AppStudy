//
//  RegisViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/11.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "RegisViewController.h"
#import "CLLockVC.h"
#import "ETabBarViewController.h"
#import "SLAlertView.h"
#import "LogInViewController.h"
@interface RegisViewController ()<UITextFieldDelegate>
{
    UILabel *backView;  //校验码背景 Label
}
@property(nonatomic,strong)UITextField *phoneField;//手机号
@property (nonatomic,strong)UITextField *jiaoField; //校验码
@property(nonatomic,strong)UITextField *testField;//验证码
@property(nonatomic,strong)UITextField *FkeyField;//密码
@property(nonatomic,strong)UITextField *keyField;//确认密码
@property(nonatomic,strong)UITextField *recomNumField;//推荐人号码
@property(nonatomic,strong)NSString *testStr;//验证码
@property(nonatomic,assign)int timer;
@end

@implementation RegisViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.timer = 60;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    
    self.view.backgroundColor = YRedColor;
    // Do any additional setup after loading the view.
    
    [self createUI];
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/10, WINSIZEWIDTH/6, WINSIZEWIDTH/10)];
    //viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:@"back" highImage:@"navigationbar_back_highlighted" target:self action:@selector(back)];
    [backBtn setImage:[UIImage imageNamed:@"back"] forState:(UIControlStateNormal)];
    [backBtn addTarget:self action:@selector(back) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:backBtn];
}
-(void)back{//返回

    [self presentViewController:[LogInViewController new] animated:YES completion:nil];
}
-(void)createUI{

    //logo
    UIImageView *logoView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/7, WINSIZEWIDTH/3-WINSIZEWIDTH/10, WINSIZEWIDTH-WINSIZEWIDTH/3.5, WINSIZEWIDTH/5)];
    logoView.image = [UIImage imageNamed:@"logo"];
    //手机号
    NSArray *array = @[@"shouji",@"jiaoyanma",@"yanzhengma",@"fmima",@"mima",@"tuijianren"];
    for (int i = 0; i<array.count; i++) {
    UIImageView *phoneView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, CGRectGetMaxY(logoView.frame)+WINSIZEWIDTH/12+(WINSIZEWIDTH/8+WINSIZEWIDTH/100+WINSIZEWIDTH/25)*i, WINSIZEWIDTH-WINSIZEWIDTH/4.5, WINSIZEWIDTH/8+WINSIZEWIDTH/100)];
    phoneView.image = [UIImage imageNamed:@"backg"];
    UIImageView *phoneImage = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, 0, WINSIZEWIDTH/30, phoneView.height)];
    phoneImage.contentMode = UIViewContentModeScaleAspectFit;
    phoneImage.image = [UIImage imageNamed:array[i]];
        [phoneView addSubview:phoneImage];
        UIButton *codeButton = [[UIButton alloc] init];
        [self.view addSubview:phoneView];
        switch (i) {
            case 0:
                self.phoneField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.phoneField.placeholder = @"请输入手机号";
                self.phoneField.font = YBFont(WINSIZEWIDTH/22);
                self.phoneField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
                [self.view addSubview:self.phoneField];
                break;
                
            case 1:
                self.jiaoField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                
                self.jiaoField.placeholder = @"请输入校验码";
                self.jiaoField.font = YBFont(WINSIZEWIDTH/22);
               // self.jiaoField.keyboardType = UIKeyboardTypeNumberPad;
                
                backView = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/3 + WINSIZEWIDTH/30, self.jiaoField.height/6, WINSIZEWIDTH/7+WINSIZEWIDTH/25, self.jiaoField.height/3 * 2 )];
                backView.backgroundColor = [UIColor whiteColor];
                backView.font = YBFont(WINSIZEWIDTH / 22);
                backView.textAlignment = NSTextAlignmentCenter;
                backView.textColor = YRedColor;
                backView.layer.cornerRadius = WINSIZEWIDTH / 100;
                backView.layer.masksToBounds = YES;
                backView.text = [self getJiaoYanMaStr];
                [self.jiaoField addSubview:backView];
                [self.view addSubview:self.jiaoField];
                
                break;
                
            case 2:
                self.testField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                
                self.testField.placeholder = @"请输入验证码";
                self.testField.font = YBFont(WINSIZEWIDTH/22);
                self.testField.keyboardType = UIKeyboardTypeNumberPad;
                [codeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
                [codeButton setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
                [codeButton setTitleColor:YRedColor forState:(UIControlStateNormal)];
                [codeButton addTarget:self action:@selector(getCode:) forControlEvents:(UIControlEventTouchUpInside)];
                codeButton.tag = 1000;
                codeButton.backgroundColor = [UIColor whiteColor];
                codeButton.titleLabel.font = YBFont(WINSIZEWIDTH/30);
                codeButton.frame = CGRectMake(WINSIZEWIDTH/3+WINSIZEWIDTH/30, self.testField.height/4, WINSIZEWIDTH/7+WINSIZEWIDTH/25, self.phoneField.height/2 );
                codeButton.layer.cornerRadius = WINSIZEWIDTH/100;
                [self.testField addSubview:codeButton];
                [self.view addSubview:self.testField];
                break;
            case 3:
                self.FkeyField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.FkeyField.placeholder = @"请输入密码";
                self.FkeyField.font = YBFont(WINSIZEWIDTH/22);
                self.FkeyField.secureTextEntry = YES;
                [self.view addSubview:self.FkeyField];
                break;
            case 4:
                self.keyField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.keyField.font = YBFont(WINSIZEWIDTH/22);
                self.keyField.placeholder = @"确认密码";
                self.keyField.font = YBFont(WINSIZEWIDTH/22);
                self.keyField.secureTextEntry = YES;
                [self.view addSubview:self.keyField];
                break;
            case 5:
                self.recomNumField = [[UITextField alloc]initWithFrame:CGRectMake(self.FkeyField.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.recomNumField.font = YBFont(WINSIZEWIDTH/22);
                self.recomNumField.placeholder = @"推荐人号码";
                [self.view addSubview:self.recomNumField];
                break;
            default:
                break;
        }
       }
    self.phoneField.delegate = self;
    self.jiaoField.delegate = self;
    self.testField.delegate = self;
    self.FkeyField.delegate = self;
    self.keyField.delegate =self;
    self.recomNumField.delegate = self;
    [self.phoneField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.jiaoField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.testField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.FkeyField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.keyField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.recomNumField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    //注册
    UIButton *loginBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, CGRectGetMaxY(self.recomNumField.frame)+WINSIZEWIDTH/25, WINSIZEWIDTH-WINSIZEWIDTH/4.5, self.keyField.height)];
    [loginBtn setBackgroundColor:[UIColor whiteColor]];
    [loginBtn setTitle:@"注  册" forState:(UIControlStateNormal)];
    [loginBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    loginBtn.layer.cornerRadius = WINSIZEWIDTH/100;
    loginBtn.titleLabel.font = YBFont(WINSIZEWIDTH/16);
    [loginBtn setTitleColor:YRedColor forState:(UIControlStateNormal)];
    [loginBtn addTarget:self action:@selector(regist:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:loginBtn];
    [self.view addSubview:logoView];
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == self.phoneField) {
        [UIView animateWithDuration:1.0 animations:^{
            self.view.y = 0;
        }];
    }else if(textField == self.testField ){
        [UIView animateWithDuration:0.5 animations:^{
            self.view.y = self.phoneField.y-self.testField.y+WINSIZEWIDTH/7;
        }];
    }else if(textField == self.FkeyField){
    
        [UIView animateWithDuration:0.5 animations:^{
            self.view.y = self.phoneField.y-self.FkeyField.y+WINSIZEWIDTH/7;
        }];
    }else if(textField == self.keyField){
    
        [UIView animateWithDuration:0.5 animations:^{
            self.view.y = self.phoneField.y-self.keyField.y+WINSIZEWIDTH/7;
        }];
    }else if(textField == self.recomNumField){
    [UIView animateWithDuration:0.5 animations:^{
        self.view.y = self.phoneField.y-self.recomNumField.y+WINSIZEWIDTH/7;
    }];
    }
}
//获取验证码
-(void)getCode:(UIButton *)sender{
    
    self.jiaoField.text = [self.jiaoField.text lowercaseString];
    NSString *jiaotext = [backView.text lowercaseString];//校验码大写转小写
    if (self.phoneField.text.length!=11) {
        [SLAlertView showAlertWithStatusString:@"请输入正确的手机号"];
        //        [MBProgressHUD showError:@"请输入正确的手机号"];
        return;
    }else
        if (self.jiaoField.text.length < 1){
            [SLAlertView showAlertWithStatusString:@"请输入校验码"];
            // backView.text = [self getJiaoYanMaStr];
            return;
        }else if(![self.jiaoField.text isEqualToString:jiaotext]){
            NSLog(@"--%@---%@++%@,",backView.text,self.jiaoField.text,jiaotext);
            backView.text = [self getJiaoYanMaStr];
            
            [SLAlertView showAlertWithStatusString:@"请输入正确的校验码"];
            
            return;
        }
    
    sender.enabled = NO;
    [sender setTitle:@"请稍候..." forState:(UIControlStateNormal)];

    self.timer = 60;
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\"}",self.phoneField.text];
    
    [IKHttpTool postWithURL:@"validateCode" params:@{@"json":param} success:^(id json) {
        int status = [json[@"status"] intValue];
        // NSLog(@"---++json%@",json);
        
        if (status==0) {
            //   NSLog(@"---json%@",json[@"status"]);
            
            [SLAlertView showAlertWithStatusString:@"获取验证码请求失败"];
            sender.enabled = YES;
            [sender setTitle:@"重新获取" forState:(UIControlStateNormal)];
        }else{
            [SLAlertView showAlertWithStatusString:@"获取验证码发送成功"];

            NSTimer *timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(codeChange:) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
            self.testStr = [NSString stringWithFormat:@"%@",json[@"data"]];
        }
    } failure:^(NSError *error) {
#warning 获取验证码失败应该加提示
        [SLAlertView showAlertWithStatusString:@"获取验证码请求失败"];
        sender.enabled = YES;
    }];
}
-(void)codeChange:(NSTimer *)timer{

    
    UIButton *button = (UIButton *)[self.view viewWithTag:1000];
    self.timer--;
    NSString *btnTit =[NSString stringWithFormat:@"已发送..%d",self.timer];
    [button setTitle:btnTit forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    button.enabled = NO;
    if (self.timer<1) {
        [button setTitleColor:YRedColor forState:(UIControlStateNormal)];
        [button setTitle:@"获取验证码" forState:(UIControlStateNormal)];
        button.enabled = YES;
        [timer invalidate];
    }
}
//注册
-(void)regist:(UIButton *)sender{
   // [self dismissViewControllerAnimated:YES completion:nil];
   
    [self.view endEditing:YES];
    if(self.phoneField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"手机号不能为空"];
//        [MBProgressHUD showError:@"手机号不能为空"];
        return;
    }else if(self.testField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"验证码不能为空"];
//        [MBProgressHUD showError:@"验证码不能为空"];
        return;
    }else if(self.FkeyField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"密码不能为空"];
//        [MBProgressHUD showError:@"密码能为空"];
        return;
    }else if (self.FkeyField.text.length < 6){
        [SLAlertView showAlertWithStatusString:@"密码长度不得少于6位"];
        return;
    }else if (self.FkeyField.text.length > 20){
        [SLAlertView showAlertWithStatusString:@"密码长度不能大于20"];
        return;
    }else if(![self.FkeyField.text isEqualToString:self.keyField.text]){
        [SLAlertView showAlertWithStatusString:@"两次密码输入不一致"];
//        [MBProgressHUD showError:@"两次密码输入不一致"];
        return;
    }else if(![self.testField.text isEqualToString:self.testStr]){
        [SLAlertView showAlertWithStatusString:@"请输入正确的验证码"];
        return;
    }else if ([self.phoneField.text isEqualToString:self.recomNumField.text]){
      [SLAlertView showAlertWithStatusString:@"推荐人不能填写自己"];
        return;
    }
    [SLAlertView showAlertWithMessageString:@"请稍候..."];
  //  [MBProgressHUD showMessage:@"请稍后..."];
   // NSString *token = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"password\":\"%@\",\"reference_phone\":\"%@\"}",self.phoneField.text,self.keyField.text,self.recomNumField.text];
    [IKHttpTool postWithURL:@"regist" params:@{@"json":param} success:^(id json) {
        [SLAlertView hide];
//        [MBProgressHUD hideHUD];
        [SLAlertView showAlertWithStatusString:@"注册成功"];
       // [self.prompt showPromptWithTitle:@"tishi" message:@"    注册成功" buttonleft:nil buttonright:nil];
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        [userdefault setObject:@"100" forKey:@"lock"];
        [userdefault setObject:json[@"data"][@"token"] forKey:TOKEN];

        if(self.recomNumField.text.length>1){
            [userdefault setObject:self.recomNumField.text forKey:@"reference_phone"];
        }else{
            [userdefault setObject:@"" forKey:@"reference_phone"];
        }
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setObject:json[@"data"][@"user_name"] forKey:@"user_name"];
        [userDefault setObject:self.phoneField.text forKey:@"user_phone"];
        [userDefault setObject:self.keyField.text forKey:@"password"];
        [userDefault setObject:json[@"data"][@"user_id"] forKey:USER_ID];
//        NSString *handword = [NSString stringWithFormat:@"%@",json[@"data"][@"hand_password"]];
//        NSLog(@"---hand:%@ %ld",handword,(unsigned long)handword.length);
//        if(handword.length<4||[handword intValue]<100){//存手势密码
//            [userDefault setObject:@"1" forKey:HAND_PASSWORD];
//        }else {
//            [userDefault setObject:handword forKey:HAND_PASSWORD];
//        }
        NSString *paypassword = [NSString stringWithFormat:@"%@",json[@"data"][@"paypassword"]];
        if([paypassword isEqualToString:@"<null>"]){
            [userDefault setObject:@"1" forKey:PAYPASSWORD];
        }else{
            NSLog(@"------payPassword:%@",json[@"data"][@"paypassword"]);
            [userDefault setObject:json[@"data"][@"paypassword"] forKey:PAYPASSWORD];
        }
        [CLLockVC showSettingLockVCInVC:self successBlock:^(CLLockVC *lockVC, NSString *pwd) {
            NSLog(@"密码设置成功");
            NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"password\":\"%@\"}",self.phoneField.text,self.keyField.text];
            [userdefault setObject:HANDSTATUS forKey:@"1"];
            [SLAlertView showAlertWithMessageString:@"正在登录..."];
           // [MBProgressHUD showMessage:@"正在登陆..."];
            [IKHttpTool postWithURL:@"login" params:@{@"json":str} success:^(id json) {
                
                NSLog(@"login-----:%@",json);
                [SLAlertView hide];
//                [MBProgressHUD hideHUD];
                
                NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
                [userDefault setObject:self.phoneField.text forKey:@"user_phone"];
                [userDefault setObject:self.keyField.text forKey:@"password"];
                [userDefault setObject:json[@"data"][@"user_id"] forKey:USER_ID];
                [userDefault setObject:json[@"data"][@"token"] forKey:TOKEN];

//                NSString *handword = [NSString stringWithFormat:@"%@",json[@"data"][@"hand_password"]];
//                NSLog(@"---hand:%@ %ld",handword,(unsigned long)handword.length);
//                if(handword.length<4||[handword intValue]<100){//存手势密码
//                    [userDefault setObject:@"1" forKey:HAND_PASSWORD];
//                }else {
//                    [userDefault setObject:handword forKey:HAND_PASSWORD];
//                }
                NSString *paypassword = [NSString stringWithFormat:@"%@",json[@"data"][@"paypassword"]];
                if([paypassword isEqualToString:@"<null>"]){
                    [userDefault setObject:@"1" forKey:PAYPASSWORD];
                }else{
                    NSLog(@"------payPassword:%@",json[@"data"][@"paypassword"]);
                    [userDefault setObject:json[@"data"][@"paypassword"] forKey:PAYPASSWORD];
                }
                [UIApplication sharedApplication].keyWindow.rootViewController = [[ETabBarViewController alloc]init];
                [SLAlertView showAlertWithStatusString:@"登录成功"];
                [userdefault setObject:@"200" forKey:@"lock"];

            } failure:^(NSError *error) {
                [SLAlertView hide];
//                [MBProgressHUD hideHUD];
                NSLog(@"--------error logIN:%@",error);
            }];

            // [lockVC dismiss:1.0f];
        }];

       
    } failure:^(NSError *error) {
        [SLAlertView hide];
//        [MBProgressHUD hideHUD];
    }];
    
}
-(void)keyboardHide:(NSNotificationCenter *)notification{

    self.view.y = 0;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - 随机生成4个字母的字符串
- (NSString *)getJiaoYanMaStr
{
    NSString *str = @"";
    NSArray *zimuArr = @[@"",@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",@"a",@"b",@"c",@"d",@"e",@"f",@"g",@"h",@"i",@"j",@"k",@"l",@"m",@"n",@"o",@"p",@"q",@"r",@"s",@"t",@"u",@"v",@"w",@"x",@"y",@"z"];

    for (int i = 0; i < 4; i ++) {
        int a = (arc4random() % 52) + 1;
        NSString *s = zimuArr[a];
        str = [str stringByAppendingString:s];
    }
    
    return str;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
