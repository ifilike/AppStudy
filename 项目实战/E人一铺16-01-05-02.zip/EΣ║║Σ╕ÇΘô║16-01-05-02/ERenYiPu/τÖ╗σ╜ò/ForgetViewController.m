//
//  ForgetViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/11.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ForgetViewController.h"
#import "SLAlertView.h"
@interface ForgetViewController ()<UITextFieldDelegate>
@property(nonatomic,strong)UITextField *phoneField;//手机号
@property(nonatomic,strong)UITextField *testField;//验证码
@property(nonatomic,strong)UITextField *FkeyField;//密码
@property(nonatomic,strong)UITextField *keyField;//确认密码
@property(nonatomic,strong)NSString *testStr;//验证码
@property(nonatomic,assign)int timer;//倒计时
@end

@implementation ForgetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.timer = 60;
    self.view.backgroundColor = YRedColor;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    // Do any additional setup after loading the view.
    [self createUI];
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/10, WINSIZEWIDTH/6, WINSIZEWIDTH/10)];
    //viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:@"back" highImage:@"navigationbar_back_highlighted" target:self action:@selector(back)];
    [backBtn setImage:[UIImage imageNamed:@"back"] forState:(UIControlStateNormal)];
    [backBtn addTarget:self action:@selector(back) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:backBtn];


}
-(void)back{

    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)createUI{
    
    //logo
    UIImageView *logoView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/7, WINSIZEWIDTH/3-WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/3.5, WINSIZEWIDTH/5)];
    logoView.image = [UIImage imageNamed:@"logo"];
    //手机号
    NSArray *array = @[@"shouji",@"yanzhengma",@"fmima",@"mima"];
    for (int i = 0; i<array.count; i++) {
        UIImageView *phoneView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, CGRectGetMaxY(logoView.frame)+WINSIZEWIDTH/8+(WINSIZEWIDTH/8+WINSIZEWIDTH/100+WINSIZEWIDTH/25)*i, WINSIZEWIDTH-WINSIZEWIDTH/4.5, WINSIZEWIDTH/8+WINSIZEWIDTH/100)];
        phoneView.image = [UIImage imageNamed:@"backg"];
        UIImageView *phoneImage = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, 0, WINSIZEWIDTH/30, phoneView.height)];
        phoneImage.contentMode = UIViewContentModeScaleAspectFit;
        phoneImage.image = [UIImage imageNamed:array[i]];
        [phoneView addSubview:phoneImage];
        UIButton *codeButton = [[UIButton alloc] init];
        [self.view addSubview:phoneView];
        switch (i) {
            case 0:
                self.phoneField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.phoneField.placeholder = @"请输入手机号";
                self.phoneField.font = YBFont(WINSIZEWIDTH/22);
                self.phoneField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
                [self.view addSubview:self.phoneField];
                break;
            case 1:
                self.testField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                
                self.testField.placeholder = @"请输入验证码";
                self.testField.font = YBFont(WINSIZEWIDTH/22);
                self.testField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
                [codeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
                [codeButton setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
                [codeButton setTitleColor:YRedColor forState:(UIControlStateNormal)];
                codeButton.tag = 1000;
                [codeButton addTarget:self action:@selector(getCode:) forControlEvents:(UIControlEventTouchUpInside)];
                codeButton.backgroundColor = [UIColor whiteColor];
                codeButton.titleLabel.font = YBFont(WINSIZEWIDTH/30);
                codeButton.frame = CGRectMake(WINSIZEWIDTH/3+WINSIZEWIDTH/30, self.testField.height/4, WINSIZEWIDTH/7+WINSIZEWIDTH/25, self.phoneField.height/2 );
                codeButton.layer.cornerRadius = WINSIZEWIDTH/100;
                [self.testField addSubview:codeButton];
                [self.view addSubview:self.testField];
                break;
            case 2:
                self.FkeyField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.FkeyField.placeholder = @"重置密码";
                self.FkeyField.font = YBFont(WINSIZEWIDTH/22);
                self.FkeyField.secureTextEntry = YES;
                [self.view addSubview:self.FkeyField];
                break;
            case 3:
                self.keyField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneImage.frame)+WINSIZEWIDTH/30+phoneView.x, phoneView.y, phoneView.width-CGRectGetMaxX(phoneImage.frame)-WINSIZEWIDTH/30, phoneView.height)];
                self.keyField.font = YBFont(WINSIZEWIDTH/22);
                self.keyField.placeholder = @"确认密码";
                self.keyField.font = YBFont(WINSIZEWIDTH/22);
                self.keyField.secureTextEntry = YES;
                [self.view addSubview:self.keyField];
                break;
            default:
                break;
        }
    }
    self.phoneField.delegate = self;
    self.testField.delegate = self;
    self.FkeyField.delegate = self;
    self.keyField.delegate =self;
    [self.phoneField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.testField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.FkeyField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    [self.keyField setValue:[UIColor colorWithHexString:@"e0e0e0"] forKeyPath:@"_placeholderLabel.textColor"];
    
    //注册
    UIButton *loginBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, CGRectGetMaxY(self.keyField.frame)+WINSIZEWIDTH/25, WINSIZEWIDTH-WINSIZEWIDTH/4.5, self.keyField.height)];
    [loginBtn setBackgroundColor:[UIColor whiteColor]];
    [loginBtn setTitle:@"提  交" forState:(UIControlStateNormal)];
    [loginBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    loginBtn.layer.cornerRadius = WINSIZEWIDTH/100;
    loginBtn.titleLabel.font = YBFont(WINSIZEWIDTH/16);
    [loginBtn setTitleColor:YRedColor forState:(UIControlStateNormal)];
    [loginBtn addTarget:self action:@selector(regist:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:loginBtn];
    [self.view addSubview:logoView];
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == self.phoneField) {
        [UIView animateWithDuration:1.0 animations:^{
            self.view.y = 0;
        }];
    }else if(textField == self.testField ){
        [UIView animateWithDuration:0.5 animations:^{
            self.view.y = self.phoneField.y-self.testField.y;
        }];
    }else if(textField == self.FkeyField){
        
        [UIView animateWithDuration:0.5 animations:^{
            self.view.y = self.phoneField.y-self.FkeyField.y;
        }];
    }else if(textField == self.keyField){
        
        [UIView animateWithDuration:0.5 animations:^{
            self.view.y = self.phoneField.y-self.keyField.y;
        }];
    }
}
//获取验证码
//获取验证码
-(void)getCode:(UIButton *)sender{
    
    if (self.phoneField.text.length!=11) {
        [SLAlertView showAlertWithStatusString:@"请输入正确的手机号"];
        //        [MBProgressHUD showError:@"请输入正确的手机号"];
        return;
    }
    sender.enabled = NO;
    [sender setTitle:@"请稍候..." forState:(UIControlStateNormal)];

    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\"}",self.phoneField.text];
    [IKHttpTool postWithURL:@"validateCode" params:@{@"json":param} success:^(id json) {
        int status = [json[@"status"] intValue];
        if (status==0) {
            // NSLog(@"---json%@ --%@--%ld",json,json[@"status"],status);
            [SLAlertView showAlertWithStatusString:@"获取验证码请求失败"];
            sender.enabled = YES;
            [sender setTitle:@"重新获取" forState:(UIControlStateNormal)];
        }else{
            [SLAlertView showAlertWithStatusString:@"获取验证码发送成功"];

            self.timer = 60;
            NSTimer *timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(codeChange:) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
        }
        
        self.testStr = [NSString stringWithFormat:@"%@",json[@"data"]];
    } failure:^(NSError *error) {
#warning 获取验证码失败应该加提示
        [SLAlertView showAlertWithStatusString:@"获取验证码请求失败"];
        [sender setTitle:@"重新获取" forState:(UIControlStateNormal)];
        NSLog(@"=++++");
        sender.enabled = YES;
    }];
    
}
-(void)codeChange:(NSTimer *)timer{
    
    
    UIButton *button = (UIButton *)[self.view viewWithTag:1000];
    self.timer--;
    NSString *btnTit =[NSString stringWithFormat:@"已发送..%d",self.timer];
    [button setTitle:btnTit forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    button.enabled = NO;
    if (self.timer<1) {
        [button setTitleColor:YRedColor forState:(UIControlStateNormal)];
        [button setTitle:@"获取验证码" forState:(UIControlStateNormal)];
        button.enabled = YES;
        [timer invalidate];
    }

}
//提交
-(void)regist:(UIButton *)sender{
    
    [self.view endEditing:YES];
    if(self.phoneField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"手机号不能为空"];
        //[self.prompt showPromptWithTitle:@"error" message:@"手机号不能为空" buttonleft:nil buttonright:nil];
        return;
    }else if(self.testField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"验证码不能为空"];

        //[self.prompt showPromptWithTitle:@"error" message:@"验证码不能为空" buttonleft:nil buttonright:nil];
        return;
    }else if(self.FkeyField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"密码不能为空"];
       // [self.prompt showPromptWithTitle:@"error" message:@"密码不能为空" buttonleft:nil buttonright:nil];
        return;
    }else if (self.FkeyField.text.length<6){
        [SLAlertView showAlertWithStatusString:@"密码长度不能小于6位"];
        return;
    }else if (self.FkeyField.text.length > 20){
        [SLAlertView showAlertWithStatusString:@"密码长度不能大于20"];
        return;
    }else if(![self.FkeyField.text isEqualToString:self.keyField.text]){
        [SLAlertView showAlertWithStatusString:@"两次输入密码不一致"];

        return;
    }else if(![self.testField.text isEqualToString:self.testStr]){
        [SLAlertView showAlertWithStatusString:@"请输入正确的验证码"];

        return;
    }
    [SLAlertView showAlertWithMessageString:@"请稍候..."];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"new_password\":\"%@\",\"vcode\":\"%@\"}",self.phoneField.text,self.keyField.text,self.testField.text];
    [IKHttpTool postWithURL:@"forgetPassword" params:@{@"json":param} success:^(id json) {
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        [userdefault setObject:self.phoneField.text forKey:USER_PHONE];
        [SLAlertView showAlertWithStatusString:@"密码找回成功"];
        [self dismissViewControllerAnimated:YES completion:nil];
    } failure:^(NSError *error) {
        [SLAlertView showAlertWithStatusString:@"密码找回失败"];
    }];
}
-(void)keyboardHide:(NSNotificationCenter *)notification{
    
    self.view.y = 0;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
