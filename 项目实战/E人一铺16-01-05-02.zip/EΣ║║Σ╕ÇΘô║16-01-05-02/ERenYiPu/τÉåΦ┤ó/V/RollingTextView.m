//
//  RollingTextView.m
//  RollingTextView11
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "RollingTextView.h"

@interface RollingTextView () <UIScrollViewDelegate>

@property (strong, nonatomic) NSArray * textArrLabels;
@property (strong, nonatomic) CADisplayLink *dlink;

@end

@implementation RollingTextView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.speed = 2;
        [self.dlink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        self.delegate = self;
        //self.contentInset = UIEdgeInsetsMake(-64, 0, 64, 0);
        
    }
    return self;
}

- (void)setTextArr:(NSArray *)textArr {
    if (textArr.count > 0) {
        
        for (UIView *subview in self.subviews) {
            if ([subview isKindOfClass:[UILabel class]]) {
                [subview removeFromSuperview];
            }
        }
        
        _textArr = [textArr arrayByAddingObject:textArr[0]];
        _textArrLabels = [self textArrLabelsWithTextArr:_textArr];
        

        [self layoutSubviews];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    UILabel *lastLabel = (UILabel *)_textArrLabels.lastObject;
    self.contentSize = CGSizeMake( lastLabel.frame.origin.x + lastLabel.frame.size.width, self.bounds.size.height);
}


- (NSArray *)textArrLabelsWithTextArr:(NSArray *)textArr {
    
    NSMutableArray *arr = [NSMutableArray array];
    for (NSInteger i = 0; i < textArr.count; i++) {
        static CGFloat x;
        NSString *str = textArr[i];
        CGFloat width = [self titleStringWidthWithString:str];
        
        UILabel *label = [[UILabel alloc] init];
        if (self.textColor) {
            label.textColor = self.textColor;
        } 
        label.frame = CGRectMake(x, 0, width, self.bounds.size.height);
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:16];
        label.text = str;
        x = x + width;
        [self addSubview:label];
        [arr addObject:label];
    }
    return arr.copy;
}




- (CGFloat)titleStringWidthWithString:(NSString *)titleString {
    // 计算titleStringSize
    CGSize titleStringSizeInCell = [titleString boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.bounds.size.height) options:0 attributes:nil context:nil].size;
    return [self numberOfScreenWidthByTitleStringSize:titleStringSizeInCell];
}

- (CGFloat)numberOfScreenWidthByTitleStringSize:(CGSize)titleSize {
    CGFloat selfWidth = self.bounds.size.width;
    while (titleSize.width > selfWidth) {
        selfWidth = selfWidth + selfWidth;
    }
    return selfWidth;
}



#pragma - 定时方法
- (CADisplayLink *)dlink {
    if (_dlink == nil) {
        _dlink = [CADisplayLink displayLinkWithTarget:self selector:@selector(changeIndex)];
    }
    return _dlink;
}

- (void)changeIndex {
    double x = self.contentOffset.x;
    self.contentOffset = CGPointMake(x + self.speed, self.contentOffset.y);
    if (x > self.contentSize.width - self.bounds.size.width) {
        self.contentOffset = CGPointMake(0, self.contentOffset.y);
    }
}


#pragma mark - lifeStyle



- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    self.dlink.paused = true;
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset {
    self.dlink.paused = false;
}

- (void)rollingTextViewAnimationPause {
    self.dlink.paused = true;
}

- (void)rollingTextViewAnimationStart {
    self.dlink.paused = false;
}










@end
