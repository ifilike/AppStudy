//
//  YDScrollView.h
//  ERenYiPu
//
//  Created by babbage on 15/12/22.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YDScrollView : UIView
@property(nonatomic,strong)UILabel *label;
@property(nonatomic,strong)UILabel *label2;
@property(nonatomic,strong)NSString *scrollText;
@property(nonatomic,assign)CGFloat speed;
-(void)createScrllWith:(NSString *)scrollTest speed:(CGFloat)speed;
@end
