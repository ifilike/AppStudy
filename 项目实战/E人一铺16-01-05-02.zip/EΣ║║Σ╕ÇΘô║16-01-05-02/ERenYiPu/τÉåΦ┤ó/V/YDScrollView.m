//
//  YDScrollView.m
//  ERenYiPu
//
//  Created by babbage on 15/12/22.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "YDScrollView.h"
@interface YDScrollView()
@property(nonatomic,strong)NSTimer *timer;
@end
@implementation YDScrollView
-(instancetype)initWithFrame:(CGRect)frame{

   self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
-(void)createUI{
    
    self.label = [[UILabel alloc]init];
    self.label2 = [[UILabel alloc]init];
    [self addSubview:self.label];
    [self addSubview:self.label2];
}
-(void)createScrllWith:(NSString *)scrollTest speed:(CGFloat)speed{
    if (self.timer) {
        [self.timer invalidate];
    }
       self.scrollText = scrollTest;
    self.speed = speed;
    CGRect frame = CGRectMake(self.width+10, 0, self.width*10, self.height);
    self.label.text = scrollTest;
    self.label.textColor = YGrayColor;
    self.label.font = YBFont(WINSIZEWIDTH/20);
    self.label2.text = scrollTest;
    self.label.frame = [self.label textRectForBounds:frame limitedToNumberOfLines:1];
    self.label2.frame = CGRectMake(-self.width*10, 0, self.label.frame.size.width, self.frame.size.height);
    self.label2.textColor = YGrayColor;
    self.label2.font = YBFont(WINSIZEWIDTH/20);
   
    self.layer.masksToBounds = YES;
    self.clipsToBounds = YES;
    self.timer = [NSTimer timerWithTimeInterval:speed target:self selector:@selector(scroLL:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
    
}
-(void)scroLL:(NSTimer *)timer{
    
   
    //  lable2.frame = CGRectMake(lable2.frame.origin.x-1, label.frame.origin.y, label.frame.size.width, label.frame.size.height);
    
    if ((NSInteger)self.label.frame.origin.x+(NSInteger)self.label.frame.size.width==(NSInteger)(self.width/2)) {
        self.label2.frame = CGRectMake(self.frame.size.width, self.label.frame.origin.y, self.label2.frame.size.width, self.label2.frame.size.height);
    }else if((NSInteger)self.label2.frame.origin.x+(NSInteger)self.label2.frame.size.width==(NSInteger)(self.width/2)){
        self.label.frame = CGRectMake(self.frame.size.width, self.label.frame.origin.y, self.label2.frame.size.width, self.label2.frame.size.height);
    }
    
    self.label.frame = CGRectMake(self.label.frame.origin.x-1, self.label.frame.origin.y, self.label2.frame.size.width, self.label2.frame.size.height);
    
    self.label2.frame = CGRectMake(self.label2.frame.origin.x-1, self.label.frame.origin.y, self.label2.frame.size.width, self.label2.frame.size.height);
    
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
