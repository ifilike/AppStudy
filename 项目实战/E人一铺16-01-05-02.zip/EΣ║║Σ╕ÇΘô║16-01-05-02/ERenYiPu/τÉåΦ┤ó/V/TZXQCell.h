//
//  TZXQCell.h
//  TZXQ
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TZXQCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *labelHeightCons;

@property (weak, nonatomic) IBOutlet UILabel *contextLabel;

@end
