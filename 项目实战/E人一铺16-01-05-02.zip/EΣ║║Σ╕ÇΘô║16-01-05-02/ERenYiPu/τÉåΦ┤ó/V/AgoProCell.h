//
//  AgoProCell.h
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AgoProCell : UITableViewCell

@property (nonatomic,strong)UILabel *limit; //蒲宝宝 第几期
@property (nonatomic,strong)UILabel *time;//日期
@property (nonatomic,strong)UILabel *money;//总额
@property (nonatomic,strong)UILabel *persons;//投资人数
@property (nonatomic,strong)UILabel *profit; //年化收益

@end
