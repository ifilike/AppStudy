//
//  AgoProCell.m
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AgoProCell.h"

@interface AgoProCell() 

@end
@implementation AgoProCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    //蒲宝宝
    self.limit = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/40, WINSIZEWIDTH/20, WINSIZEWIDTH/3*2, WINSIZEWIDTH/15)];
    self.limit.text = @"铺宝宝第-期";
    self.limit.font = YBFont(WINSIZEWIDTH/20);
    self.limit.textColor = YRedColor;
    //时间
    self.time = [[UILabel alloc]initWithFrame:CGRectMake(self.limit.x, CGRectGetMaxY(self.limit.frame), WINSIZEWIDTH/2, WINSIZEWIDTH/20)];
    self.time.text = @"2015-11-12 15:12";
    self.time.textColor = YGrayColor;
    self.time.font = YBFont(WINSIZEWIDTH/28);
    UIView *horView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30, CGRectGetMaxY(self.time.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/15, 1)];
    horView.backgroundColor = YBackGrayColor;
    NSArray *array = @[@"总额（万）",@"投资人数",@"年化收益率"];
    for (int i =0; i<3; i++) {
        switch (i) {
            case 0:
                self.money = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30, CGRectGetMaxY(horView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH/3-WINSIZEWIDTH/45, WINSIZEWIDTH/15)];
                self.money.textColor = YGrayColor;
                self.money.text = @"-";
                self.money.font = YBFont(WINSIZEWIDTH/25);
                self.money.textAlignment = NSTextAlignmentCenter;
                break;
                case 1:
                self.persons = [[UILabel alloc]initWithFrame:CGRectMake( CGRectGetMaxX(self.money.frame),self.money.y, self.money.width, self.money.height)];
                self.persons.text = @"-";
                self.persons.font =self.money.font;
                self.persons.textColor = self.money.textColor;
                self.persons.textAlignment = NSTextAlignmentCenter;
                break;
                case 2:
                self.profit = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.persons.frame), self.money.y, self.money.width, self.money.height)];
                self.profit.textAlignment = NSTextAlignmentCenter;
                self.profit.textColor = self.money.textColor;
                self.profit.font = self.money.font;
                self.profit.text = @"8.00%";
            default:
                break;
        }
        UILabel *pertect = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30+self.money.width*i, CGRectGetMaxY(self.money.frame), self.money.width, self.money.height)];
        pertect.text = array[i];
        pertect.textColor = YGrayColor;
        pertect.font = self.money.font;
        pertect.textAlignment = NSTextAlignmentCenter;
        UIView *verView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30+self.money.width*(i+1), self.money.y+WINSIZEWIDTH/30, 1, WINSIZEWIDTH/10)];
        verView.backgroundColor = YBackGrayColor;
        if (i==2) {
            verView.hidden = YES;
        }

        [self addSubview:verView];
        [self addSubview:pertect];
    }
    UIImageView *imageView =[[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-horView.y-WINSIZEWIDTH/8, 0, horView.y+WINSIZEWIDTH/12, horView.y-WINSIZEWIDTH/50)];
   // imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.image = [UIImage imageNamed:@"isover"];
    [self addSubview:self.limit];
    [self addSubview:self.time];
    [self addSubview:self.money];
    [self addSubview:self.persons];
    [self addSubview:self.profit];
    [self addSubview:horView];
    [self addSubview:imageView];
}
@end
