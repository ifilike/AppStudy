//
//  RollingTextView.h
//  RollingTextView11
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RollingTextView : UIScrollView

// 字符串数组
@property (strong, nonatomic) NSArray *textArr;
// 字体颜色
@property (strong, nonatomic) UIColor *textColor;


// 移动速度
@property (assign, nonatomic) CGFloat speed;

- (void)rollingTextViewAnimationPause;
- (void)rollingTextViewAnimationStart;

@end
