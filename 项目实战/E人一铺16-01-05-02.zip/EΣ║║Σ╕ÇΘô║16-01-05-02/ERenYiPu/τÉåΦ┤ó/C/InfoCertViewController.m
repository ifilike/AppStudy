//
//  InfoCertViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/6.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "InfoCertViewController.h"
#import "SLAlertView.h"
#import "AboutTieCardVC.h"
#import "InvestViewController.h"
@interface InfoCertViewController ()<PayVIeWDelegate>
@property(nonatomic,strong)UITextField *numField;//验证码
@property(nonatomic,strong)UIButton *getNumBtn;//获取验证码按钮
@property(nonatomic,assign)int timer;//倒计时
@property(nonatomic,strong)PayVIew *payView;//支付界面
@property(nonatomic,strong)NSString *code;//验证码
@end

@implementation InfoCertViewController

-(PayVIew *)payView{

    if (!_payView) {
        _payView = [[PayVIew alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
        _payView.delegate = self;
        _payView.backgroundColor = [UIColor colorWithHexString:@"000000" alpha:0.5];
    }
    return _payView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.timer = 60;
    // Do any additional setup after loading the view.
    self.title = @"填写个人信息";
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    
    [self createUI];
    //支付界面
    [self createPayView];
    
}
-(void)createPayView{

    [self.payView createUI:@"请输入支付密码"];
    [self.navigationController.view addSubview:self.payView];
    self.payView.hidden = YES;
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/7)];
    firstView.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/3-WINSIZEWIDTH/30, firstView.height)];
    label.text = @"输入个人信息";
    label.textColor = YGrayColor;
    label.font = YFont(WINSIZEWIDTH/22);
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame), firstView.height/2-WINSIZEWIDTH/80, WINSIZEWIDTH/60, WINSIZEWIDTH/40)];
    image1.image = [UIImage imageNamed:@"jiantou"];
    [firstView addSubview:image1];
    UILabel *cardLal = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(image1.frame)+WINSIZEWIDTH/25, label.y, WINSIZEWIDTH/3-WINSIZEWIDTH/16, firstView.height)];
    cardLal.textColor = YGrayColor;
    cardLal.font = label.font;
    cardLal.text = @"绑定银行卡";
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardLal.frame), image1.y, image1.width, image1.height)];
    image2.image = [UIImage imageNamed:@"jiantou"];
    UILabel *infoCerti = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(image2.frame)+WINSIZEWIDTH/25, label.y, WINSIZEWIDTH/4, firstView.height)];
    infoCerti.text = @"信息认证";
    infoCerti.textColor = YRedColor;
    infoCerti.font = label.font;
    
    [firstView addSubview:label];
    [firstView addSubview:image1];
    [firstView addSubview:cardLal];
    [firstView addSubview:image2];
    [firstView addSubview:infoCerti];
    
    UIView *secondView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    secondView.backgroundColor = [UIColor whiteColor];
    self.numField = [[UITextField alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/50, WINSIZEWIDTH/3+WINSIZEWIDTH/20, firstView.height-WINSIZEWIDTH/25)];
    self.numField.leftViewMode = UITextFieldViewModeAlways;
    self.numField.leftView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30, 0, WINSIZEWIDTH/30, self.numField.height)];
    self.numField.font = YBFont(WINSIZEWIDTH/21);
    self.numField.placeholder = @"在此输入验证码";
    self.numField.layer.borderColor = YRedColor.CGColor;
    self.numField.layer.borderWidth = 1;
    self.numField.keyboardType = UIKeyboardTypeNumberPad;
    UIButton *getNum = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(infoCerti.frame)-WINSIZEWIDTH/3-WINSIZEWIDTH/20, self.numField.y+1, WINSIZEWIDTH/4+WINSIZEWIDTH/20, self.numField.height-2)];
    getNum.tag = 1000;
    getNum.backgroundColor = YRedColor;
    [getNum setTitle:@"获取验证码" forState:(UIControlStateNormal)];
    [getNum setTitle:@"验证码已发送..." forState:(UIControlStateSelected)];
    getNum.titleLabel.font = self.numField.font;
    [getNum setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [getNum setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    getNum.layer.cornerRadius = WINSIZEWIDTH/100;
    [getNum addTarget:self action:@selector(getNum:) forControlEvents:(UIControlEventTouchUpInside)];
  //  getNum setTitle:@"验证码已发送" forState:(UIControlState)
    self.getNumBtn = getNum;
    [secondView addSubview:self.numField];
    [secondView addSubview:getNum];
    
    UIView *thirdView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEHEIGHT)];
    thirdView.backgroundColor = [UIColor whiteColor];
    UIButton *chooseBtn = [[UIButton alloc]initWithFrame:CGRectMake(self.numField.x, WINSIZEWIDTH/30, WINSIZEWIDTH/25, WINSIZEWIDTH/30)];
    [chooseBtn setImage:[UIImage imageNamed:@"chooseno"] forState:(UIControlStateNormal)];
    [chooseBtn setImage:[UIImage imageNamed:@"chooseyes"] forState:(UIControlStateSelected)];
    [chooseBtn addTarget:self action:@selector(choose:) forControlEvents:(UIControlEventTouchUpInside)];
    UILabel *readedLal = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(chooseBtn.frame)+WINSIZEWIDTH/100,WINSIZEWIDTH/33 , WINSIZEWIDTH/3+WINSIZEWIDTH/75, WINSIZEWIDTH/30)];
    readedLal.text = @"我已阅读并同意遵守";
    readedLal.font = YFont(WINSIZEWIDTH/26);
    readedLal.textColor = YGrayColor;
    //网上服务条款
    UIButton *provision = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(readedLal.frame)+WINSIZEWIDTH/100, WINSIZEWIDTH/33, WINSIZEWIDTH/3, readedLal.height)];
    [provision setTitle:@"《网上服务条款》" forState:(UIControlStateNormal)];
    [provision setTitleColor:YRedColor forState:(UIControlStateNormal)];
    [provision setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    provision.titleLabel.font = readedLal.font;
    UIButton *okBtn = [[UIButton alloc]initWithFrame:CGRectMake(label.x, WINSIZEWIDTH/5, WINSIZEWIDTH-label.x*2, WINSIZEWIDTH/8)];
    [okBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [okBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    [okBtn setTitle:@"确 定" forState:(UIControlStateNormal)];
    okBtn.backgroundColor = YRedColor;
    okBtn.titleLabel.font = YBFont(WINSIZEWIDTH/19);
    okBtn.layer.cornerRadius = WINSIZEWIDTH/100;
    [okBtn addTarget:self action:@selector(ok:) forControlEvents:(UIControlEventTouchUpInside)];
#pragma mark -- 网上协议已删除
    [thirdView addSubview:okBtn];
//    [thirdView addSubview:chooseBtn];
//    [thirdView addSubview:readedLal];
//    [thirdView addSubview:provision];
    
    [self.view addSubview:thirdView];
    [self.view addSubview:secondView];
    [self.view addSubview:firstView];
}
//选择是否遵守
-(void)choose:(UIButton *)sender{

    sender.selected = !sender.selected;
    //NSLog(@"-----%d",(int)sender.selected);
}
//网上服务协议
//获取验证码
// user_phone public function validateCode(){

-(void)getNum:(UIButton *)sender{
#warning 获取手机验证码待测；
    [SLAlertView showAlertWithMessageString:@"请稍候..." ];
    sender.enabled = NO;
    self.timer = 60;
    [sender setTitle:@"请稍候..." forState:(UIControlStateNormal)];

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"card_number\":\"%@\",\"bank_name\":\"%@\",\"token\":\"%@\",\"phone_no\":\"%@\",\"user_name\":\"%@\"}",user_phone,self.cardNum,self.bankName,token,self.infoPhone,self.userName];
    [IKHttpTool postWithURL:@"bingdingCard" params:@{@"json":param} success:^(id json) {
        int status = [json[@"status"] intValue];
        if (status==0) {
            [SLAlertView showAlertWithStatusString:json[@"data"][@"response_message"]];
            sender.enabled = YES;
            [sender setTitle:@"重新获取" forState:(UIControlStateNormal)];
        }else{
            [SLAlertView showAlertWithStatusString:@"验证码发送成功"];
            self.ticket = [NSString stringWithFormat:@"%@",json[@"data"][@"ticket"]];
            NSTimer *timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(change:) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
        }
    } failure:^(NSError *error) {
        sender.enabled = YES;
    }];
    
}
-(void)change:(NSTimer *)timer{

    UIButton *button = [self.view viewWithTag:1000];
    NSString *btnTit = [NSString stringWithFormat:@"已发送..%d",--self.timer];
    [button setTitle:btnTit forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    button.enabled = NO;
    if (self.timer<1) {
        [button setTitle:@"获取验证码" forState:(UIControlStateNormal)];
        button.enabled = YES;
        [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [timer invalidate];
    }
}
#pragma mark --- 支付界面的delegate
-(void)payViewDelegateButton:(NSInteger)buttonIndex textFields:(NSString *)text{

    if ([self.payView.symbol isEqualToString:@"请输入支付密码"]) {
        [self.payView createUI:@"请确认支付密码"];
    }
    NSLog(@"------------text:%@",text);
}
//确定 valid_code;user_id public function bingdingCardVerify()
-(void)ok:(UIButton *)sender{

    if (self.numField.text.length<1) {
        [SLAlertView showAlertWithStatusString:@"验证码不能为空"];
        return;
    }
    [self.view endEditing:YES];
    [SLAlertView showAlertWithMessageString:@"请稍候..."];
    //[MBProgressHUD showMessage:@"请稍后"];
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    self.userName = [userdefault objectForKey:@"user_name"];
    NSString *param = [NSString stringWithFormat:@"{\"valid_code\":\"%@\",\"user_phone\":\"%@\",\"token\":\"%@\",\"ticket\":\"%@\",\"user_name\":\"%@\"}",self.numField.text,user_phone,token,self.ticket,self.userName];
    [IKHttpTool postWithURL:@"bingdingCardVerify" params:@{@"json":param} success:^(id json) {
        [userdefault setObject:self.userName forKey:@"user_name"];
        NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
        [userdefault setObject:json[@"data"][@"uuid"] forKey:@"uuid"];
        
        [IKHttpTool postWithURL:@"queryIsSetPayPassword" params:@{@"json":str} success:^(id json) {
            [SLAlertView hide];
//            [MBProgressHUD hideHUD];
            NSString *status = [NSString stringWithFormat:@"%@",json[@"data"][@"is_set_paypass"]];
            if ([status isEqualToString:@"Y"]) {
                [SLAlertView showAlertWithStatusString:@"绑定成功"];
                for (UIViewController *vc in self.navigationController.viewControllers) {
                    if ([vc isKindOfClass:[AboutTieCardVC class]]) {
                        [self.navigationController popToViewController:vc animated:YES];
                        return ;
                    }
                }
                for (UIViewController *vc in self.navigationController.viewControllers) {
                    if ([vc isKindOfClass:[InvestViewController class]]) {
                        [self.navigationController popToViewController:vc animated:YES];
                        return ;
                    }
                }
                [self.navigationController popToRootViewControllerAnimated:YES];
                
            }else{
                void(^block)() = ^(){
                };
                void(^block2)() = ^(){
                    [SLAlertView showAlertWithMessageString:@"请稍候..."];
                    // [MBProgressHUD showMessage:@"请稍后"];
                    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                    NSString *user_id = [userdefault objectForKey:USER_ID];
                    NSString *token = [userdefault objectForKey:TOKEN];
                    NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                    [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                        [SLAlertView hide];
                        //        [MBProgressHUD hideHUD];
                        WebViewController *webVC = [[WebViewController alloc]init];
                        webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"]];
                        [self.navigationController pushViewController:webVC animated:YES];
                    } failure:^(NSError *error) {
                        
                    }];
                };
                [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];
            }
            
            return ;
        } failure:^(NSError *error) {
            return ;
        }];

    } failure:^(NSError *error) {
        
    }];
//    NSString *param = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\",\"ticket\":\"%@\",\"user_name\":\"%@\",\"valid_code\":\"%@\"}",user_id,token,self.ticket,self.userName,self.code];
//    
//    NSLog(@"+++param:%@ %@ %@",param,self.code,self.numField.text);
//    [IKHttpTool postWithURL:@"bingdingCardVerify" params:@{@"json":param} success:^(id json) {
//       // self.payView.hidden = NO;
//        [self.prompt makePromptWithTitle:@"提示" message:@"您是否要立即设置支付密码？" buttonleft:@"取消" buttonright:@"去设置"];
//    } failure:^(NSError *error) {
//        
//    }];
}
//设置支付密码
-(void)actionWithButtonIndex:(NSInteger)buIndex{

}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
