//
//  TieCardViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/6.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "TieCardViewController.h"
#import "InfoCertViewController.h"
#import "SLAlertView.h"
@interface TieCardViewController ()<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UITextField *CardField;//储蓄卡卡号；
@property (nonatomic,strong) UITextField *phoneField;//银行预留手机号
@property (nonatomic,strong) UITableView *cardTableView;//开户行
@property (nonatomic,strong) NSMutableArray *cardArr;//所有的开户行
@property (nonatomic,strong) NSString *bank_name;//开户行
@property (nonatomic,strong) NSMutableArray *bankArr;//所有开户行的简称
@property (nonatomic,strong) NSString *ticket;
@end

@implementation TieCardViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"填写个人信息";
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    NSString *banks = @"ICBC,CCB,ABC,BOC,COMM,CMB,CEB,GDB,CITIC,CIB,CMBC,HXB,CBHB,BCCB,BOS,CZB,EGBANK,PSBC,SHRCB,SPDB,SZPAB,BON";
    NSString *cardStr = @"工商银行(ICBC),建设银行(CCB),农业银行(ABC),中国银行(BOC),交通银行(COMM),招商银行(CMB),光大银行(CEB),广发银行(GDB),中信银行(CITIC),兴业银行(CIB),民生银行(CMBC),华夏银行(HXB),渤海银行(CBHB),北京银行(BCCB),上海银行(BOS),浙商银行(CZB),恒丰银行(EGBANK),邮政储蓄(PSBC),上海农商银行(SHRCB),浦东发展银行(SPDB),平安银行(SZPAB),南京银行(BON)";
    self.cardArr = [[cardStr componentsSeparatedByString:@","] mutableCopy];
    self.bankArr = [[banks componentsSeparatedByString:@","] mutableCopy];
    NSMutableIndexSet *index=[NSMutableIndexSet indexSet];
    [index addIndex:16];
    //[index addIndex:15];
    [index addIndex:18];
    //[index addIndex:12];
    //[index addIndex:13];
    //[index addIndex:4];
    [self.cardArr removeObjectsAtIndexes:index];
    [self.bankArr removeObjectsAtIndexes:index];
   
    // Do any additional setup after loading the view.
    
    [self createUI];
}

-(void)createUI{
    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/7)];
    firstView.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/3-WINSIZEWIDTH/30, firstView.height)];
    label.text = @"输入个人信息";
    label.textColor = YGrayColor;
    label.font = YFont(WINSIZEWIDTH/22);
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame), firstView.height/2-WINSIZEWIDTH/80, WINSIZEWIDTH/60, WINSIZEWIDTH/40)];
    image1.image = [UIImage imageNamed:@"jiantou"];
    [firstView addSubview:image1];
    UILabel *cardLal = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(image1.frame)+WINSIZEWIDTH/25, label.y, WINSIZEWIDTH/3-WINSIZEWIDTH/16, firstView.height)];
    cardLal.textColor = YRedColor;
    cardLal.font = label.font;
    cardLal.text = @"绑定银行卡";
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardLal.frame), image1.y, image1.width, image1.height)];
    image2.image = [UIImage imageNamed:@"jiantou"];
    UILabel *infoCerti = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(image2.frame)+WINSIZEWIDTH/25, label.y, WINSIZEWIDTH/4, firstView.height)];
    infoCerti.text = @"信息认证";
    infoCerti.textColor = YGrayColor;
    infoCerti.font = label.font;
    
    [firstView addSubview:label];
    [firstView addSubview:image1];
    [firstView addSubview:cardLal];
    [firstView addSubview:image2];
    [firstView addSubview:infoCerti];
    
    UIView *secondView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    secondView.backgroundColor = [UIColor whiteColor];
    UILabel *cardName = [[UILabel alloc]initWithFrame:CGRectMake(label.x, 0, WINSIZEWIDTH/2-WINSIZEWIDTH/8, label.height)];
    cardName.textColor = YBlackColor;
    cardName.text = @"储蓄卡卡号";
    cardName.font = label.font;
    self.CardField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardName.frame), 0, WINSIZEWIDTH/2, secondView.height)];
    self.CardField.font = YBFont(WINSIZEWIDTH/22);
    self.CardField.placeholder = @"请输入储蓄卡";
    self.CardField.delegate = self;
    self.CardField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    [secondView addSubview:cardName];
    [secondView addSubview:self.CardField];
    
    UIButton *countBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    countBtn.backgroundColor = [UIColor whiteColor];
    UILabel *countLal = [[UILabel alloc]initWithFrame:CGRectMake(label.x, 0, WINSIZEWIDTH/5, firstView.height)];
    countLal.text = @"开户行";
    countLal.textColor = YBlackColor;
    countLal.font = label.font;
//选择银行卡开户行按钮
    UIButton *countImage = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/7, 0, WINSIZEWIDTH/8, countBtn.height)];
    [countImage addTarget:self action:@selector(choose:) forControlEvents:(UIControlEventTouchUpInside)];
    [countImage setImage:[UIImage imageNamed:@"choose"] forState:(UIControlStateNormal)];
    // countImage.backgroundColor = YRedColor;
    [countBtn addSubview:countLal];
   // [countBtn addSubview:countImage];
   
    
    
    UIView *thirdView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(countBtn.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, secondView.height)];
    thirdView.backgroundColor = [UIColor whiteColor];
    UILabel *cardNum = [[UILabel alloc]initWithFrame:CGRectMake(cardName.x, 0, cardName.width, thirdView.height)];
    cardNum.text = @"银行预留手机号";
    cardNum.font = cardName.font;
    self.phoneField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardNum.frame), 0, self.CardField.width, thirdView.height)];
    self.phoneField.font = self.CardField.font;
    self.phoneField.placeholder = @"开户行预留手机号";
    self.phoneField.keyboardType = UIKeyboardTypeNumberPad;
#pragma mark -- 此处设置开户行列表
    UITextField *chooseCard = [[UITextField alloc]initWithFrame:CGRectMake(self.phoneField.x, 0, self.phoneField.width, self.phoneField.height)];
    chooseCard.placeholder = @"请选择您的开户行";
    chooseCard.font = self.phoneField.font;
    chooseCard.tag = 10000;
    [countBtn addSubview:chooseCard];
    [countBtn addSubview:countImage];
    self.cardTableView = [[UITableView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, CGRectGetMaxY(countBtn.frame), 0, 0)];
    self.cardTableView.dataSource = self;
    self.cardTableView.delegate = self;
    self.cardTableView.backgroundColor = [UIColor clearColor];
    [self.cardTableView setSeparatorInset:(UIEdgeInsetsZero)];
    [self.cardTableView setLayoutMargins:(UIEdgeInsetsZero)];
    [thirdView addSubview:cardNum];
    [thirdView addSubview:self.phoneField];
    
    UIView *forthView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(thirdView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEHEIGHT)];
    forthView.backgroundColor = [UIColor whiteColor];
//    UILabel *promptLal = [[UILabel alloc]initWithFrame:CGRectMake(label.x, WINSIZEWIDTH/70, WINSIZEWIDTH-WINSIZEWIDTH/10, label.height/2)];
//    promptLal.text = @"·身份成功之后，姓名不可更改";
//    promptLal.font = YBFont(WINSIZEWIDTH/27);
//    promptLal.textColor = YRedColor;
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(label.x, WINSIZEWIDTH/5, WINSIZEWIDTH-label.x*2, WINSIZEWIDTH/8)];
    [button setTitle:@"下一步" forState:(UIControlStateNormal)];
    button.backgroundColor = YRedColor;
    button.titleLabel.font = YBFont(WINSIZEWIDTH/20);
    [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    button.layer.cornerRadius = WINSIZEWIDTH/100;
    [button addTarget:self action:@selector(next:) forControlEvents:(UIControlEventTouchUpInside)];
   // [forthView addSubview:promptLal];
    [forthView addSubview:button];
    
    
    [self.view addSubview:countBtn];
    [self.view addSubview:forthView];
    [self.view addSubview:thirdView];
    [self.view addSubview:secondView];
    [self.view addSubview:firstView];
    [self.view addSubview:self.cardTableView];
}
//选择银行卡
-(void)choose:(UIButton *)sender{
    [self.view endEditing:YES];
    NSLog(@"--------------");
    sender.selected = !sender.selected;
    if (sender.selected) {
        [UIView animateWithDuration:0.5 animations:^{
            self.cardTableView.size = CGSizeMake(WINSIZEWIDTH/2, self.view.height - self.cardTableView.y);
        }];
    }else{
        [UIView animateWithDuration:0.5 animations:^{
            self.cardTableView.size = CGSizeMake(WINSIZEWIDTH/2, 0);
        }];
    }
}
-(void)next:(UIButton *)sender{
#warning 银行卡认证需要测试
    if (self.CardField.text.length<1) {
        [SLAlertView showAlertWithStatusString:@"银行卡号不得为空"];
//        [MBProgressHUD showError:@"银行卡号不得为空"];
        return;
    }else if(self.bank_name.length<1){
        [SLAlertView showAlertWithStatusString:@"请选择您的开户行"];
//        [MBProgressHUD showError:@"请选择您的开户行"];
        return;
    }else if(self.phoneField.text.length<11){
        [SLAlertView showAlertWithStatusString:@"请输入正确的手机号"];
//        [MBProgressHUD showError:@"请输入正确的手机号"];
        return;
    }
    InfoCertViewController *info = [[InfoCertViewController alloc]init];
    info.infoPhone = self.phoneField.text;
    info.cardNum = [self.CardField.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    info.bankName = self.bank_name;
    [self.navigationController pushViewController:info animated:YES];
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    //NSLog(@"-----textfield:%@  str:%@  %lu %ld",textField.text,string,textField.text.length,self.CardField.text.length);
    NSString *text = [textField text];
    
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789\b"];
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) {
        return NO;
    }
    text = [text stringByReplacingCharactersInRange:range withString:string];
    text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *newString = @"";
    while (text.length > 0) {
        NSString *subString = [text substringToIndex:MIN(text.length, 4)];
        newString = [newString stringByAppendingString:subString];
        if (subString.length == 4) {
            newString = [newString stringByAppendingString:@" "];
        }
        text = [text substringFromIndex:MIN(text.length, 4)];
    }
    
    newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
    
    if (newString.length >= 100) {
        return NO;
    }
    
    [textField setText:newString];
    
    return NO;
}
#pragma mark -- tableviewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.cardArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        [cell setLayoutMargins:(UIEdgeInsetsZero)];
        [cell setSeparatorInset:(UIEdgeInsetsZero)];
        cell.backgroundColor = YBackGrayColor;
        cell.textLabel.font = YBFont(WINSIZEWIDTH/22);
        cell.textLabel.textColor = YGrayColor;
    }
    cell.textLabel.text = self.cardArr[indexPath.row];
   // cell.backgroundColor = [UIColor colorWithHexString:self.c];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITextField *textField = (UITextField *)[self.view viewWithTag:10000];
    textField.text = self.cardArr[indexPath.row];
    self.bank_name = self.bankArr[indexPath.row];
    [UIView animateWithDuration:0.5 animations:^{
        self.cardTableView.frame = CGRectMake(tableView.x, tableView.y, tableView.width, 0);
    }];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
