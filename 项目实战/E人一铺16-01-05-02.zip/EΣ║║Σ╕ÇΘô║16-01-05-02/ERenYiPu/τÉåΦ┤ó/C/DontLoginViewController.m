//
//  ManageViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "DontLoginViewController.h"
#import "NoticeDetailViewController.h"
#import "ActionViewController.h"
#import "InvestViewController.h"
#import "InviteViewController.h"
#import "WritInfoViewController.h"
#import "AgoProtectVC.h"
#import "NewsCenterVC.h"
#import "SLWaterView.h"
#import "DetailViewController.h"
#import "NewsModel.h"
#import "RollingTextView.h"
//#import "FFFViewController.h"
#import "SignInViewController.h"

#import "LogInViewController.h"
#import "SDCycleScrollView.h"
#import "SLAlertView.h"
#import "RegisViewController.h"
#import "YDScrollView.h"
#import "UserData.h"
@interface DontLoginViewController () <SDCycleScrollViewDelegate>
{
    UILabel *allmoney;
    RollingTextView *textView;
    NSString *rateStr;
    YDScrollView *textScrollView;
    NSString *canInvestMoney;   //剩余可投金额
}
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UIButton *versionBtn;
@property(nonatomic,strong)UIButton *allMoney;//项目总金额
@property(nonatomic,strong)UIButton *profit;//收益
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)SLWaterView *waterView;
@property(nonatomic,strong)NSDictionary *productDic;//理财产品信息
@property(nonatomic,strong)NSMutableArray *productArray;//理财产品列表
@property(nonatomic,strong)NSMutableArray *newsArr;
@end

@implementation DontLoginViewController
#pragma mark -- 懒加载
#warning 这只是暂时的

-(NSMutableArray *)newsArr{
    
    if (!_newsArr) {
        _newsArr = [NSMutableArray array];
    }
    return _newsArr;
}
-(UIScrollView *)scrollView{
    
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, self.view.height - self.tabBarController.tabBar.height)];
        _scrollView.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
        _scrollView.contentSize = CGSizeMake(WINSIZEWIDTH, WINSIZEHEIGHT-self.tabBarController.tabBar.height+WINSIZEWIDTH/14);
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.bounces = YES;
        _scrollView.contentInset = UIEdgeInsetsMake(-20, 0, 20, 0);
    }
    return _scrollView;
}
//水中的数字
-(UIButton *)allMoney{
    
    if (!_allMoney) {
        _allMoney = [[UIButton alloc]initWithFrame:CGRectMake(0,0, WINSIZEWIDTH/16 * 5, WINSIZEWIDTH/16 * 5)];
        _allMoney.backgroundColor = [UIColor clearColor];
        //_allMoney.backgroundColor = [UIColor colorWithHexString:@"fe7171"];
        _allMoney.layer.cornerRadius = _allMoney.height/2;
        _allMoney.titleLabel.font = YBFont(WINSIZEWIDTH/15);
        [_allMoney setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [_allMoney setTitle:@"-%" forState:(UIControlStateNormal)];
        [_allMoney setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        
        //[_allMoney addTarget:self action:@selector(version:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _allMoney;
}
-(SLWaterView *)waterView{
    
    if (!_waterView) {
        _waterView = [[SLWaterView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/12, WINSIZEWIDTH/6, self.allMoney.width, self.allMoney.width)];
        _waterView.layer.borderWidth = 2;
        _waterView.layer.borderColor = [UIColor colorWithHexString:@"fe7171"].CGColor;
    }
    return _waterView;
}
//年化收益
-(UIButton *)profit{
    
    if (!_profit) {
        _profit = [UIButton buttonWithType:UIButtonTypeCustom];
        //_profit = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-CGRectGetMaxX(self.waterView.frame), self.waterView.y, self.allMoney.width, self.allMoney.height)];
        _profit.backgroundColor = [UIColor colorWithHexString:@"fcc457"];
        _profit.layer.cornerRadius = self.allMoney.height/2;
        [_profit setTitle:@"8.00%" forState:(UIControlStateNormal)];
        [_profit setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        _profit.titleLabel.font = self.allMoney.titleLabel.font;
    }
    return _profit;
}
//版本按钮
-(UIButton *)versionBtn{
    
    if (!_versionBtn) {
        _versionBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, WINSIZEWIDTH/2, WINSIZEWIDTH/18)];
        _versionBtn.titleLabel.font = YBFont(WINSIZEWIDTH/28);
        
        [_versionBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
        //[_versionBtn setTitleColor:[UIColor colorWithHexString:@"75eab0"] forState:(UIControlStateNormal)];
        [_versionBtn setTitle:@"铺宝宝第-期" forState:(UIControlStateNormal)];
        _versionBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft  ;
        // _versionBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
        
    }
    return _versionBtn;
}


-(UIImageView *)imageView{
    
    if (!_imageView) {
        
        _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/3+WINSIZEWIDTH/19)];
        _imageView.backgroundColor = YBlackColor;
    }
    return _imageView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
//    NSArray *familyNames = [UIFont familyNames];
//    for( NSString *familyName in familyNames ){
//        printf( "Family: %s \n", [familyName UTF8String] );
//        NSArray *fontNames = [UIFont fontNamesForFamilyName:familyName];
//        for( NSString *fontName in fontNames ){
//            printf( "\tFont: %s \n", [fontName UTF8String] );
//        }
//    }
    
    
    [self createUI];
    //获取理财信息
    [self getProData];
    // Do any additional setup after loading the view.
}
-(void)createUI{
    //首页轮播图
    NSArray *images = @[[UIImage imageNamed:@"lunbo1"],
                        [UIImage imageNamed:@"lunbo2"],
                        [UIImage imageNamed:@"lunbo3"]
                        ];
    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/2) imagesGroup:images];
    
    cycleScrollView.infiniteLoop = YES;
    cycleScrollView.delegate = self;
    cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleAnimated;
    [self.scrollView addSubview:cycleScrollView];
    
    // self.view.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
    [self.view addSubview:self.scrollView];
    UIView *secondView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(cycleScrollView.frame)+10, WINSIZEWIDTH - 20, WINSIZEWIDTH/8-1)];
    secondView.backgroundColor = [UIColor whiteColor];
    secondView.layer.cornerRadius = 3;
    //UIButton *newsbutton = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, WINSIZEWIDTH/100, secondView.width/2, secondView.height)];
    //铃铛
    UIImageView *lingdang = [[UIImageView alloc]initWithFrame:CGRectMake((WINSIZEWIDTH - 30) / 18 - 3, secondView.height / 3, secondView.height / 3, secondView.height / 3)];
    lingdang.image = [UIImage imageNamed:@"xiaoxituisong"];
    [secondView addSubview:lingdang];
#pragma mark - 新闻轮播 修改了
    //新闻轮播
    textView = [[RollingTextView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lingdang.frame) + 5, 0, secondView.width - CGRectGetMaxX(lingdang.frame) * 2 - 8, secondView.height)];
    //[secondView addSubview:textView];
    
    textView.backgroundColor = [UIColor whiteColor];
    textView.textColor = YGrayColor;
    textView.speed = 1;
    //textView.textArr = @[@"消息推送新闻"];
    
    textScrollView = [[YDScrollView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lingdang.frame) + 5, 0, secondView.width - CGRectGetMaxX(lingdang.frame) * 2 - 5, secondView.height)];
    [secondView addSubview:textScrollView];
    [textScrollView createScrllWith:@"E人一铺" speed:kSpeed];
    
    UIButton *newsBt = [UIButton buttonWithType:UIButtonTypeCustom];
    newsBt.frame = CGRectMake(0, 0, CGRectGetMaxX(textScrollView.frame) - 5, secondView.height);
    newsBt.backgroundColor = [UIColor clearColor];
    [newsBt addTarget:self action:@selector(newsPush:) forControlEvents:UIControlEventTouchUpInside];
    [secondView addSubview:newsBt];
    
    //添加后面的 三个点
    //竖线
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(textScrollView.frame ) + 4, 8, 1.5, secondView.height - 16)];
    lineView.backgroundColor = [UIColor colorWithHexString:@"d8d8d8"];
    [secondView addSubview:lineView];
    
    //三个点
    UIButton *image = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lineView.frame) + 1,0, secondView.width - CGRectGetMaxX(lineView.frame) - 2, secondView.height)];
    
    [image setImage:[UIImage imageNamed:@"dian"] forState:(UIControlStateNormal)];
    [image addTarget:self action:@selector(moreNews:) forControlEvents:(UIControlEventTouchUpInside)];
    
    [secondView addSubview:image];
    
    //铺宝宝
//    UIView *forthView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/40, WINSIZEWIDTH - 20, WINSIZEWIDTH-WINSIZEWIDTH/12)];
    UIView *forthView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/40, WINSIZEWIDTH - 20, WINSIZEHEIGHT - CGRectGetMaxY(secondView.frame) - WINSIZEWIDTH / 40 - WINSIZEWIDTH / 20)];
    forthView.backgroundColor = [UIColor whiteColor];
    forthView.layer.cornerRadius = 3;
    
    [forthView addSubview:self.versionBtn];
    [self.versionBtn addTarget:self action:@selector(versionBtnClick) forControlEvents:UIControlEventTouchUpInside];
    
    
    //详情按钮
    UIButton *detailBt = [UIButton buttonWithType:UIButtonTypeCustom];
    detailBt.frame = CGRectMake(CGRectGetMaxX(forthView.frame) - 150, CGRectGetMinY(self.versionBtn.frame), 150, self.versionBtn.height);
    [detailBt setTitleColor:YGrayColor forState:UIControlStateNormal];
    [detailBt setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
    [detailBt setTitle:@"详情 >" forState:UIControlStateNormal];
    
    //[detailBt addTarget:self action:@selector(version:) forControlEvents:UIControlEventTouchUpInside];
    
    [detailBt setTitleEdgeInsets:UIEdgeInsetsMake(0, 50, 0, -10)];
    
    detailBt.titleLabel.font = self.versionBtn.titleLabel.font;
    [forthView addSubview:detailBt];
    
    //加一根线
    UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.versionBtn.frame), CGRectGetMaxY(self.versionBtn.frame) + 5, forthView.width - CGRectGetMinX(self.versionBtn.frame) * 2, 1)];
    line1.backgroundColor = [UIColor colorWithHexString:@"ececec"];
    
    [forthView addSubview:line1];
    
    //水 按钮
    
    
    [self.waterView addSubview:self.allMoney];
    [forthView addSubview:self.waterView];
    
    
    self.profit.frame = CGRectMake(forthView.width - CGRectGetMaxX(self.waterView.frame), self.waterView.y, self.allMoney.width, self.allMoney.height);
    
    [forthView addSubview:self.profit];
    
    allmoney = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.profit.frame)+WINSIZEWIDTH/50, self.profit.width+self.waterView.x*2, WINSIZEWIDTH/10)];
    allmoney.text = @"项目总金额:-万";
    allmoney.font = YFont(WINSIZEWIDTH/20);
    allmoney.textColor = YGrayColor;
    allmoney.textAlignment = NSTextAlignmentCenter;
    allmoney.userInteractionEnabled = YES;
    [forthView addSubview:allmoney];
    
    //添加按钮
    UIButton *moneyBt = [UIButton buttonWithType:UIButtonTypeCustom];
    moneyBt.frame = allmoney.bounds;
    [allmoney addSubview:moneyBt];
    moneyBt.backgroundColor = [UIColor clearColor];
    //[moneyBt addTarget:self action:@selector(version:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *profitLab = [[UILabel alloc]initWithFrame:CGRectMake(self.profit.x-self.waterView.x, allmoney.y, allmoney.width, allmoney.height)];
    profitLab.textAlignment = NSTextAlignmentCenter;
    profitLab.font = allmoney.font;
    profitLab.text = @"年化收益";
    profitLab.textColor = YGrayColor;
    [forthView addSubview:profitLab];
    
    
    //立即投资按钮
//    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/18, CGRectGetMaxY(allmoney.frame)+WINSIZEWIDTH/15, forthView.width-WINSIZEWIDTH/9, WINSIZEWIDTH/9-WINSIZEWIDTH/100)];
    CGFloat btHeight = 0.0;
    if (WINSIZEHEIGHT < 481) {
        btHeight = forthView.height - WINSIZEWIDTH / 9 - WINSIZEWIDTH / 40;
    }else if(WINSIZEHEIGHT > 481 && WINSIZEHEIGHT < 569){
        btHeight = forthView.height - WINSIZEWIDTH / 8 - WINSIZEWIDTH / 14;
    }else if (WINSIZEHEIGHT > 569){
        btHeight = forthView.height - WINSIZEWIDTH / 9 - WINSIZEWIDTH / 10;
    }
    
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/18, btHeight, forthView.width-WINSIZEWIDTH/9, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    investBtn.backgroundColor = YRedColor;
    [investBtn setTitle:@"登    录" forState:(UIControlStateNormal)];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/13);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius=WINSIZEWIDTH/100;
    

#warning mark -- 设置水的深度
    self.waterView.waterPercent = 0.0;

    [self.scrollView addSubview:secondView];
    [self.scrollView addSubview:forthView];

    [forthView addSubview:investBtn];

    
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -- button
//更多的新闻（三个点）
-(void)moreNews:(UIButton *)sender{
    
    NewsCenterVC *newsVC = [[NewsCenterVC alloc]init];
    newsVC.newsArr = self.newsArr;
    [self.navigationController pushViewController:newsVC animated:YES];
}
//消息推送
-(void)newsPush:(UIButton *)sender{

    PublicViewController *Publec = [[PublicViewController alloc]init];
    NewsModel *model = self.newsArr[0];
    Publec.idName = @"news_id";
    Publec.contentText = model.news_content;
    Publec.contentTitleText = model.news_title;
    Publec.contentId = model.news_id;
    Publec.pageTitle = model.news_title;
    [self.navigationController pushViewController:Publec animated:YES];
}


-(void)invest:(UIButton *)sender{
    
    [SLAlertView showAlertWithRegisterWithRegisterBlock:^{
        [UIApplication sharedApplication].keyWindow.rootViewController = [RegisViewController new];
    } LoginBlock:^{
        [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];;
    }];
    
    //    InvestViewController *investVC = [[InvestViewController alloc]init];
    //    [self.navigationController pushViewController:investVC animated:YES];
    NSLog(@"立即投资");
}




//查看投资项目
-(void)versionBtnClick{
    
    DetailViewController *detail = [[DetailViewController alloc]init];
    detail.productDic = self.productDic;
    detail.productArray = self.productArray;
    detail.rateStr = rateStr;
    detail.canInvestMoney = canInvestMoney;
    [self.navigationController pushViewController:detail animated:YES];
}
//获取理财产品信息跟新闻消息
-(void)getProData {
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\"}",tokoen];
    [IKHttpTool postWithURL:@"getLastProduct" params:@{@"json":param} success:^(id json) {
        self.productDic = [NSDictionary dictionary];
        NSDictionary *dic = json[@"data"];
        
        NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
        NSString *productName = [userDefaults objectForKey:@"productNameDefault"];
        if (productName != nil) {
            if (![productName isEqualToString:dic[@"product_name"]]) {
                NSString *productName = dic[@"product_name"];
                [userDefaults setObject:productName forKey:@"productNameDefault"];
                [[UserData sharedUserData] refreshProducts];
            }
        } else {
            NSString *productName = dic[@"product_name"];
            [userDefaults setObject:productName forKey:@"productNameDefault"];
            [[UserData sharedUserData] refreshProducts];
        }
        
        
        self.productDic = dic;
        [self setData:dic];
    } failure:^(NSError *error) {
        
    }];
    
    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"newsArrDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天
    if ([dateString isEqualToString:nowDataString]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].newsArr) {
            self.newsArr = [NSMutableArray array];
            for (NSDictionary *dic in [UserData sharedUserData].newsArr) {
                NewsModel *news = [[NewsModel alloc]init];
                news = [NewsModel objectWithKeyValues:dic];
                [self.newsArr addObject:news];
            }
            //textView.textArr = @[[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"]];
            if (self.newsArr.count > 0) {
                NSLog(@"loacl  [[self.newsArr objectAtIndex:0]valueForKey:] =======  %@",[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"]);
                [textScrollView createScrllWith:[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"] speed:kSpeed];
            }
            return;
        }
    } else {
        NSString *str = [NSString stringWithFormat:@"{\"page\":\"1\"}"];
        [IKHttpTool postWithURL:@"getNews" params:@{@"json":str} success:^(id json) {
            
            NSLog(@"请求newsData数据");
            
            [userDefaults setObject:dateString forKey:@"newsArrDateString"];
            [userDefaults synchronize];
            
            NSArray *array = json[@"data"];
            NSLog(@"%@",array);
            if (array) {
                [UserData sharedUserData].newsArr = array;
            }
            self.newsArr = [NSMutableArray array];
            for (NSDictionary *dic in array) {
                NewsModel *news = [[NewsModel alloc]init];
                news = [NewsModel objectWithKeyValues:dic];
                [self.newsArr addObject:news];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                //textView.textArr = @[[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"]];
                if (self.newsArr.count > 0) {
                    NSLog(@"[[self.newsArr objectAtIndex:0]valueForKey:] =======  %@",[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"]);
                    [textScrollView createScrllWith:[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"] speed:kSpeed];
                }
            });
            NSLog(@"------news:%lu",(unsigned long)self.newsArr.count);
        } failure:^(NSError *error) {
            
        }];
    }
    
    
}
//赋值
-(void)setData:(NSDictionary *)dic{
    
    NSString *allmoneyText = [NSString stringWithFormat:@"项目总金额:%.0f万",[dic[@"product_sum"] doubleValue] / 10000];
    
    allmoney.text = allmoneyText;
    
    
    NSString *productstr = [NSString stringWithFormat:@"%f",[dic[@"product_sum"] doubleValue] - [dic[@"product_now"] doubleValue]];
    double productsum = yTwoPointDouble(productstr);
    canInvestMoney = [NSString stringWithFormat:@"%.2f",productsum];
    
    //0 < 475/1000000 < 0.01%
    
    //NSString *rateStr = [NSString stringWithFormat:@"%.2f",(];
    
    double rateNum = 0.0;
    
    rateNum = [dic[@"product_now"] doubleValue]/[dic[@"product_sum"] doubleValue] * 100;
    
    if (rateNum > 0 && rateNum <0.01) {
        rateNum = 0.01;
    }
    rateStr = [NSString stringWithFormat:@"%.2f%%",rateNum];
    
    [self.allMoney setTitle:rateStr forState:(UIControlStateNormal)];
    
    //水的高度
    NSLog(@"水的高度 ================== %f",rateNum);
    self.waterView.waterPercent = rateNum / 100;
    
    //    [self.allMoney setTitle:dic[@"product_sum"] forState:(UIControlStateNormal)];
    NSString *profitString = [[NSString stringWithFormat:@"%.2lf" , [dic[@"product_rate"] doubleValue]] stringByAppendingString:@"%"];
    [self.profit setTitle:profitString forState:UIControlStateNormal];
    [self.versionBtn setTitle:dic[@"product_name"] forState:(UIControlStateNormal)];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [textView rollingTextViewAnimationStart];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [textView rollingTextViewAnimationPause];
    
}



#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    NSLog(@"---点击了第%ld张图片", index);
}

/*
(long) #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
