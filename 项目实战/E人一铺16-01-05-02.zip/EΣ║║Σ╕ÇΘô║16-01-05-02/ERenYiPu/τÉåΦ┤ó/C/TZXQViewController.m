//
//  TZXQViewController.m
//  TZXQ
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "TZXQViewController.h"
#import "TZXQCell.h"

@interface TZXQViewController () <UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSArray * infoArray;
@property (assign, nonatomic) CGFloat cellHeight;

@end

@implementation TZXQViewController

- (NSArray *)infoArray {
    if (_infoArray == nil) {
        _infoArray = @[
                       @"投资项目:",
                       @"投资金额:",
                       @"投资时间:",
                       @"投资状态:",
                       ];
    }
    return _infoArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
 
    
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    if (screenWidth == 375) {
        self.cellHeight = -45;
    } else if (screenWidth == 414) {
        self.cellHeight = -60;
    } else if (screenWidth == 320) {
        self.cellHeight = -40;
    }
    
    [self.view addSubview:self.tableView];
    self.navigationItem.title = @"投资详情";

    self.tableView.estimatedRowHeight = 60;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.contentInset = UIEdgeInsetsMake(5, 0, -5, 0);
    

    
}

//- (void)setModels:(NSArray *)models {
//    _models = models;
//    [self.tableView reloadData];
//}

- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.models.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    TZXQCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TZXQCell"];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"TZXQTableViewCell" owner:nil options:nil] lastObject];
    }
    cell.titleLabel.text = self.infoArray[indexPath.section];
    cell.contextLabel.text = self.models[indexPath.section];
    cell.titleLabel.textColor = YGrayColor;
    cell.contextLabel.textColor = YGrayColor;
    cell.labelHeightCons.constant = self.cellHeight;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 5;
}


@end
