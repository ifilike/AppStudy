//
//  DetailViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/27.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "DetailViewController.h"
#import "InvestViewController.h"
#import "AgoProtectVC.h"
#import "TZXQViewController.h"
#import "AgoProtectVC.h"
#import "ContractViewController.h"
#import "SafeguardViewController.h"
#import "PublicDetailViewController.h"
#import "SLAlertView.h"
#import "LogInViewController.h"
#import "RegisViewController.h"
@interface DetailViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UIButton *investBtn;
    
}
@property(nonatomic,strong)UITableView *tableview;
@end

@implementation DetailViewController
-(UITableView *)tableview{

    if (!_tableview) {
        _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, self.view.height)];
        _tableview.delegate = self;
        _tableview.dataSource = self;
        _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableview.backgroundColor = YBackGrayColor;
        _tableview.bounces = NO;
        _tableview.tableFooterView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/3)];
        _tableview.tableFooterView.backgroundColor = YBackGrayColor;
        investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEWIDTH/16, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
//        if ([self.rateStr floatValue] >= 100) {
//            investBtn.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
//        }else{
//            investBtn.backgroundColor = YRedColor;
//        }
        
        NSString *status = _productDic[@"product_status"];
        //status = @"0";
        if ([status isEqualToString:@"1"]) {
            investBtn.enabled = true;
            [investBtn setBackgroundImage:[UIImage imageNamed:@"redbackimg"] forState:(UIControlStateNormal)];
            
        }else if([status isEqualToString:@"0"]){
            investBtn.enabled = false;
            [investBtn setBackgroundImage:[UIImage imageNamed:@"graybackimg"] forState:(UIControlStateNormal)];
        }
        
        investBtn.layer.cornerRadius = WINSIZEWIDTH/80;
        [investBtn setTitle:@"立即投资" forState:(UIControlStateNormal)];
        [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
        investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/19);
        [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
        investBtn.layer.cornerRadius=WINSIZEWIDTH/100;
        [_tableview.tableFooterView addSubview:investBtn];
    }
    return _tableview;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"详情";
    [self.view addSubview:self.tableview];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"查看往期" style:(UIBarButtonItemStyleDone) target:self action:@selector(lookAgo:)];
    // Do any additional setup after loading the view.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 7;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.section==0) {
        return WINSIZEWIDTH/3.2;
    }else if(indexPath.section == 6){
    
        return WINSIZEWIDTH/4;
    }else{
        return WINSIZEWIDTH/8;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    if (section==6) {
        return 0;
    }
    return WINSIZEWIDTH/35;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

       UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:@"cell"];;
   cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section==0) {
        UILabel *viersion = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/30, WINSIZEWIDTH / 4 * 3, WINSIZEWIDTH/20)];
        viersion.text = self.productDic[@"product_name"];
        viersion.textColor = YRedColor;
        viersion.font = YFont(WINSIZEWIDTH/20);
        //总金额
        UILabel *moeny = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(viersion.frame)+WINSIZEWIDTH/20, WINSIZEWIDTH/3.6, WINSIZEWIDTH/15)];
        moeny.text = [NSString stringWithFormat:@"%.0f万",[self.productDic[@"product_sum"] doubleValue] / 10000];
        moeny.font = YFont(WINSIZEWIDTH/15);
        moeny.textColor = YRedColor;
        moeny.textAlignment = NSTextAlignmentCenter;
        UILabel *moenyLa = [[UILabel alloc]initWithFrame:CGRectMake(moeny.x, CGRectGetMaxY(moeny.frame)+WINSIZEWIDTH/100, moeny.width, moeny.height)];;
        moenyLa.textAlignment = NSTextAlignmentCenter;
        moenyLa.text = @"总金额";
        moenyLa.font = YFont(WINSIZEWIDTH/22);
        moenyLa.textColor = YGrayColor;
        //年化收益
        UILabel *prift = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(moeny.frame), moeny.y, WINSIZEWIDTH-moenyLa.width*2, moeny.height)];
        CGFloat abc = yTwoPointDouble(self.productDic[@"product_rate"]);
        prift.text = [NSString stringWithFormat:@"%.2lf%%",abc];
        prift.textColor = YRedColor;
        prift.font = moeny.font;
        prift.textAlignment = NSTextAlignmentCenter;
        UILabel *priftLa = [[UILabel alloc]initWithFrame:CGRectMake(prift.x, moenyLa.y, prift.width, prift.height)];
        priftLa.textAlignment = NSTextAlignmentCenter;
        priftLa.font = moenyLa.font;
        priftLa.text = @"年化收益";
        priftLa.textColor = YGrayColor;
        UILabel *person = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(priftLa.frame), moeny.y, moeny.width, moeny.height)];
        person.textColor = YRedColor;
        person.text = [NSString stringWithFormat:@"%d",[self.productDic[@"product_people"]intValue]] ;
        person.font = moeny.font;
        person.textAlignment = NSTextAlignmentCenter;
        UILabel *personLa = [[UILabel alloc]initWithFrame:CGRectMake(person.x, moenyLa.y, person.width, person.height)];
        personLa.text = @"已投人数";
        personLa.textAlignment = NSTextAlignmentCenter;
        personLa.textColor = YGrayColor;
        personLa.font = priftLa.font;
        UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(moeny.frame), moeny.y, 2, moeny.height*2)];
        view1.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
        UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(prift.frame), view1.y, 2, view1.height)];
        view2.backgroundColor = view1.backgroundColor;
        [cell addSubview:viersion];
        [cell addSubview:moeny];
        [cell addSubview:moenyLa];
        [cell addSubview:prift];
        [cell addSubview:priftLa];
        [cell addSubview:person];
        [cell addSubview:personLa];
        [cell addSubview:view1];
        [cell addSubview:view2];
    }else if(indexPath.section==1){
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/4, WINSIZEWIDTH/16-WINSIZEWIDTH/150, WINSIZEWIDTH/2, WINSIZEWIDTH/75)];
        view.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
        UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, view.width * [self.rateStr doubleValue] / 100, view.height)];
        view2.backgroundColor = YRedColor;
        
        [view addSubview:view2];
        [cell addSubview:view];
        cell.textLabel.text = @"投标进度";
        CGFloat a = yTwoPointDouble(self.rateStr);
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%.2lf%%",a];
    }else if(indexPath.section==2){
        cell.textLabel.text = @"剩余可投金额";
        
        CGFloat abc = yTwoPointDouble(self.canInvestMoney);
        
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%.2lf 元",abc] ;
    }else if(indexPath.section==3){
        cell.textLabel.text = @"起息时间";
        cell.detailTextLabel.text = @"当天投资当日计息";
    }else if(indexPath.section == 4){
        
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.textLabel.text = @"保障方式";
        cell.detailTextLabel.text = @"全额本息保障";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else if(indexPath.section == 5){
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.textLabel.text = @"债权示意";
        cell.detailTextLabel.text = @"查看合同";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else if(indexPath.section==6){
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(WINSIZEWIDTH/30, WINSIZEWIDTH/50, WINSIZEWIDTH/4, WINSIZEWIDTH/4);
        [button setImage:[UIImage imageNamed:@"shouyi"] forState:(UIControlStateNormal)];
        [button setTitleColor:YRedColor forState:(UIControlStateNormal)];
        [button setTitle:@"至高收益" forState:(UIControlStateNormal)];
        button.imageEdgeInsets = UIEdgeInsetsMake(0, button.width/3.5, button.height/1.5, 0);
        button.titleLabel.font = YFont(WINSIZEWIDTH/27);
        [button setTitleColor:YGrayColor forState:(UIControlStateNormal)];
        button.titleEdgeInsets = UIEdgeInsetsMake(0, -button.width/3, 0, 0);
        [button setTitleColor:[UIColor colorWithHexString:@"ececec"] forState:(UIControlStateHighlighted)];
        [button addTarget:self action:@selector(shouyiBtClick) forControlEvents:UIControlEventTouchUpInside];
        UILabel *lael = [[UILabel alloc]initWithFrame:CGRectMake(button.x, button.height-WINSIZEWIDTH/15, button.width, WINSIZEWIDTH/28)];
        lael.textColor = YGrayColor;
        lael.font = YFont(WINSIZEWIDTH/30);
        lael.text = @"年化收益8%起";
        lael.textAlignment = NSTextAlignmentCenter;
        
        UIButton *button2 = [UIButton buttonWithType:(UIButtonTypeCustom)];
        button2.frame = CGRectMake(WINSIZEWIDTH/2-button.width/2, button.y, button.width, button.height);
        [button2 setTitleColor:YGrayColor forState:(UIControlStateNormal)];
        [button2 setTitle:@"绝低风险" forState:(UIControlStateNormal)];
        [button2 setTitleColor:[UIColor colorWithHexString:@"ececec"] forState:(UIControlStateHighlighted)];
        button2.titleLabel.font = button.titleLabel.font;
        [button2 setImage:[UIImage imageNamed:@"fengxian"] forState:(UIControlStateNormal)];
        button2.imageEdgeInsets = button.imageEdgeInsets;
        button2.titleEdgeInsets = button.titleEdgeInsets;
        [button2 addTarget:self action:@selector(fengxianBtClick) forControlEvents:UIControlEventTouchUpInside];
        
        UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(button2.x, lael.y, lael.width, lael.height)];
        label2.textAlignment = NSTextAlignmentCenter;
        label2.text = @"新浪支付托管";
        label2.textColor = YGrayColor;
        label2.font = lael.font;
        
        UIButton *button3= [UIButton buttonWithType:(UIButtonTypeCustom)];
        button3.frame = CGRectMake(WINSIZEWIDTH-CGRectGetMaxX(button.frame), button.y, button.width, button.height);
        [button3 setTitleColor:YGrayColor forState:(UIControlStateNormal)];
        [button3 setTitleColor:[UIColor colorWithHexString:@"ececec"] forState:(UIControlStateHighlighted)];
        button3.titleLabel.font = button2.titleLabel.font;
        [button3 setImage:[UIImage imageNamed:@"tixian1"] forState:(UIControlStateNormal)];
        button3.imageEdgeInsets = button2.imageEdgeInsets;
        button3.titleEdgeInsets = button2.titleEdgeInsets;
        [button3 setTitle:@"随时提现" forState:(UIControlStateNormal)];
        [button3 addTarget:self action:@selector(tixianBtClick) forControlEvents:UIControlEventTouchUpInside];
        
        UILabel *label3 = [[UILabel alloc]initWithFrame:CGRectMake(button3.x, label2.y, label2.width, label2.height)];
        label3.textColor = label2.textColor;
        label3.font = label2.font;
        label3.text = @"24小时内到账";
        label3.textAlignment = NSTextAlignmentCenter;
        
        [cell addSubview:button3];
        [cell addSubview:label3];
        [cell addSubview:button2];
        [cell addSubview:label2];
        [cell addSubview:button];
        [cell addSubview:lael];

    }
    cell.textLabel.font = YFont(WINSIZEWIDTH/22);
    cell.detailTextLabel.font = YFont(WINSIZEWIDTH/22);
    cell.textLabel.textColor = YGrayColor;
    cell.detailTextLabel.textColor = YGrayColor;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 5) {
        ContractViewController *contractVC = [[ContractViewController alloc]init];
        [self.navigationController pushViewController:contractVC animated:YES];
    }else if(indexPath.section == 4){
        SafeguardViewController *safeguardVC = [[SafeguardViewController alloc]init];
        [self.navigationController pushViewController:safeguardVC animated:YES];
    }
    
}

//查看往期
-(void)lookAgo:(UIBarButtonItem *)sender{

    AgoProtectVC *agoVC = [[AgoProtectVC alloc]init];
    
    [self.navigationController pushViewController:agoVC animated:YES];
}
//立即投资
-(void)invest:(UIButton *)sender{
    NSLog(@"%.2f",[self.rateStr floatValue]);
    if ([self.rateStr floatValue] >= 100) {
        [SLAlertView showAlertWithStatusString:@"该期已满,请等待下期..."];
        return;
    }
    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    if (token.length<10) {
        [SLAlertView showAlertWithRegisterWithRegisterBlock:^{
            [UIApplication sharedApplication].keyWindow.rootViewController = [RegisViewController new];
        } LoginBlock:^{
            [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];;
        }];
        
    }else{
        InvestViewController *investVC = [[InvestViewController alloc]init];
        investVC.productDic = self.productDic;
        investVC.rateStr = self.rateStr;
        investVC.canInvestMoney = self.canInvestMoney;
        [self.navigationController pushViewController:investVC animated:YES];
    }
   
}

#pragma mark - 三个按钮
- (void)shouyiBtClick
{
    PublicDetailViewController *shouyiVC = [[PublicDetailViewController alloc]init];
    shouyiVC.comePage = 1;
    shouyiVC.title = @"至高收益";
    [self.navigationController pushViewController:shouyiVC animated:YES];
}

- (void)fengxianBtClick
{
    PublicDetailViewController *shouyiVC = [[PublicDetailViewController alloc]init];
    shouyiVC.comePage = 2;
    shouyiVC.title = @"绝低风险";
    [self.navigationController pushViewController:shouyiVC animated:YES];
}

- (void)tixianBtClick
{
    PublicDetailViewController *shouyiVC = [[PublicDetailViewController alloc]init];
    shouyiVC.comePage = 3;
    shouyiVC.title = @"随时提现";
    [self.navigationController pushViewController:shouyiVC animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
