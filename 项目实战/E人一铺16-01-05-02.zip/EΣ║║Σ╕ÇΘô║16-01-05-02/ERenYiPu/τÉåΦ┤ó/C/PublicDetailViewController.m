//
//  PublicDetailViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "PublicDetailViewController.h"

@interface PublicDetailViewController ()

@end

@implementation PublicDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UITextView *label = [[UITextView alloc]initWithFrame:CGRectMake(10, 20, self.view.bounds.size.width - 20, WINSIZEHEIGHT - 30)];
    label.textAlignment = NSTextAlignmentLeft;
    label.textColor = YGrayColor;
    label.editable = NO;
    label.font = YFont(16);

    [self.view addSubview:label];
    
    NSString *text1 = @"“E人一铺”通过对商业地产地段、人口、交通、商铺经营情况进行层层筛选确保综合回报率年化收益达到8%以上的优质商业地产债权。";
    NSString *text2 = @"北京中财银发投资基金公司2000万元风险保证金新浪支付全程托管，阳光保险全额财险赔付，融资性担保公司担保。";
    NSString *text3 = @"债权转让方便，资金来去自由，当天提现，当天到账，确保投资人资金流动。";
    
    if (self.comePage == 1) {
        label.text = text1;
    }else if (self.comePage == 2){
        label.text = text2;
    }else if (self.comePage == 3){
        label.text = text3;
    }
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
