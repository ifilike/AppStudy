//
//  DetailViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/27.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (nonatomic,strong)NSDictionary *productDic;//最新一期 投资项目详情信息
@property (nonatomic,strong)NSString *rateStr;  //投标进度比率
@property (nonatomic,strong)NSArray *productArray;
@property (nonatomic,strong)NSString *canInvestMoney;  //剩余可投金额

@end
