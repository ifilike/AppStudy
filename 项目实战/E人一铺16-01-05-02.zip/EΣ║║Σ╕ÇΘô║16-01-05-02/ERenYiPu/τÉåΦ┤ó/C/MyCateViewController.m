//
//  MyCateViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/17.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MyCateViewController.h"
#import "SLAlertView.h"

@interface MyCateViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@end

@implementation MyCateViewController
-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/30, WINSIZEWIDTH, self.view.height - WINSIZEWIDTH/30)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = YBackGrayColor;
        [_tableView setLayoutMargins:(UIEdgeInsetsZero)];
        [_tableView setSeparatorInset:(UIEdgeInsetsZero)];
        _tableView.tableFooterView = [[UIView alloc]init];
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的卡券";
    self.view.backgroundColor = YBackGrayColor;
    [self.view addSubview:self.tableView];
    [self getdata];
    // Do any additional setup after loading the view.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/6;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH- WINSIZEWIDTH/4, WINSIZEWIDTH/24, WINSIZEWIDTH/5, WINSIZEWIDTH/12)];
        button.tag = 10000+indexPath.row;
        button.backgroundColor = YRedColor;
        button.layer.cornerRadius = WINSIZEWIDTH/80;
        [button addTarget:self action:@selector(useCard:) forControlEvents:(UIControlEventTouchUpInside)];
        [button setTitle:@"立即使用" forState:(UIControlStateNormal)];
        [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        button.titleLabel.font = YBFont(WINSIZEWIDTH/23);
        [button setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
        cell.textLabel.font = YBFont(WINSIZEWIDTH/18);
        [cell.contentView addSubview:button];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.textColor = [UIColor colorWithHexString:@"fcc457"];
    }
    cell.textLabel.text = @"白金加息卡";

    return cell;
}

-(void)useCard:(UIButton *)sender{
   // [SLAlertView showAlertWithStatusString:@"aaaaaa"];
 //   [MBProgressHUD showError:@"aaaaaa"];
}
-(void)getdata{

}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{

    [cell setSeparatorInset:(UIEdgeInsetsZero)];
    [cell setLayoutMargins:(UIEdgeInsetsZero)];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
