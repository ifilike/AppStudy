//
//  ChooseCardVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/14.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ChooseCardVC.h"

@interface ChooseCardVC ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;

@end

@implementation ChooseCardVC
-(UITableView *)tableView{
    
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/30, WINSIZEWIDTH, self.view.height)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]init];
        if ([_tableView respondsToSelector:@selector(setSeparatorInset:)]) {
            [_tableView setSeparatorInset:(UIEdgeInsetsZero)];
        }
        if ([_tableView respondsToSelector:@selector(setLayoutMargins:)]) {
            [_tableView setLayoutMargins:(UIEdgeInsetsZero)];
        }
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        _tableView.backgroundColor = YBackGrayColor;
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选择支付方式";
    self.view.backgroundColor = YBackGrayColor;
    [self.view addSubview:self.tableView];
    // Do any additional setup after loading the view.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 4;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return WINSIZEWIDTH/6+WINSIZEWIDTH/100;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    //银行卡标识
    UIImageView *symbolView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, WINSIZEWIDTH/12-WINSIZEWIDTH/20+WINSIZEWIDTH/200, WINSIZEWIDTH/10, WINSIZEWIDTH/10)];
    symbolView.image = [UIImage imageNamed:@"headimage"];
    symbolView.layer.cornerRadius = symbolView.height/2;
    symbolView.layer.masksToBounds = YES;
    //银行卡名字
    UILabel *cardName = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(symbolView.frame)+WINSIZEWIDTH/20, WINSIZEWIDTH/25, WINSIZEWIDTH/2, WINSIZEWIDTH/20)];
    cardName.text = @"北京农商银行";
    cardName.textColor = YBlackColor;
    cardName.font = YFont(WINSIZEWIDTH/20);
    //银行卡尾号
    UILabel *cardNum = [[UILabel alloc]initWithFrame:CGRectMake(cardName.x, CGRectGetMaxY(cardName.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH/2, WINSIZEWIDTH/30)];
    cardNum.text = @"尾号2161储蓄卡";
    cardNum.textColor = YGrayColor;
    cardNum.font = YFont(WINSIZEWIDTH/30);
    //选择标识
    UIImageView *chooseImage = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/6, WINSIZEWIDTH/18, WINSIZEWIDTH/17, WINSIZEWIDTH/20)];
    chooseImage.image = [UIImage imageNamed:@"duigou"];
    chooseImage.tag = 1000+indexPath.row;
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        [cell setLayoutMargins:(UIEdgeInsetsZero)];
        [cell setSeparatorInset:(UIEdgeInsetsZero)];
        
        [cell.contentView addSubview:chooseImage];
        [cell.contentView addSubview:symbolView];
        [cell.contentView addSubview:cardName];
        [cell.contentView addSubview:cardNum];
    }
    if (indexPath.row!=0) {
        chooseImage.hidden = YES;
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    for (int i = 0; i<4; i++) {
        UIImageView *image = (UIImageView*)[self.view viewWithTag:1000+i];
        image.hidden = YES;
    }
    UIImageView *image = (UIImageView*)[self.view viewWithTag:1000+indexPath.row];
    image.hidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
