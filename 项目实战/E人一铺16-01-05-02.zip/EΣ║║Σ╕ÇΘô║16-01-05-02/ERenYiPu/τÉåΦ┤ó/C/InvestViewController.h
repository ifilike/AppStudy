//
//  InvestViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InvestViewController : UIViewController
@property(nonatomic,strong)NSDictionary *productDic;//理财产品信息
@property (nonatomic,strong)NSString *rateStr; //
@property (nonatomic,strong)NSString *canInvestMoney;   //剩余可投金额
@end
