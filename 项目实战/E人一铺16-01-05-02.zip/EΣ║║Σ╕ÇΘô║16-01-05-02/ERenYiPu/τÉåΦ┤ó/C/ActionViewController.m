//
//  ActionViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ActionViewController.h"

@interface ActionViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSIndexPath* indexpath;
@property(nonatomic,assign)NSInteger row;
@end

@implementation ActionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"活动";
    self.view.backgroundColor = [UIColor colorWithHexString:@"ececec"];
    // Do any additional setup after loading the view.
    self.row = 0;
    [self createUI];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 1;
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH-WINSIZEWIDTH/8)];
    firstView.backgroundColor = [UIColor whiteColor];
    UIView *secondView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEHEIGHT-WINSIZEWIDTH-WINSIZEWIDTH/10)];
    secondView.backgroundColor = [UIColor whiteColor];
    UILabel *stateLal = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/6)];
    stateLal.text = @"中奖情况";
    stateLal.textColor = YRedColor;
    stateLal.font = YBFont(WINSIZEWIDTH/17);
    stateLal.textAlignment = NSTextAlignmentCenter;
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(stateLal.frame), WINSIZEWIDTH, secondView.height - stateLal.height-WINSIZEWIDTH/10)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //self.tableView.backgroundColor = YBlackColor;
   // self.tableView.scrollEnabled = NO;
    [secondView addSubview:self.tableView];
    [secondView addSubview:stateLal];
    [self.view addSubview:firstView];
    [self.view addSubview:secondView];
    
    [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(scroll:) userInfo:nil repeats:YES];
}
-(void)scroll:(NSTimer *)timer{

    self.row++;
    if (self.row == 99) {
        self.row = 0;
    }
    self.indexpath = [NSIndexPath indexPathForRow:self.row inSection:0];
    [self.tableView scrollToRowAtIndexPath:self.indexpath atScrollPosition:(UITableViewScrollPositionMiddle) animated:YES];
   // NSLog(@"-----------");
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 100;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
    UILabel *nameLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEWIDTH/50, WINSIZEWIDTH/4, WINSIZEWIDTH/20)];
   nameLal.text = @"德莱厄斯";
    nameLal.textAlignment = NSTextAlignmentCenter;
    nameLal.backgroundColor = YRedColor;
    nameLal.font = YFont(WINSIZEWIDTH/22);
    UILabel *phoneLal = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(nameLal.frame), nameLal.y, WINSIZEWIDTH/3, nameLal.height)];
    NSString *str = @"15810860748";
    NSRange range = NSMakeRange(3, 8);
    phoneLal.text = [str stringByReplacingCharactersInRange:range withString:@"********"];
    phoneLal.textAlignment = NSTextAlignmentCenter;
    phoneLal.font = nameLal.font;
    UILabel *price = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(phoneLal.frame), nameLal.y, WINSIZEWIDTH/3, phoneLal.height)];
    price.text = @"抽中苹果7s";
    price.textAlignment = NSTextAlignmentCenter;
    price.font = nameLal.font;
    [cell.contentView addSubview:nameLal];
    [cell.contentView addSubview:phoneLal];
    [cell.contentView addSubview:price];
    
    //cell.backgroundColor = [UIColor blueColor];
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/11;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
