//
//  PublicDetailViewController.h
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PublicDetailViewController : UIViewController

@property (nonatomic)NSInteger comePage;    //来自于哪里  至高收益:1  绝低风险:2  随时提现:3

@end
