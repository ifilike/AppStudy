//
//  InviteViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "InviteViewController.h"
#import "SLAlertView.h"
#import "TopUpController.h"

@interface InviteViewController () <UMSocialUIDelegate>
{
    NSString *_yaoQingMa;    //邀请码
    NSString *_allMoney;    //用户总资产
}
@end

@implementation InviteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"邀请";
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT-CGRectGetMaxY(self.navigationController.navigationBar.frame))];
    imageView.image = [UIImage imageNamed:@"邀请"];
    //分享
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEHEIGHT - WINSIZEWIDTH/2-WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    investBtn.backgroundColor = YRedColor;
    [investBtn setTitle:@"分享邀请好友" forState:(UIControlStateNormal)];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius=WINSIZEWIDTH/100;
    //邀请码
    UILabel *invitLa = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(investBtn.frame)+WINSIZEWIDTH/14, WINSIZEWIDTH, investBtn.height)];
    //获取当前用户手机号
    NSString *userPhone = [[NSUserDefaults standardUserDefaults] valueForKey:USER_PHONE];
    //_yaoQingMa = [userPhone substringFromIndex:5];
    _yaoQingMa = userPhone;
#pragma mark - 取消邀请码为后6位，
    invitLa.text = [NSString stringWithFormat:@"邀请码:%@",userPhone];
    invitLa.font = YFont(WINSIZEWIDTH/18);
    invitLa.textColor = YGrayColor;
    invitLa.textAlignment = NSTextAlignmentCenter;
    
    [self.view addSubview:imageView];
    [self.view addSubview:investBtn];
    [self.view addSubview:invitLa];
    // Do any additional setup after loading the view.
}
//分享
-(void)invest:(UIButton *)sender{

    [SLAlertView showAlertWithStatusString:@"请稍候..."];
    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param} success:^(id json) {
        NSString *capitilMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"base_investment"]];//本息总额
        NSString *avalibleMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"sina_balance"]];//可用金额
        NSString *allcount = [NSString stringWithFormat:@"%f",[capitilMoney floatValue]+[avalibleMoney floatValue]];//总资产
        _allMoney = [NSString stringWithFormat:@"%0.2f",[allcount floatValue]];
        
        //请求到数据之后判断是否可以分享
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            TopUpController *tupVC = [[TopUpController alloc]init];
            tupVC.title = @"充值";
            [self.navigationController pushViewController:tupVC animated:YES];            };
        if ([_allMoney intValue]<1000) {
            [SLAlertView showAlertWithStatusString:@"您的账户余额不足1000，不能邀请好友请及时充值" withButtonTitles:@[@"取消",@"去充值"] andBlocks:@[block1,block2]];
        }else{
            NSString *shareText = [NSString stringWithFormat:@"(邀请码:%@)注册绑定银行卡成功后, 各送10元.",_yaoQingMa];
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"5652bc2567e58e75e0003108"
                                              shareText:shareText
                                             shareImage:[UIImage imageNamed:@"邀请"]
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToQQ,UMShareToQzone,UMShareToSms,UMShareToEmail,UMShareToWechatSession,UMShareToWechatTimeline,nil]
                                               delegate:self];
        }
        
        
    } failure:^(NSError *error) {
        
    }];
    
   // [MBProgressHUD showError:@"现在分享不了。。"];
}


-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response {
    
}


@end
