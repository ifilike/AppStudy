//
//  SafeguardViewController.h
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//
//    保障方式

#import <UIKit/UIKit.h>

@interface SafeguardViewController : UIViewController

@end
