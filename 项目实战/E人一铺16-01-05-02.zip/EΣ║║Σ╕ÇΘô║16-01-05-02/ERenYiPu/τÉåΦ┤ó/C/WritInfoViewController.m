//
//  WritInfoViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "WritInfoViewController.h"
#import "TieCardViewController.h"
#import "SLAlertView.h"

@interface WritInfoViewController ()
@property(nonatomic,strong)UITextField *CardName;//持卡人姓名
@property(nonatomic,strong)UITextField *CardNum;//身份证号码
@end

@implementation WritInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"填写个人信息";
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    [self createUI];

    // Do any additional setup after loading the view.
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/7)];
    firstView.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/3-WINSIZEWIDTH/30, firstView.height)];
    label.text = @"输入个人信息";
    label.textColor = YRedColor;
    label.font = YFont(WINSIZEWIDTH/22);
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(label.frame), firstView.height/2-WINSIZEWIDTH/80, WINSIZEWIDTH/60, WINSIZEWIDTH/40)];
    image1.image = [UIImage imageNamed:@"jiantou"];
    [firstView addSubview:image1];
    UILabel *cardLal = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(image1.frame)+WINSIZEWIDTH/25, label.y, WINSIZEWIDTH/3-WINSIZEWIDTH/16, firstView.height)];
    cardLal.textColor = YGrayColor;
    cardLal.font = label.font;
    cardLal.text = @"绑定银行卡";
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardLal.frame), image1.y, image1.width, image1.height)];
    image2.image = [UIImage imageNamed:@"jiantou"];
    UILabel *infoCerti = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(image2.frame)+WINSIZEWIDTH/25, label.y, WINSIZEWIDTH/4, firstView.height)];
    infoCerti.text = @"信息认证";
    infoCerti.textColor = YGrayColor;
    infoCerti.font = label.font;
    
    [firstView addSubview:label];
    [firstView addSubview:image1];
    [firstView addSubview:cardLal];
    [firstView addSubview:image2];
    [firstView addSubview:infoCerti];
    
    UIView *secondView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    secondView.backgroundColor = [UIColor whiteColor];
    UILabel *cardName = [[UILabel alloc]initWithFrame:CGRectMake(label.x, 0, WINSIZEWIDTH/4, label.height)];
    cardName.textColor = YBlackColor;
    cardName.text = @"持卡人姓名";
    cardName.font = label.font;
    self.CardName = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardName.frame)+WINSIZEWIDTH/30, 0, WINSIZEWIDTH/2, secondView.height)];
    self.CardName.font = YBFont(WINSIZEWIDTH/22);
    self.CardName.placeholder = @"请填写真实姓名";

    [secondView addSubview:cardName];
    [secondView addSubview:self.CardName];
    
    UIView *thirdView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, secondView.height)];
    thirdView.backgroundColor = [UIColor whiteColor];
    UILabel *cardNum = [[UILabel alloc]initWithFrame:CGRectMake(cardName.x, 0, cardName.width, thirdView.height)];
    cardNum.text = @"身份证号码";
    cardNum.font = cardName.font;

    self.CardNum = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(cardNum.frame)+WINSIZEWIDTH/30, 0, self.CardName.width, thirdView.height)];
    self.CardNum.font = self.CardName.font;
    self.CardNum.placeholder = @"请输入身份证号码";
    self.CardNum.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    [thirdView addSubview:cardNum];
    [thirdView addSubview:self.CardNum];
    
    UIView *forthView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(thirdView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEHEIGHT)];
    forthView.backgroundColor = [UIColor whiteColor];
    UILabel *promptLal = [[UILabel alloc]initWithFrame:CGRectMake(label.x, WINSIZEWIDTH/70, WINSIZEWIDTH-WINSIZEWIDTH/10, label.height/2)];
    promptLal.text = @"·身份成功之后，姓名不可更改";
    promptLal.font = YBFont(WINSIZEWIDTH/27);
    promptLal.textColor = YRedColor;
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(label.x, WINSIZEWIDTH/5, WINSIZEWIDTH-label.x*2, WINSIZEWIDTH/8)];
    [button setTitle:@"下一步" forState:(UIControlStateNormal)];
    button.backgroundColor = YRedColor;
    button.titleLabel.font = YBFont(WINSIZEWIDTH/20);
    [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    button.layer.cornerRadius = WINSIZEWIDTH/100;
    [button addTarget:self action:@selector(next:) forControlEvents:(UIControlEventTouchUpInside)];
    [forthView addSubview:promptLal];
    [forthView addSubview:button];
    
    [self.view addSubview:forthView];
    [self.view addSubview:thirdView];
    [self.view addSubview:secondView];
    [self.view addSubview:firstView];
}
-(void)next:(UIButton *)sender{
#warning test er yi

    if (self.CardName.text.length<1) {
        [SLAlertView showAlertWithStatusString:@"姓名不能为空"];
//        [MBProgressHUD showError:@"姓名不能为空"];
        return;
    }else if(self.CardNum.text.length<1){
        [SLAlertView showAlertWithStatusString:@"身份证号码不能为空"];
//        [MBProgressHUD showError:@"身份证号码不能为空"];
        return;
    }
    [SLAlertView showAlertWithMessageString:@"正在认证..."];
   // [MBProgressHUD showMessage:@"正在认证..."];
    NSString *user_id = [[NSUserDefaults standardUserDefaults]objectForKey:USER_ID];
    NSString *token = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *phone = [[NSUserDefaults standardUserDefaults]objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_name\":\"%@\",\"IDCardNo\":\"%@\",\"user_phone\":\"%@\",\"token\":\"%@\"}",self.CardName.text,self.CardNum.text,phone,token];
    [IKHttpTool postWithURL:@"Certification" params:@{@"json":param} success:^(id json) {
        [SLAlertView hide];
       // [SLAlertView showAlertWithStatusString:@"认证成功"];
        //[self.prompt showPromptWithTitle:@"tishi" message:@"    认证成功" buttonleft:nil buttonright:nil];
        TieCardViewController *tieCard = [[TieCardViewController alloc]init];
        tieCard.userName = [NSString stringWithFormat:@"%@",self.CardName.text];
        [[NSUserDefaults standardUserDefaults]setObject:self.CardName.text forKey:@"user_name"];
        [self.view endEditing:YES];
        [self.navigationController pushViewController:[[TieCardViewController alloc]init] animated:YES];
        NSLog(@"-------%@ %@",self.CardName.text,tieCard.userName);
    } failure:^(NSError *error) {
        
    }];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
