//
//  NewsCenterVC.h
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewsCenterVC : UIViewController
@property (nonatomic,strong)NSArray *newsArr;   //新闻列表
@end
