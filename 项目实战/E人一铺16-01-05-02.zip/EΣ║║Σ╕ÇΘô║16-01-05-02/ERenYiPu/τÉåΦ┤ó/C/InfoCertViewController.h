//
//  InfoCertViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/6.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoCertViewController : UIViewController
@property (nonatomic,strong) NSString *infoPhone;//绑定银行卡的手机
@property (nonatomic,strong) NSString *ticket;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *cardNum;//银行卡号
@property (nonatomic,strong) NSString *bankName;//银行卡类型
@end
