//
//  TieCardViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/6.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TieCardViewController : UIViewController
@property (nonatomic,strong) NSString *userName;
@end
