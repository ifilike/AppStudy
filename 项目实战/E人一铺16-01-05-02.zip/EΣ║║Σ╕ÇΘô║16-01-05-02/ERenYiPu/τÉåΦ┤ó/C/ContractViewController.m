//
//  ContractViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ContractViewController.h"

@interface ContractViewController ()

@end

@implementation ContractViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.navigationItem.title = @"合同";
    
//    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(10, 0, WINSIZEWIDTH - 20, WINSIZEHEIGHT)];
//    scrollView.contentSize = CGSizeMake(WINSIZEWIDTH - 20, WINSIZEHEIGHT * 3);
//    scrollView.backgroundColor = [UIColor whiteColor];
//    [self.view addSubview:scrollView];
    
    NSString *text = @"\n一、甲方的权利和义务\n1、甲方应按合同约定的借款期限将足额的借款本金支付给乙方，并享有其所出借款项所带来的利息收益。\n2、甲方有权在借款前委托丙方有偿对乙方提供的信息的真实性进行确认。\n3、如乙方违约，甲方有权要求丙方提供其已获得的乙方信息，丙方应当提供。\n4、甲方可以根据自己的意愿进行本协议下其对乙方债权的转让。甲方委托丙方以电子邮件的方式将债权转让通知发送到乙方在丙方注册时提供的电子邮件地址即视为通知。在甲方的债权转让后，乙方需对债权受让人继续履行本协议下其对甲方的还款义务，不得以未接到债权转让通知为由拒绝履行还款义务。\n5、甲方应主动缴纳由利息所得带来的可能的税费。\n6、如乙方实际还款金额少于本协议约定的本金、利息及违约金的，甲方各出借人同意各自按照其于本协议文首约定的借款比例收取还款。\n7、甲方应确保其提供信息和资料的真实性，不得提供虚假信息或隐瞒重要事实。\n8、甲方应保证其出借资金来源的合法性。\n9、甲方享有在乙方违约时向丁方主张连带责任保证还款的权利。在甲方转让债权的情况下，同时转让向丁方主张连带责任保证还款的权利。\n二、乙方权利和义务\n1、乙方必须按合同约定的还款日期足额向甲方偿还本金和利息。\n2、乙方必须按期足额向丙方支付借款管理费用。\n3、乙方承诺所借款项不用于任何违法用途。\n4、乙方应确保其提供的信息和资料的真实性，不得提供虚假信息或隐瞒重要事实。\n5、乙方有权了解其在丙方的信用评审进度及结果。\n6、乙方不得将本协议项下的任何权利义务转让给任何其他方。\n三、丙方的权利和义务\n1、甲方授权并委托丙方代其收取本协议文首所约定的出借人每月应收本息，代收后按照甲方的要求进行处置，乙方对此表示认可。\n2、甲方授权并委托丙方将其支付的出借本金直接划付至乙方账户，乙方对此表示认可。\n3、甲、乙双方一致同意，在有必要时，丙方有权代甲方对乙方进行关于本协议借款的违约提醒及催收工作，包括但不限于：电话通知、上门催收提醒、发律师函、对乙方提起诉讼等。甲方在此确认委托丙方为其进行以上工作，并授权丙方可以将此工作委托给本协议外的其他方进行。乙方对前述委托的提醒、催收事项已明确知晓并应积极配合。\n4、丙方有权按月向乙方收取双方约定的借款管理费，并在有必要时对乙方进行违约提醒及催收工作，包括但不限于电话通知、发律师函、对乙方提起诉讼等。丙方有权将此违约提醒及催收工作委托给本协议外的其他方进行。\n5、丙方接受甲、乙双方的委托行为所产生的法律后果由相应委托方承担。如因乙方或甲方或其他方（包括但不限于技术问题）造成的延误或错误，丙方不承担任何责任。\n6、丙方应对甲方和乙方的信息及本协议内容保密；如任何一方违约，或因相关权力部门要求（包括但不限于法院、仲裁机构、金融监管机构等），丙方有权披露。\n";
    
    UITextView *label = [[UITextView alloc]initWithFrame:CGRectMake(10, 0, WINSIZEWIDTH - 20, WINSIZEHEIGHT - 64)];
    label.textAlignment = NSTextAlignmentLeft;
    label.font = YFont(16);
    label.textColor = YGrayColor;
    label.editable = NO;
    label.text = text;
    label.showsVerticalScrollIndicator = NO;
    [self.view addSubview:label];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
