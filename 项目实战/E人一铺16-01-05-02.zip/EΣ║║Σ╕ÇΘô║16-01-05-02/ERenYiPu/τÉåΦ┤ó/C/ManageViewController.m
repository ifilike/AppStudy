//
//  ManageViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ManageViewController.h"
#import "NoticeDetailViewController.h"
#import "ActionViewController.h"
#import "InvestViewController.h"
#import "InviteViewController.h"
#import "WritInfoViewController.h"
#import "AgoProtectVC.h"
#import "NewsCenterVC.h"
#import "SLWaterView.h"
#import "DetailViewController.h"
#import "NewsModel.h"
#import "RollingTextView.h"
#import "ActiveDetailViewController.h"
#import "SignInViewController.h"
#import "ActivityModel.h"
#import "SDCycleScrollView.h"
#import "ETabBarViewController.h"
#import "SLAlertView.h"
#import "TopUpController.h"
#import "ShareViewController.h"
#import "YDScrollView.h"
#import "UserData.h"

@interface ManageViewController ()<SDCycleScrollViewDelegate>
{
    UILabel *allmoney;
    RollingTextView *textView;
    YDScrollView *textScrollView;
    NSString *rateStr;  //已投比率
    NSString *canInvestMoney;   //剩余可投金额
    UIButton *investBtn;    //立即投资按钮
    NSDictionary *activityDic;  //当前活动字典
    
    double _zongshouyi; //总收益
    double _zhanghuyue; //账户余额
}
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UIButton *versionBtn;
@property(nonatomic,strong)UIButton *allMoney;//项目总金额
@property(nonatomic,strong)UIButton *profit;//收益
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)SLWaterView *waterView;
@property(nonatomic,strong)NSDictionary *productDic;//理财产品信息
@property(nonatomic,strong)NSMutableArray *productArray;//理财产品列表
@property(nonatomic,strong)NSMutableArray *newsArr;
@property(nonatomic,strong)NSString *myCount;//我的余额
@property (strong, nonatomic) UIView *scrollBackgroundView;

@property (nonatomic,strong)ActivityModel *activeModel;

@end

@implementation ManageViewController
#pragma mark -- 懒加载
-(NSMutableArray *)newsArr{

    if (!_newsArr) {
        _newsArr = [NSMutableArray array];
    }
    return _newsArr;
}
-(UIScrollView *)scrollView{

    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT - 49)];
        _scrollView.backgroundColor = [UIColor colorWithHexString:@"ff6054"];
        _scrollView.contentSize = CGSizeMake(WINSIZEWIDTH, WINSIZEWIDTH*1.935);
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        //_scrollView.bounces = NO;
        _scrollView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
        _scrollBackgroundView = [[UIView alloc] init];
        [_scrollView addSubview:_scrollBackgroundView];
        _scrollBackgroundView.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
        [self scrollViewBackgroundView];
    }
    return _scrollView;
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    self.scrollBackgroundView.frame = CGRectMake(0, 0, self.scrollView.contentSize.width, self.scrollView.contentSize.height);
}

- (void)scrollViewBackgroundView  {
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(WINSIZEWIDTH/30, 40, WINSIZEWIDTH/4, WINSIZEWIDTH/4);
    [button setImage:[UIImage imageNamed:@"shouyi"] forState:(UIControlStateNormal)];
    [button setTitleColor:YRedColor forState:(UIControlStateNormal)];
    [button setTitle:@"至高收益" forState:(UIControlStateNormal)];
    button.imageEdgeInsets = UIEdgeInsetsMake(0, button.width/3.5, button.height/1.5, 0);
    button.titleLabel.font = YFont(WINSIZEWIDTH/27);
    [button setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    button.titleEdgeInsets = UIEdgeInsetsMake(0, -button.width/3, 0, 0);
    [button setTitleColor:[UIColor colorWithHexString:@"ececec"] forState:(UIControlStateHighlighted)];
//    [button addTarget:self action:@selector(shouyiBtClick) forControlEvents:UIControlEventTouchUpInside];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(button.x, button.height-WINSIZEWIDTH/15+28, button.width, WINSIZEWIDTH/28)];
    label.textColor = YGrayColor;
    label.font = YFont(WINSIZEWIDTH/30);
    label.text = @"年化收益8%起";
    label.textAlignment = NSTextAlignmentCenter;
    
    UIButton *button2 = [UIButton buttonWithType:(UIButtonTypeCustom)];
    button2.frame = CGRectMake(WINSIZEWIDTH/2-button.width/2, button.y, button.width, button.height);
    [button2 setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [button2 setTitle:@"绝低风险" forState:(UIControlStateNormal)];
    [button2 setTitleColor:[UIColor colorWithHexString:@"ececec"] forState:(UIControlStateHighlighted)];
    button2.titleLabel.font = button.titleLabel.font;
    [button2 setImage:[UIImage imageNamed:@"fengxian"] forState:(UIControlStateNormal)];
    button2.imageEdgeInsets = button.imageEdgeInsets;
    button2.titleEdgeInsets = button.titleEdgeInsets;
//    [button2 addTarget:self action:@selector(fengxianBtClick) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(button2.x, label.y, label.width, label.height)];
    label2.textAlignment = NSTextAlignmentCenter;
    label2.text = @"奉献金银行托管";
    label2.textColor = YGrayColor;
    label2.font = label.font;
    
    UIButton *button3= [UIButton buttonWithType:(UIButtonTypeCustom)];
    button3.frame = CGRectMake(WINSIZEWIDTH-CGRectGetMaxX(button.frame), button.y, button.width, button.height);
    [button3 setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [button3 setTitleColor:[UIColor colorWithHexString:@"ececec"] forState:(UIControlStateHighlighted)];
    button3.titleLabel.font = button2.titleLabel.font;
    [button3 setImage:[UIImage imageNamed:@"tixian1"] forState:(UIControlStateNormal)];
    button3.imageEdgeInsets = button2.imageEdgeInsets;
    button3.titleEdgeInsets = button2.titleEdgeInsets;
    [button3 setTitle:@"随时提现" forState:(UIControlStateNormal)];
//    [button3 addTarget:self action:@selector(tixianBtClick) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *label3 = [[UILabel alloc]initWithFrame:CGRectMake(button3.x, label2.y, label2.width, label2.height)];
    label3.textColor = label2.textColor;
    label3.font = label2.font;
    label3.text = @"24小时内到账";
    label3.textAlignment = NSTextAlignmentCenter;
    
    
    [self.view addSubview:button];
    [self.view addSubview:button2];
    [self.view addSubview:button3];
    
    [self.view addSubview:label];
    [self.view addSubview:label2];
    [self.view addSubview:label3];
}



//水中的数字
-(UIButton *)allMoney{

    if (!_allMoney) {
        _allMoney = [[UIButton alloc]initWithFrame:CGRectMake(0,0, WINSIZEWIDTH/16*5, WINSIZEWIDTH/16*5)];
        _allMoney.backgroundColor = [UIColor clearColor];
        //_allMoney.backgroundColor = [UIColor colorWithHexString:@"fe7171"];
        _allMoney.layer.cornerRadius = _allMoney.height/2;
        _allMoney.titleLabel.font = YBFont(WINSIZEWIDTH/15);
        [_allMoney setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [_allMoney setTitle:@"-%" forState:(UIControlStateNormal)];
        [_allMoney setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        
        [_allMoney addTarget:self action:@selector(version:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _allMoney;
}
-(SLWaterView *)waterView{

    if (!_waterView) {
        _waterView = [[SLWaterView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEWIDTH/6, self.allMoney.width, self.allMoney.width)];
        _waterView.layer.borderWidth = 2;
        _waterView.layer.borderColor = [UIColor colorWithHexString:@"fe7171"].CGColor;
        _waterView.waterPercent = 0.0;
    }
    return _waterView;
}
//年化收益
-(UIButton *)profit{

    if (!_profit) {
        _profit = [UIButton buttonWithType:UIButtonTypeCustom];
        //_profit = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-CGRectGetMaxX(self.waterView.frame), self.waterView.y, self.allMoney.width, self.allMoney.height)];
        _profit.backgroundColor = [UIColor colorWithHexString:@"fcc457"];
        _profit.layer.cornerRadius = self.allMoney.height/2;
        [_profit setTitle:@"8.00%" forState:(UIControlStateNormal)];
        [_profit setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        _profit.titleLabel.font = self.allMoney.titleLabel.font;
    }
    return _profit;
}
//版本按钮
-(UIButton *)versionBtn{

    if (!_versionBtn) {
        _versionBtn = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, WINSIZEWIDTH/2, WINSIZEWIDTH/18)];
        _versionBtn.titleLabel.font = YBFont(WINSIZEWIDTH/28);

        [_versionBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
        //[_versionBtn setTitleColor:[UIColor colorWithHexString:@"75eab0"] forState:(UIControlStateNormal)];
        [_versionBtn setTitle:@"铺宝宝第-期" forState:(UIControlStateNormal)];
        _versionBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft  ;
        // _versionBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
        
    }
    return _versionBtn;
}


-(UIImageView *)imageView{

    if (!_imageView) {
       
         _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/3+WINSIZEWIDTH/19)];
        _imageView.backgroundColor = YBlackColor;
    }
    return _imageView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
//    NSArray *familyNames = [UIFont familyNames];
//    for( NSString *familyName in familyNames ){
//        printf( "Family: %s \n", [familyName UTF8String] );
//        NSArray *fontNames = [UIFont fontNamesForFamilyName:familyName];
//        for( NSString *fontName in fontNames ){
//            printf( "\tFont: %s \n", [fontName UTF8String] );
//        }
//    }
//    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    _productArray = [NSMutableArray array];
    
//    [self getProData];//获取理财信息

    [self createUI];
    
    [self getActiveData];
    
    // Do any additional setup after loading the view.
}
-(void)createUI{
    //首页轮播图
    NSArray *images = @[[UIImage imageNamed:@"lunbo1"],
                        [UIImage imageNamed:@"lunbo2"],
                        [UIImage imageNamed:@"lunbo3"]
                        ];
    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/2) imagesGroup:images];
    
    cycleScrollView.infiniteLoop = YES;
    cycleScrollView.delegate = self;
    cycleScrollView.pageControlStyle = SDCycleScrollViewPageContolStyleAnimated;
    [self.scrollView addSubview:cycleScrollView];

   // self.view.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
    [self.view addSubview:self.scrollView];
    UIView *secondView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(cycleScrollView.frame)+10, WINSIZEWIDTH - 20, WINSIZEWIDTH/8-1)];
    secondView.backgroundColor = [UIColor whiteColor];
    secondView.layer.cornerRadius = 3;
    //UIButton *newsbutton = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/9, WINSIZEWIDTH/100, secondView.width/2, secondView.height)];
    //铃铛
    UIImageView *lingdang = [[UIImageView alloc]initWithFrame:CGRectMake((WINSIZEWIDTH - 30) / 18 - 5, secondView.height / 3, secondView.height / 3, secondView.height / 3)];
    lingdang.image = [UIImage imageNamed:@"xiaoxituisong"];
    [secondView addSubview:lingdang];
#pragma mark - 新闻轮播修改了
//    textView = [[RollingTextView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lingdang.frame) + 8, 0, secondView.width - CGRectGetMaxX(lingdang.frame) * 2, secondView.height)];
//    [secondView addSubview:textView];
//    
//    textView.backgroundColor = [UIColor whiteColor];
//    textView.textColor = YGrayColor;
//    textView.speed = 1;
//    //textView.textArr = @[@"消息推送新闻"];
    
    textScrollView = [[YDScrollView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lingdang.frame) + 5, 0, secondView.width - CGRectGetMaxX(lingdang.frame) * 2 - 5, secondView.height)];
    [secondView addSubview:textScrollView];
    [textScrollView createScrllWith:@"E人一铺" speed:kSpeed];
    
    UIButton *newsBt = [UIButton buttonWithType:UIButtonTypeCustom];
    newsBt.frame = CGRectMake(0, 0, CGRectGetMaxX(textScrollView.frame) - 5, secondView.height);
    newsBt.backgroundColor = [UIColor clearColor];
    [newsBt addTarget:self action:@selector(newsPush:) forControlEvents:UIControlEventTouchUpInside];
    [secondView addSubview:newsBt];
    
    //添加后面的 三个点
    //竖线
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(textScrollView.frame ) + 2, 8, 1.5, secondView.height - 16)];
    lineView.backgroundColor = [UIColor colorWithHexString:@"d8d8d8"];
    [secondView addSubview:lineView];
    
    //三个点
    UIButton *image = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(lineView.frame) + 2,0, secondView.width - CGRectGetMaxX(lineView.frame) - 2, secondView.height)];
    //[image setBackgroundImage:[UIImage imageNamed:@"dian"] forState:(UIControlStateNormal)];
    //image.backgroundColor = [UIColor redColor];
    
    [image setImage:[UIImage imageNamed:@"dian"] forState:(UIControlStateNormal)];
    //[image setTintColor:[UIColor grayColor]];
    //image.contentMode = UIViewContentModeScaleAspectFit;
    [image addTarget:self action:@selector(moreNews:) forControlEvents:(UIControlEventTouchUpInside)];

    [secondView addSubview:image];

    //第三个view块  活动 邀请好友
    UIView *thirdView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/40, WINSIZEWIDTH - 20, WINSIZEWIDTH / 7)];
    thirdView.backgroundColor = [UIColor colorWithHexString:@"ececec"];

    //活动
    UIView *actionView = [[UIView alloc] init];
    actionView.frame = CGRectMake(0, 0, (WINSIZEWIDTH - 30)/2, thirdView.height);
    actionView.backgroundColor = [UIColor whiteColor];
    actionView.layer.cornerRadius = 3;
    
    UIImageView *actionImage = [[UIImageView alloc]initWithFrame:CGRectMake(actionView.width / 9, actionView.height / 5, actionView.height / 5 * 3, actionView.height /  5 * 3)];
    actionImage.layer.cornerRadius = actionImage.height / 2;
    actionImage.image = [UIImage imageNamed:@"huodongbt"];
    
    UILabel *actionLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(actionImage.frame ) + 20, CGRectGetMinY(actionImage.frame) + 2, actionView.width / 2, actionView.height / 4)];
    actionLabel1.textColor = [UIColor redColor];
    actionLabel1.font = YFont(WINSIZEWIDTH / 27);
    actionLabel1.text = @"活动";
    
    UILabel *actionLabel2 = [[UILabel alloc]initWithFrame:CGRectMake(actionLabel1.frame.origin.x, CGRectGetMaxY(actionLabel1.frame) + 4, actionLabel1.width, actionLabel1.height)];
    actionLabel2.textColor = YGrayColor;
    actionLabel2.font = YFont(WINSIZEWIDTH / 34);
    actionLabel2.text = @"最高加息8%";
    
    [actionView addSubview:actionImage];
    [actionView addSubview:actionLabel1];
    [actionView addSubview:actionLabel2];
    
    
    
    //邀请好友
    UIView *inviteView = [[UIView alloc]init];
    inviteView.frame = CGRectMake(CGRectGetMaxX(actionView.frame) + 10, 0, (WINSIZEWIDTH - 30)/2, thirdView.height);
    
    inviteView.backgroundColor = [UIColor whiteColor];
    inviteView.layer.cornerRadius = 3;
    
    UIImageView *inviteImage = [[UIImageView alloc]initWithFrame:CGRectMake(inviteView.width / 9, inviteView.height / 3, inviteView.height / 3 * 2 - 5, inviteView.height / 3)];
    inviteImage.image = [UIImage imageNamed:@"yaoqing"];
    
    UILabel *inviteLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(inviteImage.frame ) + 20, inviteView.height / 5 + 2, inviteView.width / 2 , inviteView.height / 4)];
    inviteLabel1.textColor = [UIColor redColor];
    inviteLabel1.font = YFont(WINSIZEWIDTH / 27);
    inviteLabel1.text = @"邀请好友";
    
    UILabel *inviteLabel2 = [[UILabel alloc]initWithFrame:CGRectMake(inviteLabel1.frame.origin.x, CGRectGetMaxY(inviteLabel1.frame) + 4, inviteLabel1.width, inviteLabel1.height)];
    inviteLabel2.textColor = YGrayColor;
    inviteLabel2.font = YFont(WINSIZEWIDTH / 34);
    inviteLabel2.text = @"奖励特权本金";
    
    [inviteView addSubview:inviteImage];
    [inviteView addSubview:inviteLabel1];
    [inviteView addSubview:inviteLabel2];
    
    
    [thirdView addSubview:actionView];
    [thirdView addSubview:inviteView];
    
    
    //活动点击
    UIButton *huodongBt = [UIButton buttonWithType:UIButtonTypeCustom];
    huodongBt.backgroundColor = [UIColor clearColor];
    huodongBt.frame = actionView.bounds;
    [huodongBt addTarget:self action:@selector(huodongByAction) forControlEvents:UIControlEventTouchUpInside];
    [actionView addSubview:huodongBt];
    
    //邀请好友 按钮
    UIButton *inviteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    inviteBtn.frame = inviteView.bounds;
    
    inviteBtn.backgroundColor = [UIColor clearColor];
    [inviteBtn addTarget:self action:@selector(invite:) forControlEvents:UIControlEventTouchUpInside];
    [inviteView addSubview:inviteBtn];
    NSLog(@" inviteBtn.frame %@",inviteBtn);
    
    //今日任务
    UIView *addView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(thirdView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH -20 , secondView.height)];
    addView.backgroundColor = [UIColor whiteColor];
    addView.layer.cornerRadius = 3;
    
    UIImageView *renwuImage = [[UIImageView alloc]initWithFrame:CGRectMake(actionView.width / 9 + 2, addView.height / 4, addView.height / 2, addView.height / 2)];
    renwuImage.image = [UIImage imageNamed:@"jinrirenwu"];
    UILabel *renwuLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(renwuImage.frame ) + 20, addView.height / 3, addView.width / 2, addView.height / 3)];
    renwuLabel.textColor = YGrayColor;
    renwuLabel.font = actionLabel1.font;
    renwuLabel.text = @"今日任务";
    
    [addView addSubview:renwuImage];
    [addView addSubview:renwuLabel];
    
    [self.scrollView addSubview:addView];
    
    UIButton *todayBt = [UIButton buttonWithType:UIButtonTypeCustom];
    todayBt.frame = addView.bounds;
    todayBt.backgroundColor = [UIColor clearColor];
    [todayBt addTarget:self action:@selector(signIn:) forControlEvents:UIControlEventTouchUpInside];
    [addView addSubview:todayBt];
    

    //铺宝宝
    UIView *forthView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(addView.frame)+WINSIZEWIDTH/40, WINSIZEWIDTH - 20, WINSIZEWIDTH * 13/16)];
    forthView.backgroundColor = [UIColor whiteColor];
    forthView.layer.cornerRadius = 3;
    
    [forthView addSubview:self.versionBtn];
    
    //详情按钮
    UIButton *detailBt = [UIButton buttonWithType:UIButtonTypeCustom];
    detailBt.frame = CGRectMake(CGRectGetMaxX(forthView.frame) - 150, CGRectGetMinY(self.versionBtn.frame), 150, self.versionBtn.height);
    [detailBt setTitleColor:YGrayColor forState:UIControlStateNormal];
    [detailBt setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
    [detailBt setTitle:@"详情 >" forState:UIControlStateNormal];
    
    [detailBt addTarget:self action:@selector(version:) forControlEvents:UIControlEventTouchUpInside];
    
    [detailBt setTitleEdgeInsets:UIEdgeInsetsMake(0, 50, 0, -10)];
    
    detailBt.titleLabel.font = self.versionBtn.titleLabel.font;
    [forthView addSubview:detailBt];
    
    //加一根线
    UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetMinX(self.versionBtn.frame), CGRectGetMaxY(self.versionBtn.frame) + 5, forthView.width - CGRectGetMinX(self.versionBtn.frame) * 2, 1)];
    line1.backgroundColor = [UIColor colorWithHexString:@"ececec"];
    
    [forthView addSubview:line1];
    
    //水 按钮
    
    
    [self.waterView addSubview:self.allMoney];
    [forthView addSubview:self.waterView];
    
    
    self.profit.frame = CGRectMake(forthView.width - CGRectGetMaxX(self.waterView.frame), self.waterView.y, self.allMoney.width, self.allMoney.height);
    
    [forthView addSubview:self.profit];
    
    allmoney = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.profit.frame)+WINSIZEWIDTH/50, self.profit.width+self.waterView.x*2, WINSIZEWIDTH/10)];
    allmoney.text = @"项目总金额:-万";
    allmoney.font = YFont(WINSIZEWIDTH/28);
    allmoney.textColor = YGrayColor;
    allmoney.textAlignment = NSTextAlignmentCenter;
    allmoney.userInteractionEnabled = YES;
    [forthView addSubview:allmoney];
    
    //添加按钮
    UIButton *moneyBt = [UIButton buttonWithType:UIButtonTypeCustom];
    moneyBt.frame = allmoney.bounds;
    [allmoney addSubview:moneyBt];
    moneyBt.backgroundColor = [UIColor clearColor];
    [moneyBt addTarget:self action:@selector(version:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *profitLab = [[UILabel alloc]initWithFrame:CGRectMake(self.profit.x-self.waterView.x, allmoney.y, allmoney.width, allmoney.height)];
    profitLab.textAlignment = NSTextAlignmentCenter;
    profitLab.font = allmoney.font;
    profitLab.text = @"年化收益";
    profitLab.textColor = YGrayColor;
    [forthView addSubview:profitLab];
    
    
    //立即投资按钮
    investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/16, CGRectGetMaxY(allmoney.frame)+WINSIZEWIDTH/15, forthView.width-WINSIZEWIDTH/8, WINSIZEWIDTH/9-WINSIZEWIDTH/100)];
    [investBtn setBackgroundImage:[UIImage imageNamed:@"graybackimg"] forState:(UIControlStateNormal)];
    investBtn.enabled = false;
    [investBtn setTitle:@"立即投资" forState:(UIControlStateNormal)];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/24);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius=WINSIZEWIDTH/100;
    
    UIButton *agoBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(forthView.frame), WINSIZEWIDTH, WINSIZEWIDTH/8)];
    agoBtn.backgroundColor = YBackGrayColor;
    [agoBtn setTitle:@"查看往期 >" forState:(UIControlStateNormal)];
    [agoBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [agoBtn setTitleColor:[UIColor colorWithHexString:@"e5e5e5"] forState:(UIControlStateHighlighted)];
    agoBtn.titleLabel.font = YBFont(WINSIZEWIDTH/22);
    [agoBtn addTarget:self action:@selector(agoPro:) forControlEvents:(UIControlEventTouchUpInside)];
    [agoBtn setBackgroundColor:YBackGrayColor];
    //[investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    //self.imageView.image = [UIImage imageNamed:@"banner.jpg"];
#warning mark -- 设置水的深度
    //self.waterView.waterPercent = 0.5;
    //[self.scrollView addSubview:self.imageView];
    //[self.scrollView addSubview:addView];
    [self.scrollView addSubview:secondView];
    [self.scrollView addSubview:thirdView];
    [self.scrollView addSubview:forthView];
    [self.scrollView addSubview:agoBtn];
    [forthView addSubview:investBtn];
    
    [inviteView bringSubviewToFront:inviteBtn];
    
//    [self.waterView addSubview:self.allMoney];
//    [forthView addSubview:self.waterView];
   // [forthView addSubview:self.allMoney];
    
}

#pragma mark - 如果活动可以玩,要判断  收益 min_profit , 余额 min_balance, 是否需要认证 is_auth,(这三个是活动数据传过来的,需要跟当前用户比较) sum_profit   sina_balance
//活动点击
//翻翻翻 需要用户累积收益达到1000元   //需要获取  用户累积收益
- (void)huodongByAction
{
    NSLog(@"点击活动");
    NSString *userName = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_name"];
    if ([userName isEqualToString:@"未认证"]) {
        if ([_activeModel.is_auth isEqualToString:@"1"]) {
            [SLAlertView showAlertWithStatusString:@"您还未认证，不能参加该活动"];
            return;
        }
    }
    if ([_activeModel.min_profit floatValue] > _zongshouyi ) {
        [SLAlertView showAlertWithStatusString:@"您的总收益不足，不能参加该活动"];
        return;
    }
    if ([_activeModel.min_balance floatValue] > _zhanghuyue ) {
        [SLAlertView showAlertWithStatusString:@"您的账户余额不足，不能参加该活动"];
        return;
    }
    
    ActiveDetailViewController *zhuanVC = [[ActiveDetailViewController alloc]init];
    
//    ActivityModel *activeModel = [[ActivityModel alloc]init];
//    
//    activeModel.active_id = @"2";
//    activeModel.active_url = @"http://115.28.143.129/EREP/active/earnings.web/index.html";
    
    zhuanVC.activeModel = _activeModel;
    
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    zhuanVC.userPhone = userPhone;
    zhuanVC.title = _activeModel.active_title;
    
    [self.navigationController pushViewController:zhuanVC animated:YES];
    
    
}

//今日任务
//签到
-(void)signIn:(UIButton *)sender{

   // [self.navigationController pushViewController:[SignInViewController new] animated:YES];

    NSString *name = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_name"];
    if ([name isEqualToString:@"未认证"]) {
        void(^block)() = ^(){
        };
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"对不起，您还没有认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block,block2]];
        //[self.prompt makePromptWithTitle:@"提示" message:@"请认证后投资" buttonleft:@"取消" buttonright:@"去认证"];
        return;
    }
    
    void(^block1)() = ^(){};
    void(^block2)() = ^(){
        TopUpController *tupVC = [[TopUpController alloc]init];
        tupVC.title = @"充值";
        [self.navigationController pushViewController:tupVC animated:YES];            };
    if ([self.myCount intValue]<1000) {
        [SLAlertView showAlertWithStatusString:@"您的账户余额不足1000，不能做任务请及时充值" withButtonTitles:@[@"取消",@"去充值"] andBlocks:@[block1,block2]];
    }else{
    NSLog(@"点击今日任务");
    [self.navigationController pushViewController:[SignInViewController new] animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -- button 
//更多的新闻（三个点）
-(void)moreNews:(UIButton *)sender{
    if (self.newsArr.count < 1) {
        [SLAlertView showAlertWithStatusString:@"暂无新闻数据"];
        return;
    }else{
        NewsCenterVC *newsVC = [[NewsCenterVC alloc]init];
        newsVC.newsArr = self.newsArr;
        [self.navigationController pushViewController:newsVC animated:YES];
    }
}
//消息推送
-(void)newsPush:(UIButton *)sender{
    if (self.newsArr.count < 1) {
        [SLAlertView showAlertWithStatusString:@"暂无新闻数据!"];
        return;
    }else{
        PublicViewController *Publec = [[PublicViewController alloc]init];
        NewsModel *model = self.newsArr[0];
        Publec.idName = @"news_id";
        Publec.contentText = model.news_content;
        Publec.contentTitleText = model.news_title;
        Publec.contentId = model.news_id;
        Publec.pageTitle = model.news_title;
        [self.navigationController pushViewController:Publec animated:YES];
    }
    
}
//邀请
-(void)invite:(UIButton *)sender{
    NSLog(@"点击邀请");
    NSString *name = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_name"];
    if ([name isEqualToString:@"未认证"]) {
        void(^block)() = ^(){
        };
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"对不起，您还没有认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block,block2]];
        //[self.prompt makePromptWithTitle:@"提示" message:@"请认证后投资" buttonleft:@"取消" buttonright:@"去认证"];
        return;
    }
    
    InviteViewController *investVC = [[InviteViewController alloc]init];
    investVC.myCount = self.myCount;
    
    [self.navigationController pushViewController:investVC animated:YES];
}
//往期回顾
-(void)agoPro:(UIButton *)sender{

    AgoProtectVC *agoVC = [[AgoProtectVC alloc]init];
    
    [self.navigationController pushViewController:agoVC animated:YES];
}
//投资
-(void)invest:(UIButton *)sender{
    NSLog(@"%.2f",[rateStr floatValue]);
    if ([rateStr floatValue] >= 100) {
        [SLAlertView showAlertWithStatusString:@"该期已满,请等待下期..."];
        return;
    }
    InvestViewController *investVC = [[InvestViewController alloc]init];
    investVC.productDic = self.productDic;
    investVC.rateStr = rateStr;
    investVC.canInvestMoney = canInvestMoney;
    [self.navigationController pushViewController:investVC animated:YES];
    NSLog(@"立即投资");
}

//查看投资项目
-(void)version:(UIButton *)sender{

    DetailViewController *detail = [[DetailViewController alloc]init];
    detail.productDic = self.productDic;
    detail.productArray = self.productArray;
    detail.rateStr = rateStr;
    detail.canInvestMoney = canInvestMoney;
    [self.navigationController pushViewController:detail animated:YES];
}
//获取理财产品信息跟新闻消息
-(void)getProData{
    
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\"}",tokoen];
    [IKHttpTool postWithURL:@"getLastProduct" params:@{@"json":param} success:^(id json) {
        
        self.productDic = [NSDictionary dictionary];
        NSDictionary *dic = json[@"data"];
        
        NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
        NSString *productName = [userDefaults objectForKey:@"productNameDefault"];
        if (productName != nil) {
            if (![productName isEqualToString:dic[@"product_name"]]) {
                NSString *productName = dic[@"product_name"];
                [userDefaults setObject:productName forKey:@"productNameDefault"];
                [[UserData sharedUserData] refreshProducts];
            }
        } else {
            NSString *productName = dic[@"product_name"];
            [userDefaults setObject:productName forKey:@"productNameDefault"];
            [[UserData sharedUserData] refreshProducts];
        }
        self.productDic = dic;
        [self setData:dic];
        [ShareViewController sharedViewController].rateStr = dic[@"product_rate"];
    } failure:^(NSError *error) {
        
    }];
    
    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"newsArrDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天
    if ([dateString isEqualToString:nowDataString]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].newsArr) {
            self.newsArr = [NSMutableArray array];
            for (NSDictionary *dic in [UserData sharedUserData].newsArr) {
                NewsModel *news = [[NewsModel alloc]init];
                news = [NewsModel objectWithKeyValues:dic];
                [self.newsArr addObject:news];
            }
            //textView.textArr = @[[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"]];
            if (self.newsArr.count > 0) {
                [textScrollView createScrllWith:[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"] speed:kSpeed];
            }
            return;
        }
    } else {
        NSString *str = [NSString stringWithFormat:@"{\"page\":\"1\"}"];
        [IKHttpTool postWithURL:@"getNews" params:@{@"json":str} success:^(id json) {
            NSLog(@"请求newsData数据");
            
            
            [userDefaults setObject:dateString forKey:@"newsArrDateString"];
            [userDefaults synchronize];
            
            NSArray *array = json[@"data"];
            if (array) {
                [UserData sharedUserData].newsArr = array;
            }
            self.newsArr = [NSMutableArray array];
            for (NSDictionary *dic in array) {
                NewsModel *news = [[NewsModel alloc]init];
                news = [NewsModel objectWithKeyValues:dic];
                [self.newsArr addObject:news];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                //textView.textArr = @[[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"]];
                if (self.newsArr.count > 0) {
                    [textScrollView createScrllWith:[[self.newsArr objectAtIndex:0]valueForKey:@"news_summary"] speed:kSpeed];
                }
            });
            NSLog(@"------news:%@",self.newsArr);
        } failure:^(NSError *error) {
            
        }];
    }
}
//赋值
-(void)setData:(NSDictionary *)dic{
//    NewsModel *news = self.newsArr[0];
//    UILabel *label = (UILabel *)[self.view viewWithTag:1000];
//    label.text = news.news_title;
    
    NSString *allmoneyText = [NSString stringWithFormat:@"项目总金额:%.0f万",[dic[@"product_sum"] doubleValue] / 10000];
    
    allmoney.text = allmoneyText;
    
    //改变按钮
    NSString *status = dic[@"product_status"];
    //status = @"0";
    if ([status isEqualToString:@"1"]) {
        investBtn.enabled = true;
        [investBtn setBackgroundImage:[UIImage imageNamed:@"redbackimg"] forState:(UIControlStateNormal)];
        
    }else if([status isEqualToString:@"0"]){
        investBtn.enabled = false;
        [investBtn setBackgroundImage:[UIImage imageNamed:@"graybackimg"] forState:(UIControlStateNormal)];
    }
    
    //0 < 475/1000000 < 0.01%
    
    //NSString *rateStr = [NSString stringWithFormat:@"%.2f",(];
    
    double rateNum = 0.0;
    
    rateNum = [dic[@"product_now"] doubleValue]/[dic[@"product_sum"] doubleValue] * 100;
    
    if (rateNum > 0 && rateNum <0.01) {
        rateNum = 0.01;
    }
    
    double rates = floor(rateNum*100)/100;
    rateStr = [NSString stringWithFormat:@"%.2f%%",rates];
    
    NSString *productstr = [NSString stringWithFormat:@"%f",[dic[@"product_sum"] doubleValue] - [dic[@"product_now"] doubleValue]];
    double productsum = yTwoPointDouble(productstr);
    canInvestMoney = [NSString stringWithFormat:@"%.2f",productsum];
    
    [self.allMoney setTitle:rateStr forState:(UIControlStateNormal)];

    //水的高度
    NSLog(@"水的高度 ================== %f",rateNum);
    self.waterView.waterPercent = rateNum / 100;
    if (rateNum >= 100) {
        self.waterView.waterPercent = 1.0;
        rateStr = [NSString stringWithFormat:@"%.2f%%",100.0];
        NSLog(@"%.2f",[rateStr floatValue]);
        [investBtn setBackgroundColor:[UIColor colorWithHexString:@"bcbcbc"]];
    }

//    [self.allMoney setTitle:dic[@"product_sum"] forState:(UIControlStateNormal)];
    NSString *profitString = [[NSString stringWithFormat:@"%.2lf" , [dic[@"product_rate"] doubleValue]] stringByAppendingString:@"%"];
    [self.profit setTitle:profitString forState:UIControlStateNormal];
    [self.versionBtn setTitle:dic[@"product_name"] forState:(UIControlStateNormal)];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getData];
    self.navigationController.navigationBar.hidden = YES;
}
-(void)getData{
    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param} success:^(id json) {
    NSString *capitilMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"base_investment"]];
        //self.allcount = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_capital"]];
        NSString *allProft = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_profit"]];//总收益
        NSString *avalibleMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"sina_balance"]];//可用金额
        NSString *allcount = [NSString stringWithFormat:@"%f",[capitilMoney floatValue]+[avalibleMoney floatValue]];//总收益
        self.myCount = [NSString stringWithFormat:@"%0.2f",[allcount floatValue]];
        //[self.tableView reloadData];
        _zongshouyi = [allProft doubleValue];
        _zhanghuyue = [avalibleMoney doubleValue];
        
    } failure:^(NSError *error) {
        
    }];
//    [IKHttpTool postWithURL:@"queryBalance" params:@{@"json":param} success:^(id json) {
//        self.myCount = [NSString stringWithFormat:@"%@元",json[@"data"][@"balance"]];
//    } failure:^(NSError *error) {
//        
//    }];
}

//获取活动信息
- (void)getActiveData
{
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\"}",tokoen];
    [IKHttpTool postWithURL:@"fetchActiveList" params:@{@"json":param} success:^(id json) {
        
        NSArray *arr = json[@"data"];
        for (NSDictionary *dic in arr) {
            ActivityModel *model = [[ActivityModel alloc]init];
            model = [ActivityModel objectWithKeyValues:dic];
            
            if([model.active_status isEqualToString:@"1"]){
                self.activeModel = model;
                return ;
            }
            
        }
        
    } failure:^(NSError *error) {
        
    }];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self getProData];//获取理财信息
    
    [textView rollingTextViewAnimationStart];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    

    [textView rollingTextViewAnimationPause];
    
}

#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    NSLog(@"---点击了第%ld张图片", index);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
