//
//  SafeguardViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/4.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SafeguardViewController.h"

@interface SafeguardViewController ()

@end

@implementation SafeguardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"保障方式";
    
    NSString *text = @"在保障方面，为了最大限度保证投资人的权益不受损失，E人一铺创建了投资者安全保障机制。针对投资人，北京中财银发投资基金公司对E人一铺设立2000万的平台兑付风险保证金，一旦用户出现资金不到账时，该笔保证金将会立刻运转起来，从容应对投资人的提现需求，以保证投资者能正常进行提现操作；此外，江之南融资担保有限公司针对合作第三方借款人（如易购连锁有限公司），进行了担保，一旦合作的第三方借款人发生还款不及时，将由江之南融资担保有限公司进行担保垫付，以保证E人一铺获得的收益不受损失。";
    
    UITextView *label = [[UITextView alloc]initWithFrame:CGRectMake(10, 20, WINSIZEWIDTH - 20, WINSIZEHEIGHT-64)];
    label.textAlignment = NSTextAlignmentLeft;
    label.font = YFont(16);
    label.textColor = YGrayColor;
    label.editable = NO;
    label.text = text;
    [self.view addSubview:label];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
