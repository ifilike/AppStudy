//
//  NewsCenterVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "NewsCenterVC.h"
#import "NewsModel.h"

@interface NewsCenterVC()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@end
@implementation NewsCenterVC
-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, self.view.height)];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}
-(void)viewDidLoad{

    [super viewDidLoad];
    self.title = @"消息中心";
    self.view.backgroundColor = YBackGrayColor;
    [self.view addSubview:self.tableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return self.newsArr.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    return WINSIZEWIDTH/30;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/5;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        //数据
        NSDictionary *dic = [self.newsArr objectAtIndex:indexPath.section];
        
        //日期
        UILabel *dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/17, WINSIZEWIDTH/20, WINSIZEWIDTH/2, WINSIZEWIDTH/25)];
        //dateLabel.text = @"2015-11-12 15：12";
        dateLabel.text = [[dic valueForKey:@"news_time"] substringToIndex:16];
        dateLabel.textColor = YGrayColor;
        dateLabel.font = YFont(WINSIZEWIDTH/28);
        //新闻标题
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(dateLabel.x, CGRectGetMaxY(dateLabel.frame), WINSIZEWIDTH-dateLabel.x*2, WINSIZEWIDTH/10)];
        titleLabel.textColor = YGrayColor;
        titleLabel.font = YBFont(WINSIZEWIDTH/20);
        //titleLabel.text = @"这应该是个推送标题";
        titleLabel.text = [dic valueForKey:@"news_title"];
        
        [cell.contentView addSubview:dateLabel];
        [cell.contentView addSubview:titleLabel];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    //[self.navigationController pushViewController:[[PublicViewController alloc]init] animated:YES];
    PublicViewController *Publec = [[PublicViewController alloc]init];
    NewsModel *model = self.newsArr[indexPath.section];
    Publec.idName = @"news_id";
    Publec.contentText = model.news_content;
    Publec.contentTitleText = model.news_title;
    Publec.contentId = model.news_id;
    Publec.pageTitle = model.news_title;
    [self.navigationController pushViewController:Publec animated:YES];
    
}
@end
