//
//  InvestViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "InvestViewController.h"
#import "WritInfoViewController.h"
#import "SLWaterView.h"
#import "TopUpController.h"
#import "TZXQViewController.h"
#import "SLAlertView.h"

@interface InvestViewController ()
@property(nonatomic,strong)UILabel *version;//投资项目
@property(nonatomic,strong)UILabel *allMoney;//项目总金额
@property(nonatomic,strong)UILabel *profit;//收益
@property(nonatomic,strong)UITextField *investField;//投资金额
@property(nonatomic,strong)UILabel *banlace;//账户余额
@property(nonatomic,strong)SLWaterView *waterView;//波动界面
@property(nonatomic,assign)int sym;//根据状态判断事件
@end

@implementation InvestViewController
#pragma mark -- 懒加载
-(SLWaterView *)waterView{
    
    if (!_waterView) {
        _waterView = [[SLWaterView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/12, CGRectGetMaxY(self.version.frame)+WINSIZEWIDTH/19, WINSIZEWIDTH/4+WINSIZEWIDTH/20, WINSIZEWIDTH/4+WINSIZEWIDTH/20)];
        _waterView.layer.borderWidth = 2;
        _waterView.layer.borderColor = [UIColor colorWithHexString:@"fe7171"].CGColor;
    }
    return _waterView;
}
-(UILabel *)version{

    if (!_version) {
        _version = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/12, WINSIZEWIDTH/25, WINSIZEWIDTH-WINSIZEWIDTH/5, WINSIZEWIDTH/8)];
        _version.font = YBFont(WINSIZEWIDTH/20);
        _version.textColor = YGrayColor;
        _version.text = @"蒲宝宝第-期";
        _version.textAlignment = NSTextAlignmentLeft;
    }
    return _version;
}
-(UILabel *)allMoney{

    if (!_allMoney) {
        _allMoney = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH/4+WINSIZEWIDTH/20, WINSIZEWIDTH/4+WINSIZEWIDTH/20)];
        //_allMoney.backgroundColor = [UIColor colorWithHexString:@"fe7171"];
        _allMoney.backgroundColor = [UIColor clearColor];
        _allMoney.layer.cornerRadius = _allMoney.height/2;
        _allMoney.layer.masksToBounds = YES;
        _allMoney.font = YBFont(WINSIZEWIDTH/15);
        _allMoney.text = @"-万";
        _allMoney.textAlignment = NSTextAlignmentCenter;
        _allMoney.textColor = [UIColor whiteColor];
    }
    return _allMoney;
}
-(UILabel *)profit{

    if (!_profit) {
        _profit = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH - CGRectGetMaxX(self.waterView.frame), self.waterView.y, self.allMoney.width, self.allMoney.height)];
        _profit.backgroundColor = [UIColor colorWithHexString:@"fcc457"];
        _profit.font = self.allMoney.font;
        _profit.textAlignment = NSTextAlignmentCenter;
        _profit.textColor = [UIColor whiteColor];
        _profit.layer.cornerRadius = _profit.height/2;
        _profit.layer.masksToBounds = YES;
        _profit.text = @"-%";
    }
    return _profit;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"投资";
    self.view.backgroundColor = [UIColor whiteColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];

    [self createUI];

    [self setData:self.productDic];
    [self getData];
    // Do any additional setup after loading the view.
}

-(void)createUI{

    UILabel *allmoney = [[UILabel alloc]initWithFrame:CGRectMake(self.waterView.x-WINSIZEWIDTH/20, CGRectGetMaxY(self.waterView.frame)+WINSIZEWIDTH/100, self.allMoney.width+WINSIZEWIDTH/10, WINSIZEWIDTH/10)];
    allmoney.textColor = YBlackColor;
    allmoney.font =  YFont(WINSIZEWIDTH/22);
    allmoney.textAlignment = NSTextAlignmentCenter;
    allmoney.text = [NSString stringWithFormat:@"项目总金额:%.0f万",[self.productDic[@"product_sum"] doubleValue] / 10000];
    
    UILabel *prift = [[UILabel alloc]initWithFrame:CGRectMake(self.profit.x-WINSIZEWIDTH/20, allmoney.y, allmoney.width,allmoney.height)];
    prift.textColor = YBlackColor;
    prift.textAlignment = NSTextAlignmentCenter;
    prift.font = allmoney.font;
    prift.text = @"年化收益";
    //投资金额
    UILabel *canInvest = [[UILabel alloc]initWithFrame:CGRectMake(self.version.x, CGRectGetMaxY(allmoney.frame)+WINSIZEWIDTH/10, WINSIZEWIDTH/2 - WINSIZEWIDTH / 25, allmoney.height)];
    canInvest.text = @"剩余可投金额：";
    canInvest.textColor = YBlackColor;
    canInvest.font = YFont(WINSIZEWIDTH/18);
    UILabel *canInvestL = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(canInvest.frame), canInvest.y+WINSIZEWIDTH/100, WINSIZEWIDTH/1.5, canInvest.height-WINSIZEWIDTH/50)];
    canInvestL.textColor = YBlackColor;
    canInvestL.font = canInvest.font;
    CGFloat abc = yTwoPointDouble(self.canInvestMoney);
    canInvestL.text = [NSString stringWithFormat:@"%.2lf 元",abc] ;
    [self.view addSubview:canInvest];
    [self.view addSubview:canInvestL];
    
    //投资金额
    UILabel *invest = [[UILabel alloc]initWithFrame:CGRectMake(canInvest.x, CGRectGetMaxY(canInvest.frame)+WINSIZEWIDTH/10, WINSIZEWIDTH/3, canInvest.height)];
    invest.text = @"投资金额：";
    invest.textColor = YBlackColor;
    invest.font = YFont(WINSIZEWIDTH/18);
    self.investField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(invest.frame), invest.y+WINSIZEWIDTH/100, WINSIZEWIDTH/2, invest.height-WINSIZEWIDTH/50)];
    self.investField.leftViewMode = UITextFieldViewModeAlways;
    self.investField.leftView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30, 0, WINSIZEWIDTH/30, self.investField.height)];
    self.investField.layer.borderWidth = 1;
    self.investField.layer.borderColor = YShawGrayColor.CGColor;
    self.investField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    
    //我的账户余额
    UILabel *myBanlance = [[UILabel alloc]initWithFrame:CGRectMake(invest.x, CGRectGetMaxY(invest.frame)+WINSIZEWIDTH/10, WINSIZEWIDTH/2-WINSIZEWIDTH/5, invest.height)];
    myBanlance.textColor = YBlackColor;
    myBanlance.font = YFont(WINSIZEWIDTH / 18);
    myBanlance.text = @"账户余额：";
    self.banlace = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(myBanlance.frame)-WINSIZEWIDTH/40, myBanlance.y, WINSIZEWIDTH/3 + 15, myBanlance.height)];
   // self.banlace.backgroundColor = YRedColor;
    self.banlace.textColor = YBlackColor;
    self.banlace.font = myBanlance.font;
    self.banlace.text = @"-元";
    
    
    //充值
    UIButton *topUp = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-invest.x-myBanlance.height*2+WINSIZEWIDTH/20, myBanlance.y, myBanlance.height*2, myBanlance.height)];
    [topUp setTitle:@"充值" forState:(UIControlStateNormal)];
    [topUp setTitleColor:YRedColor forState:(UIControlStateNormal)];
    [topUp setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    topUp.titleLabel.font = YBFont(WINSIZEWIDTH/17);
    [topUp addTarget:self action:@selector(topUp:) forControlEvents:(UIControlEventTouchUpInside)];
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, CGRectGetMaxY(topUp.frame)+WINSIZEWIDTH/8, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    investBtn.backgroundColor = YRedColor;
    [investBtn setTitle:@"确认投资" forState:(UIControlStateNormal)];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/19);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius=WINSIZEWIDTH/100;
    
//    self.waterView.waterPercent = 0.5;
    [self.waterView addSubview:self.allMoney];
    [self.view addSubview:investBtn];
    [self.view addSubview:topUp];
    [self.view addSubview:myBanlance];
    [self.view addSubview:self.banlace];
    [self.view addSubview:self.investField];
    [self.view addSubview:allmoney];
    [self.view addSubview:prift];
    [self.view addSubview:invest];
    [self.view addSubview:self.version];
    [self.view addSubview:self.waterView];
    [self.view addSubview:self.profit];
}
-(void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
    [self getData];
    
#warning 判断当前 标 剩余可投余额 少于100 时如何操作
    //判断 剩余可投余额 少于100 时
    if ([self.canInvestMoney floatValue] < 100) {
        self.investField.text = [NSString stringWithFormat:@"%.2f ",[self.canInvestMoney floatValue]];
        [SLAlertView showAlertWithStatusString:[NSString stringWithFormat:@"该期剩余可投金额为%@ 元",self.investField.text]];
        self.investField.enabled = false;
    }
    
    
    
}
- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//确认投资
-(void)invest:(UIButton *)sener{
    sener.enabled = NO;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        sener.enabled = YES;
    });
    
    //[SLAlertView showAlertWithMessageString:@"请稍候..."];
    [self.view endEditing:true];
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *name = [userdefault objectForKey:@"user_name"];
    if ([name isEqualToString:@"未认证"]) {
        void(^block)() = ^(){
        };
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"对不起，您还没有认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block,block2]];
        //[self.prompt makePromptWithTitle:@"提示" message:@"请认证后投资" buttonleft:@"取消" buttonright:@"去认证"];
        self.sym = 3;
        return;
    }
    if (self.investField.text.length<1) {
        [SLAlertView showAlertWithStatusString:@"投资金额不能为空"];
        //[self.prompt showPromptWithTitle:@"error" message:@"   投资金额不能为空" buttonleft:nil buttonright:nil];
        return;
    }
    if ([self.investField.text floatValue] < 0.1) {
        [SLAlertView showAlertWithStatusString:@"您的投资金额过低"];
        return;
    }
    if ([self.investField.text floatValue]>[self.banlace.text floatValue]) {
        [SLAlertView showAlertWithStatusString:@"投资金额不得高于您账户可用余额"];
        return;
    }
    
    if ([self.investField.text floatValue]<100 && [self.canInvestMoney floatValue] >= 100) {
        [SLAlertView showAlertWithStatusString:@"投资金额最低一百起"];
        return;
    }
    
    [SLAlertView showAlertWithMessageString:@"请稍候..."];
  //  [MBProgressHUD showMessage:@"请稍后"];
   
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"queryWithholdAuthority" params:@{@"json":param} success:^(id json) {//看用户是否授权
//        [MBProgressHUD hideHUD];
        [SLAlertView showAlertWithMessageString:@"请稍候..."];
        NSString *hordStatu = [NSString stringWithFormat:@"%@",json[@"data"][@"is_withhold_authoity"]];
        if([hordStatu isEqualToString:@"Y"]){//已授权
           // NSString *param = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\",\"summary\":\"投资%@\",\"amount\":\"%@\",\"product_id\":\"%@\",\"out_trade_code\":\"1001\",\"product_name\":\"%@\"}",user_id,token,self.productDic[@"product_name"],self.investField.text,self.productDic[@"product_id"],self.version.text];
            NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\",\"summary\":\"%@\",\"amount\":\"%@\",\"product_id\":\"%@\",\"product_name\":\"%@\"}",user_phone,token,self.productDic[@"product_name"],self.investField.text,self.productDic[@"product_id"],self.version.text];
            
            [IKHttpTool postWithURL:@"createHostingCollectTrade" params:@{@"json":param} success:^(id json) {
                //[SLAlertView hide];

                [self getData];
                void(^block)() = ^(){
                    
                };
//                [SLAlertView showAlertWithImage:[UIImage imageNamed:@"投资成功"] withButtonTitles:@[@"返回"] andBlocks:@[block]];
                [SLAlertView showAlertWithImage:[UIImage imageNamed:@"投资成功"]];
                //[self.prompt showPromptWithTitle:@"tishi" message:@"您已投资成功，感谢您的参与" buttonleft:nil buttonright:nil];
                
                //投资成功展示详情
                TZXQViewController *tzxqVC = [[TZXQViewController alloc]init];
                tzxqVC.models = [NSMutableArray array];
                NSMutableString *date = [NSMutableString stringWithFormat:@"%@",[json[@"data"][@"response_time"]substringWithRange:NSMakeRange(0, 8) ]];
                [date insertString:@"-" atIndex:4];
                [date insertString:@"-" atIndex:7];

                tzxqVC.models = [@[self.version.text,[self.investField.text stringByAppendingString:@"元"],date,@"提交成功"]mutableCopy];
                [self.navigationController pushViewController:tzxqVC animated:YES];
                
            } failure:^(NSError *error) {
                
                //[self.prompt showPromptWithTitle:@"error" message:@"  投资失败" buttonleft:nil buttonright:nil];

            }];
            
        }else{//未授权   执行代扣授权（重定向）*/
            void(^block1)() = ^(){};
            void(^block2)() = ^(){
                [SLAlertView showAlertWithMessageString:@"请稍候..."];
                NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                [IKHttpTool postWithURL:@"handleWithholdAuthority" params:@{@"json":param} success:^(id json) {
                    [SLAlertView hide];

                    WebViewController *webVC = [[WebViewController alloc]init];
                    webVC.title = @"授权";
                    webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                    [self.navigationController pushViewController:webVC animated:YES];
                } failure:^(NSError *error) {
                    
                }];
            };
            [SLAlertView hide];

            [SLAlertView showAlertWithStatusString:@"请获取授权后投资" withButtonTitles:@[@"取消",@"去授权"] andBlocks:@[block1,block2]];
            
          //  [self.prompt makePromptWithTitle:@"提示" message:@"请获取授权后投资" buttonleft:@"取消" buttonright:@"去授权"];
        }
    } failure:^(NSError *error) {
        
    }];
    
   // [SLAlertView showAlertWithStatusString:@"确认投资"];
    //[MBProgressHUD showSuccess:@"确认投资"];
}

//充值
-(void)topUp:(UIButton *)sender{

    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *name = [userdefault objectForKey:@"user_name"];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    if ([name isEqualToString:@"未认证"]) {
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"请您先认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
        //[self.prompt makePromptWithTitle:@"提示" message:@"请先认证" buttonleft:@"取消" buttonright:@"去认证"];
        self.sym = 2;
        return;
    }else{
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"queryIsSetPayPassword" params:@{@"json":str} success:^(id json) {
        NSString *status = [NSString stringWithFormat:@"%@",json[@"data"][@"is_set_paypass"]];
        if ([status isEqualToString:@"Y"]) {
            [self.navigationController pushViewController:[TopUpController new] animated:YES];
        }else{
            void(^blcok1)() = ^(){};
            void(^block2)() = ^(){
                [SLAlertView showAlertWithMessageString:@"请稍候..."];
                //[MBProgressHUD showMessage:@"请稍后"];
                NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":param} success:^(id json) {
                    [SLAlertView hide];
                    //        [MBProgressHUD hideHUD];
                    WebViewController *webVC = [[WebViewController alloc]init];
                    webVC.title = @"设置支付密码";
                    webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                    [self.navigationController pushViewController:webVC animated:YES];
                } failure:^(NSError *error) {
                    
                }];
            };
            [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[blcok1,block2]];
//            [self.prompt makePromptWithTitle:@"提示" message:@"请先设置支付密码" buttonleft:@"取消" buttonright:@"去设置"];
//            self.sym = 0;
        }

        return ;
    } failure:^(NSError *error) {
        return ;
    }];

    
    }    // [self.navigationController pushViewController:[[WritInfoViewController alloc]init] animated:YES];
}
-(void)keyboardWillShow:(NSNotificationCenter *)center{

    self.view.y = -WINSIZEWIDTH/4;
}
-(void)keyboardWillHide:(NSNotificationCenter *)center{

    self.view.y = CGRectGetMaxY(self.navigationController.navigationBar.frame);
}
//-(void)actionWithButtonIndex:(NSInteger)buIndex{
//
//    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
//    NSString *user_id = [userdefault objectForKey:USER_ID];
//    NSString *token = [userdefault objectForKey:TOKEN];
//    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
//    if (self.sym==1) {//获取代扣授权
//    }else if(self.sym == 0){//设置支付密码
//        [SLAlertView showAlertWithMessageString:@"请稍后"];
//        //[MBProgressHUD showMessage:@"请稍后"];
//    NSString *param = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\"}",user_id,token];
//    [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":param} success:^(id json) {
//        [SLAlertView hide];
////        [MBProgressHUD hideHUD];
//        WebViewController *webVC = [[WebViewController alloc]init];
//        webVC.title = @"设置支付密码";
//        webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
//        [self.navigationController pushViewController:webVC animated:YES];
//    } failure:^(NSError *error) {
//        
//    }];
//    }else if(self.sym==3){
//        [self.navigationController pushViewController:[[WritInfoViewController alloc]init] animated:YES];
//    }else if(self.sym == 2){
//        [self.navigationController pushViewController:[[WritInfoViewController alloc]init] animated:YES];
//
//    }
//}
-(void)setData:(NSDictionary *)dic{

    self.waterView.waterPercent = [self.rateStr floatValue] / 100;
    //self.version.text = dic[@"product_name"];
    CGFloat a = yTwoPointDouble(self.rateStr);
    self.allMoney.text = [NSString stringWithFormat:@"%.2lf%%",a];
    if ([[NSString stringWithFormat:@"%@",dic[@"product_name"]] isEqualToString:@"(null)"]) {
        self.version.text = @"铺宝宝-期";
    }else{
        self.version.text = [NSString stringWithFormat:@"%@",dic[@"product_name"]];
    }
    CGFloat b = yTwoPointDouble(dic[@"product_rate"]);
    self.profit.text = [NSString stringWithFormat:@"%.2lf%%",b];
}
//获取余额
-(void)getData{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param} success:^(id json) {
        NSString *banlance = [NSString stringWithFormat:@"%@",json[@"data"][@"sina_balance"]];
        CGFloat abc = yTwoPointDouble(banlance);
        self.banlace.text = [NSString stringWithFormat:@"%0.2lf元",abc];
       
    } failure:^(NSError *error) {
        
    }];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
