//
//  InviteViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/5.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InviteViewController : UIViewController

@property (nonatomic,strong)NSString *myCount;  //账户总资产

@end
