//
//  AgoProtectVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AgoProtectVC.h"
#import "AgoProCell.h"
#import "UserData.h"

@interface AgoProtectVC()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong)UITableView *tableView ;
@property (nonatomic,strong)NSMutableArray *productArray;//往期列表
@end
@implementation AgoProtectVC

-(void)viewDidLoad{
    
    [super viewDidLoad];
    self.title = @"往期项目";
    
    _productArray = [NSMutableArray array];
    
    [self createUI];
    self.view.backgroundColor = YBackGrayColor;
    [self headerRefreshing];
}
-(void)createUI{

    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, self.view.height - 64)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [[UIView alloc]init];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.tableView addHeaderWithTarget:self action:@selector(headerRefreshing)];
    // dateKey用于存储刷新时间，可以保证不同界面拥有不同的刷新时间
    [self.tableView addHeaderWithTarget:self action:@selector(headerRefreshing) dateKey:@"table"];
    self.tableView.headerPullToRefreshText = @"下拉可以刷新数据!";
    self.tableView.headerReleaseToRefreshText = @"松开马上刷新!";
    self.tableView.headerRefreshingText = @"数据正在刷新中,请稍候!";
    [self.view addSubview:self.tableView];
}
- (void)headerRefreshing{
    [self.productArray removeAllObjects];
    if ([UserData sharedUserData].products.count > 0) {
        [self.productArray addObjectsFromArray:[UserData sharedUserData].products];
        [self.tableView reloadData];
        [self.tableView headerEndRefreshing];
    } else {
        NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\"}",tokoen];
        [IKHttpTool postWithURL:@"showProduct" params:@{@"json":param} success:^(id json) {
            NSLog(@"请求往期产品数据");
            NSMutableArray *productsArray = [NSMutableArray array];
            NSDictionary *productDic = [NSDictionary dictionary];
            NSArray *array = json[@"data"];
            for (NSDictionary *dic in array) {
                if ([dic[@"product_status"]isEqualToString:@"1"]) {
                    productDic = dic;
                }else{
                    [self.productArray addObject:dic];
                }
            }
            [UserData sharedUserData].products = productsArray.copy;
            self.productArray = productsArray.copy;
            [self.tableView reloadData];
        } failure:^(NSError *error) {
            [self.tableView headerEndRefreshing];
        }];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.tableView headerEndRefreshing];
        });
    }
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return self.productArray.count > 0 ? self.productArray.count : 0;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    return WINSIZEWIDTH/30;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/2 - WINSIZEWIDTH/13;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    AgoProCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[AgoProCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
    }
    
    if (self.productArray.count > 0) {
        cell.limit.text = [[self.productArray objectAtIndex:indexPath.section]valueForKey:@"product_name"];
        cell.time.text = [[[self.productArray objectAtIndex:indexPath.section]valueForKey:@"product_time"] substringWithRange:NSMakeRange(0, 16)];
        cell.money.text = [NSString stringWithFormat:@"%.0f",[[[self.productArray objectAtIndex:indexPath.section]valueForKey:@"product_sum"]doubleValue] / 10000];
        cell.persons.text = [[self.productArray objectAtIndex:indexPath.section]valueForKey:@"product_people"];
        cell.profit.text = [NSString stringWithFormat:@"%@%%",[[self.productArray objectAtIndex:indexPath.section]valueForKey:@"product_rate"]];
    }else{
        cell.limit.text = @"铺宝宝0期";
        cell.time.text = @"0";
        cell.money.text = @"0";
        cell.persons.text = @"0";
        cell.profit.text = @"0%";
    }
    
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
