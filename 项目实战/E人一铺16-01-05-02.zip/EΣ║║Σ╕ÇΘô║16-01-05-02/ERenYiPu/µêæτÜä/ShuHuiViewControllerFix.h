//
//  ShuHuiViewControllerFix.h
//  ERenYiPu
//
//  Created by mac on 15/12/8.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShuHuiViewControllerFix : UIViewController
//@property (weak, nonatomic) IBOutlet UILabel *productNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *investAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *investSumLabel;
@property (weak, nonatomic) IBOutlet UILabel *interestLabel;
@property (weak, nonatomic) IBOutlet UILabel *investDateLabel;
@property (weak, nonatomic) IBOutlet UITextField *shuHuiTextField;

@property (nonatomic,strong) NSString *product_id;
@property (nonatomic,strong)NSString *benjin;   //本金
@property (nonatomic,strong)NSDictionary *dataDic;


@end
