//
//  EarningsModel.h
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EarningsModel : NSObject

@property (nonatomic,strong)NSString *profit_id;
@property (nonatomic,strong)NSString *user_phone;
@property (nonatomic,strong)NSString *profit_money;
@property (nonatomic,strong)NSString *profit_time;
@property (nonatomic,strong)NSString *product_id;
@property (nonatomic,strong)NSString *product_name;

/*
 
 
 "profit_id": "2",
 "user_phone": "15810860748",
 "profit_money": "0.00438404",
 "profit_time": "2015-11-28 00:00:00",
 "product_id": "2147483647",
 "product_name": "陈通集资平台"
 
 
 */

@end
