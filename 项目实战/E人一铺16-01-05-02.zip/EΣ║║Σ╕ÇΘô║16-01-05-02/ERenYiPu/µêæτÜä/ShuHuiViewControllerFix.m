//
//  ShuHuiViewControllerFix.m
//  ERenYiPu
//
//  Created by mac on 15/12/8.
//  Copyright © 2015年 babbage. All rights reserved.
//

#define kNowDate @"nowDateInterval"

#import "ShuHuiViewControllerFix.h"
#import "SLAlertView.h"

@interface ShuHuiViewControllerFix ()
@property (weak, nonatomic) IBOutlet UIButton *okBtn;

@end

@implementation ShuHuiViewControllerFix

- (void)viewDidLoad {
    [super viewDidLoad];
  
}

- (void)setDataDic:(NSDictionary *)dataDic
{
    _dataDic = dataDic;
    

}
#pragma mark 这个应该不需要
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
//    _okBtn.enabled = false;
//    _okBtn.backgroundColor = YGrayColor;
//    
//    NSString *nowDateStr = [self getNowDateInterval];
//    NSString *oldDateStr = [[NSUserDefaults standardUserDefaults]objectForKey:kNowDate];
//    
//    NSLog(@"1 = %@      2 = %@",nowDateStr,oldDateStr);
//    
//    if ([nowDateStr longLongValue] - [oldDateStr longLongValue] > 40) {
//        _okBtn.enabled = true;
//        _okBtn.backgroundColor = YRedColor;
//    }else{
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)([nowDateStr longLongValue] - [oldDateStr longLongValue] * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            _okBtn.enabled = true;
//            _okBtn.backgroundColor = YRedColor;
//        });
//    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    _okBtn.enabled = false;
    [_okBtn setBackgroundImage:[UIImage imageNamed:@"graybackimg"] forState:UIControlStateDisabled];
    
    NSString *nowDateStr = [self getNowDateInterval];
    NSString *oldDateStr = [[NSUserDefaults standardUserDefaults]objectForKey:kNowDate];
    
    NSLog(@"1 = %@      2 = %@",nowDateStr,oldDateStr);
    
    if ([nowDateStr doubleValue] - [oldDateStr doubleValue] > 60) {
        _okBtn.enabled = true;
        //_okBtn.backgroundColor = YRedColor;
        [_okBtn setBackgroundImage:[UIImage imageNamed:@"redbackimg"] forState:UIControlStateNormal];
    }else{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(([nowDateStr doubleValue] - [oldDateStr doubleValue] ) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            _okBtn.enabled = true;
            [_okBtn setBackgroundImage:[UIImage imageNamed:@"redbackimg"] forState:UIControlStateNormal];
            //_okBtn.backgroundColor = YRedColor;
        });
    }
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.okBtn.backgroundColor = YRedColor;
    self.okBtn.layer.cornerRadius = WINSIZEWIDTH/80;
    self.shuHuiTextField.layer.cornerRadius = WINSIZEWIDTH/80;
    self.shuHuiTextField.layer.borderColor = YGrayColor.CGColor;
    self.shuHuiTextField.layer.borderWidth = 1.5;
   // self.productNameLabel.text = [NSString stringWithFormat:@"%@",_dataDic[@"product_name"]];
    NSLog(@"++++ %@",_dataDic);
    float moey = yTwoPointDouble(_dataDic[@"invest_amount"]);
    //[_dataDic[@"invest_amount"] floatValue];
    NSLog(@"%f",moey);

    float invest =  yTwoPointDouble(_dataDic[@"interest"]);

    //severa.text = dic[@"product_name"];
    //date.text = [dic[@"invest_time"] componentsSeparatedByString:@" "][0];
    // tradLa.text = [NSString stringWithFormat:@"%0.2f",invest+moey];
    
    self.investAmountLabel.text = [NSString stringWithFormat:@"%.2f",moey];
    self.investDateLabel.text = [_dataDic[@"invest_time"] componentsSeparatedByString:@" "][0];
    CGFloat b = yTwoPointDouble(self.benjin);
    self.investSumLabel.text = [NSString stringWithFormat:@"%0.2lf",b];
    self.interestLabel.text = [NSString stringWithFormat:@"%@%%",_dataDic[@"interest"]];
    self.product_id = [NSString stringWithFormat:@"%@",_dataDic[@"product_id"]];
    
}
#warning 12月24号晚11点 修改了赎回需要设置支付密码的条件
- (IBAction)shuHuiButtonCLick:(UIButton *)sender {
    NSLog(@"确认赎回");
    
    if ([self.shuHuiTextField.text floatValue] <= 0) {
        [SLAlertView showAlertWithStatusString:@"请输入有效的金额"];
        return;
    }
    
    
    if ([self.shuHuiTextField.text floatValue]>[self.investSumLabel.text floatValue]) {
        [SLAlertView showAlertWithStatusString:@"赎回金额不得大于本息总额"];
        
        return;
    }
    
    if (self.shuHuiTextField.text.length < 1) {
        [SLAlertView showAlertWithStatusString:@"赎回金额不得为空"];
        return;
    }
    
    
    _okBtn.enabled = false;
    [_okBtn setBackgroundImage:[UIImage imageNamed:@"graybackimg"] forState:UIControlStateDisabled];
    
//    _okBtn.backgroundColor = YGrayColor;
    [self.view endEditing:YES];
    
    NSString *nowDateStr = [self getNowDateInterval];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:nowDateStr forKey:kNowDate];
    NSLog(@"%@",[userDefaults objectForKey:kNowDate]) ;
    NSString *user_phone = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_phone"];
    NSString *token = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(60 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        _okBtn.enabled = true;
        [_okBtn setBackgroundImage:[UIImage imageNamed:@"redbackimg"] forState:UIControlStateNormal];
    });
    
    [SLAlertView showAlertWithMessageString:@"请稍侯..."];
    [IKHttpTool postWithURL:@"modifyPaypassword" params:@{@"json":str} success:^(id json) {
        [SLAlertView hide];
        //            [MBProgressHUD hideHUD];
        NSString *status = [NSString stringWithFormat:@"%@",json[@"status"]];
        
        if ([status isEqualToString:@"1"]) {//如果有支付密码
            
//            if ([self.shuHuiTextField.text floatValue]>[self.investSumLabel.text floatValue]) {
//                [SLAlertView showAlertWithStatusString:@"赎回金额不得大于本息总额"];
//                
//                return;
//            }
//            
//            if (self.shuHuiTextField.text.length < 1) {
//                [SLAlertView showAlertWithStatusString:@"赎回金额不得为空"];
//                return;
//            }
            
            
            //_okBtn.backgroundColor = YGrayColor;
            
//            NSString *nowDateStr = [self getNowDateInterval];
//            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//            
//            NSString *oldDateStr = [userDefaults objectForKey:kNowDate];
//            if ([nowDateStr longLongValue] - [oldDateStr longLongValue] > 18) {
//                [userDefaults setObject:nowDateStr forKey:kNowDate];
//            }else{
//                //[userDefaults setObject:nowDateStr forKey:kNowDate];
//                [SLAlertView showAlertWithStatusString:@"您的操作过快,请稍后再试"];
//                return;
//            }
            //赎回金额不得小于100
            //            if ([self.shuHuiTextField.text floatValue] < 100 ) {
            //                [SLAlertView showAlertWithStatusString:@"赎回金额不得小于100"];
            //                return;
            //            }
            /**赎回到存钱罐*/
            //用户的 user_phone  金额 amount   备注： summary   产品id product_id
            // public function createSingleHostingPayTrade(){
            NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
            NSString *user_phone = [userdefault objectForKey:USER_PHONE];
            NSString *token = [userdefault objectForKey:TOKEN];
            NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"amount\":\"%@\",\"summary\":\"赎回\",\"product_id\":\"%@\",\"token\":\"%@\"}",user_phone,self.shuHuiTextField.text,self.product_id,token];
            [SLAlertView showAlertWithMessageString:@"请稍候..."];
            [IKHttpTool postWithURL:@"createSingleHostingPayTrade" params:@{@"json":param} success:^(id json) {
                // [SLAlertView hide];
                if ([json[@"status"] intValue] == 1) {
                    [SLAlertView showAlertWithStatusString:@"提交成功"];
                    [self.navigationController popToRootViewControllerAnimated:YES];

                }else{
                    [self.navigationController popToRootViewControllerAnimated:YES];

                }
                
                
            } failure:^(NSError *error) {
                [SLAlertView showAlertWithStatusString:@"提交失败"];
                [self.navigationController popToRootViewControllerAnimated:YES];
                
            }];
            
        }else{//如果没有支付密码
            void(^block)() = ^(){
            };
            void(^block2)() = ^(){
                 [SLAlertView showAlertWithMessageString:@"请稍侯..."];
                // [MBProgressHUD showMessage:@"请稍后"];
                NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                NSString *token = [userdefault objectForKey:TOKEN];
                NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                    [SLAlertView hide];
                    //        [MBProgressHUD hideHUD];
                    WebViewController *webVC = [[WebViewController alloc]init];
                    webVC.title = @"设置支付密码";
                    webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                    [self.navigationController pushViewController:webVC animated:YES];
                } failure:^(NSError *error) {
                    
                }];
            };
            [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];
        }
        
        return ;
    } failure:^(NSError *error) {
        return ;
    }];
}
-(void)keyboardShow:(NSNotification *)notification{

    self.view.y = -WINSIZEWIDTH/8;
}
-(void)keyboardHide:(NSNotification *)notication{

    self.view.y = 64;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

#pragma mark - 获取当前时间的时间戳
- (NSString *)getNowDateInterval
{
    NSDate *date = [NSDate date];
    long timeSp = (long)[date timeIntervalSince1970];
    return [NSString stringWithFormat:@"%ld",(long)timeSp];
}


@end
