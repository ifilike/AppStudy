//
//  QDSYModel.h
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QDSYModel : NSObject

@property (nonatomic,strong)NSString *Id;
@property (nonatomic,strong)NSString *user_phone;
@property (nonatomic,strong)NSString *time;
@property (nonatomic,strong)NSString *in_profit;

@end
