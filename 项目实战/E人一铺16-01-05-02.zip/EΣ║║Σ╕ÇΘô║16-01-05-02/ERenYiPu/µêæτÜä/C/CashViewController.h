//
//  CashViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CashViewController : UIViewController
@property (nonatomic,strong) NSString *goods_id;//产品id
@property (nonatomic,strong) NSString *count;//总资金
@property (nonatomic,strong) NSArray *cardData;//银行卡信息
@property (nonatomic,strong) NSString *capitialMoney;//本金
@end
