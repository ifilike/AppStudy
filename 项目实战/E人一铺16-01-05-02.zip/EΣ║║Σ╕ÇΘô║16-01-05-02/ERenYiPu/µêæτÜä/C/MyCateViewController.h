//
//  MyCateViewController.h
//  MyCateViewController
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCateViewController : UIViewController

@property (nonatomic,strong)NSArray *cardListArr;
@end
