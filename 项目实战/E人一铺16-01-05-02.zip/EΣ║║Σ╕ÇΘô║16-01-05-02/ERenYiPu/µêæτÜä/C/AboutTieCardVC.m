//
//  AboutTieCardVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/14.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AboutTieCardVC.h"
#import "TieCardViewController.h"
#import "WritInfoViewController.h"
#import "BankCardCellTableViewCell.h"
#import "SLAlertView.h"
@interface AboutTieCardVC ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *cardArr;
@property(nonatomic,strong)NSMutableArray *cardIDArr;//所有的银行卡编码
@property(nonatomic,strong)NSArray *allCard;//所有的银行卡
@property(nonatomic,strong)NSArray *allCardNL;//所有的银行卡简称
@property(nonatomic,strong)NSString *cardID;
@property(nonatomic,strong)NSArray *allcolorArr;

@end

@implementation AboutTieCardVC

-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/60, WINSIZEWIDTH, self.view.height-CGRectGetMaxY(self.navigationController.navigationBar.frame))];
        _tableView.delegate = self;
        _tableView.dataSource = self;
       _tableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/3)];
        if ([_tableView respondsToSelector:@selector(setSeparatorInset:)]) {
            [_tableView setSeparatorInset:(UIEdgeInsetsZero)];
        }
        if ([_tableView respondsToSelector:@selector(setLayoutMargins:)]) {
            [_tableView setLayoutMargins:(UIEdgeInsetsZero)];
        }
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        _tableView.backgroundColor = YBackGrayColor;
        UIButton *addCardBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/13, WINSIZEWIDTH/2, WINSIZEWIDTH/18)];
        [addCardBtn setBackgroundColor:[UIColor clearColor]];
        [addCardBtn setTitle:@"    添加银行卡" forState:(UIControlStateNormal)];
        [addCardBtn setImage:[UIImage imageNamed:@"add"] forState:(UIControlStateNormal)];
        addCardBtn.titleLabel.font = YBFont(WINSIZEWIDTH/20);
        [_tableView.tableFooterView addSubview:addCardBtn];
        _tableView.backgroundColor = [UIColor clearColor];
        [addCardBtn setTitleColor:YRedColor forState:(UIControlStateNormal)];
        [addCardBtn setTintColor:YRedColor];
        [addCardBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
        [addCardBtn addTarget:self action:@selector(addCard:) forControlEvents:(UIControlEventTouchUpInside)];
        UIView *lineView= [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, CGRectGetMaxY(addCardBtn.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/10, 3)] ;
        lineView.backgroundColor = YRedColor;
        lineView.layer.cornerRadius = WINSIZEWIDTH/100;
        [_tableView.tableFooterView addSubview:lineView];
        _tableView.bounces = NO;
        _tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"绑定银行卡";
    self.view.backgroundColor = YBackGrayColor;
    [self.view addSubview:self.tableView];
    
    NSString *banks = @"ICBC,CCB,ABC,BOC,COMM,CMB,CEB,GDB,CITIC,CIB,CMBC,HXB,CBHB,BCCB,BOS,CZB,EGBANK,PSBC,SHRCB,SPDB,SZPAB,BON";
    NSString *cardStr = @"工商银行(ICBC),建设银行(CCB),农业银行(ABC),中国银行(BOC),交通银行(COMM),招商银行(CMB),光大银行(CEB),广发银行(GDB),中信银行(CITIC),兴业银行(CIB),民生银行(CMBC),华夏银行(HXB),渤海银行(CBHB),北京银行(BCCB),上海银行(BOS),浙商银行(CZB),恒丰银行(EGBANK),邮政储蓄(PSBC),上海农商银行(SHRCB),浦东发展银行(SPDB),平安银行(SZPAB),南京银行(BON)";
    NSString *colorArr = @"2866ad,2f69b2,2c968d,ac1a2b,3069b2,c32625,8e2c88,ea3027,c21e02,18327d,32a053,e42f22,20478f,c01f00,f6c800,ebae00,9f7d09,34be52,214997,2866ad,ec5700,e60012";
    self.allcolorArr = [colorArr componentsSeparatedByString:@","];
    self.allCard = [cardStr componentsSeparatedByString:@","];
    self.allCardNL = [banks componentsSeparatedByString:@","];
    [self getAllCard];
    NSLog(@"color%@-%ld card:%@-%ld,ccardNL%@-%ld",self.allcolorArr,self.allcolorArr.count,self.allCard,self.allCard.count,self.allCardNL,self.allCardNL.count);
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:animated];
    [self getAllCard];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

//    if ([NSString stringWithFormat:@"%@",self.cardArr].length>10) {
//        NSLog(@"----%@  %ld",self.cardArr,self.cardArr.count);
//        return self.cardArr.count;
//    }
//    return 0;
    return self.cardArr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/3.5+WINSIZEWIDTH/50;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
//    NSString *str = self.cardArr[indexPath.row];
//    NSMutableArray *dataArr = [[str componentsSeparatedByString:@"^"]mutableCopy];
//    NSLog(@"str--%@",str);
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
//    //银行卡标识
//    UIImageView *symbolView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, WINSIZEWIDTH/12-WINSIZEWIDTH/20+WINSIZEWIDTH/200, WINSIZEWIDTH/10, WINSIZEWIDTH/10)];
//    symbolView.image = [UIImage imageNamed:@"headimage"];
//    symbolView.layer.cornerRadius = symbolView.height/2;
//    symbolView.layer.masksToBounds = YES;
//    //银行卡名字
//    UILabel *cardName = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(symbolView.frame)+WINSIZEWIDTH/20, WINSIZEWIDTH/25, WINSIZEWIDTH/2, WINSIZEWIDTH/20)];
//    cardName.text = @"北京农商银行";
//    cardName.textColor = YBlackColor;
//    cardName.font = YFont(WINSIZEWIDTH/20);
//    //银行卡尾号
//    UILabel *cardNum = [[UILabel alloc]initWithFrame:CGRectMake(cardName.x, CGRectGetMaxY(cardName.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH/2, WINSIZEWIDTH/30)];
//    cardNum.text = @"尾号2161储蓄卡";
//    cardNum.textColor = YGrayColor;
//    cardNum.font = YFont(WINSIZEWIDTH/30);
//    if (!cell) {
//        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
//        [cell setLayoutMargins:(UIEdgeInsetsZero)];
//        [cell setSeparatorInset:(UIEdgeInsetsZero)];
//        [cell.contentView addSubview:symbolView];
//        [cell.contentView addSubview:cardName];
//        [cell.contentView addSubview:cardNum];
//    }
//#pragma mark -- 待该
//    if(dataArr.count>1){
//        for (int i = 0; i<self.allCardNL.count; i++) {
//            if ([dataArr[1] isEqualToString:self.allCardNL[i]]) {
//                cardName.text = self.allCard[i];
//            }
//        }
//        NSString *card = [dataArr[2] stringByReplacingOccurrencesOfString:@"*" withString:@""];
//        cardNum.text = [NSString stringWithFormat:@"尾号%@储蓄卡",card];
//        symbolView.image = [UIImage imageNamed:dataArr[1]];
//    }
    NSString *data = self.cardArr[indexPath.row];
    BankCardCellTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[BankCardCellTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSArray *aray = [data componentsSeparatedByString:@"^"];
    cell.imageSym.image = [UIImage imageNamed:aray[1]];
    for (int i = 0; i<self.allCardNL.count; i++) {
        if ([self.allCardNL[i] isEqual:aray[1]]) {
            cell.cardName.text = [NSString stringWithFormat:@"%@",self.allCard[i]];
            NSLog(@"----%@,%@",self.allCard[i],self.allcolorArr[i]);
            cell.backView.backgroundColor = [UIColor colorWithHexString:self.allcolorArr[i]];
        }
    }
    NSMutableString *cardname = [NSMutableString stringWithFormat:@"%@",aray[2]];
    [cardname insertString:@" " atIndex:4];
    if (cardname.length >= 9) {
        [cardname insertString:@" " atIndex:9];
        
    }
    if (cardname.length >= 14) {
        [cardname insertString:@" " atIndex:14];
        
    }
    if (cardname.length >= 19) {
        [cardname insertString:@" " atIndex:19];
    }
    

    cell.cardNum.text = cardname;
    return cell;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    

    self.cardID = [NSString stringWithFormat:@"%@",self.cardIDArr[indexPath.row]];
    void(^block1)() = ^(){
    
    };
    void(^block2)() = ^(){
    
        NSLog(@"----解绑");
        UILabel *label = (UILabel *)[self.view viewWithTag:111];
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        NSString *user_id = [userdefault objectForKey:USER_ID];
        NSString *token = [userdefault objectForKey:TOKEN];
        NSString *user_phone = [userdefault objectForKey:USER_PHONE];
        NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\",\"card_id\":\"%@\"}",user_phone,token,self.cardID];
        NSLog(@"----%@",param);
        NSString *cardParam = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\"}",user_id,token];
        [SLAlertView showAlertWithMessageString:@"请稍候..."];
        [IKHttpTool postWithURL:@"unbindingBankCard" params:@{@"json":param} success:^(id json) {

            [self getAllCard];
            [SLAlertView showAlertWithStatusString:@"解绑成功"];
            NSLog(@"----cardid:%@--card:%@",self.cardIDArr,self.cardArr);
            [self.tableView reloadData];
            //                NSLog(@"-----datalist:%@,lenth:%ld",data,data.length);
            //                self.cardData = [[data componentsSeparatedByString:@"|"]mutableCopy];
            //                NSLog(@"---%@ %ld",self.cardArr,self.cardArr.count);
            //                if (self.cardData.count<1) {
            //                    if (data.length>10) {
            //                        [self.cardData addObject:data];
            //                    }
            //                }
            //                self.cardIDArr = [NSMutableArray array];
            //                for (int i = 0; i<self.cardData.count; i++) {
            //                    NSString *str = [NSString stringWithFormat:@"%@",self.cardArr[i]];
            //                    NSLog(@"----%@",str);
            //                    NSArray *array = [str componentsSeparatedByString:@"^"];
            //                    NSLog(@"++++%@ --- %@",array,array[0]);
            //                    [self.cardIDArr addObject:array[0]];
            //                }
            //                if (data.length>10) {
            //                    [self.tableView reloadData];
            //                }
        } failure:^(NSError *error) {
            NSLog(@"----------");
        }];
        //            [IKHttpTool postWithURL:@"unbindingBankCard" params:@{@"json":param} success:^(id json) {
        //                [self.prompt showPromptWithTitle:@"tishi" message:@"    删除成功" buttonleft:nil buttonright:nil];
        //        
        //            } failure:^(NSError *error) {
        //                
        //            }];
        
    };

    [SLAlertView showAlertWithStatusString:@"您确定要解绑此银行卡吗" withButtonTitles:@[@"取消",@"解绑"] andBlocks:@[block1,block2]];
}

-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return @"解 绑";
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
   
}
-(void)actionWithButtonIndex:(NSInteger)buIndex{
#pragma mark -- 解绑银行卡，待该
//    UILabel *label = (UILabel *)[self.view viewWithTag:111];
//    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
//    NSString *user_id = [userdefault objectForKey:USER_ID];
//    NSString *token = [userdefault objectForKey:TOKEN];
//    NSString *param = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\",\"card_id\":\"%@\"}",user_id,token,label.text];
//    NSLog(@"----%@",param);
//    NSString *cardParam = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\"}",user_id,token];
//    
//    [IKHttpTool postWithURL:@"queryBankCard" params:@{@"json":cardParam} success:^(id json) {
//        NSString *data = [NSString stringWithFormat:@"%@",json[@"data"][@"card_list"]];
//        NSLog(@"-----datalist:%@,lenth:%ld",data,data.length);
//        self.cardData = [[data componentsSeparatedByString:@"|"]mutableCopy];
//        NSLog(@"---%@ %ld",self.cardArr,self.cardArr.count);
//        if (self.cardData.count<1) {
//            if (data.length>10) {
//                [self.cardData addObject:data];
//            }
//        }
//        self.cardIDArr = [NSMutableArray array];
//        for (int i = 0; i<self.cardData.count; i++) {
//            NSString *str = [NSString stringWithFormat:@"%@",self.cardArr[i]];
//            NSLog(@"----%@",str);
//            NSArray *array = [str componentsSeparatedByString:@"^"];
//            NSLog(@"++++%@ --- %@",array,array[0]);
//            [self.cardIDArr addObject:array[0]];
//        }
//        if (data.length>10) {
//            [self.tableView reloadData];
//        }
//    } failure:^(NSError *error) {
//        
//    }];
//    [IKHttpTool postWithURL:@"unbindingBankCard" params:@{@"json":param} success:^(id json) {
//        [self.prompt showPromptWithTitle:@"tishi" message:@"    删除成功" buttonleft:nil buttonright:nil];
//
//    } failure:^(NSError *error) {
//        
//    }];
}
#pragma mark -- 显示自己所绑定的银行卡
-(void)getAllCard{

    self.cardIDArr = [NSMutableArray array];
    self.cardArr = [NSMutableArray array];
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"queryBankCard" params:@{@"json":param} success:^(id json) {
        NSString *data = [NSString stringWithFormat:@"%@",json[@"data"][@"card_list"]];
        NSLog(@"----%@",data);
        if (data.length>10) {
            self.cardArr = [[data componentsSeparatedByString:@"|"]mutableCopy];
            if (self.cardArr.count<1) {
                if (data.length>10) {
                    [self.cardArr addObject:data];
                }
            }
        }
        NSString *lenth2 = [NSString stringWithFormat:@"%@",self.cardArr];
        NSLog(@"-----------------%@-- %ld %ld,--%ld ata.length",self.cardArr,self.cardArr.count,lenth2.length,data.length);
        if (lenth2.length>50) {
            for (int i = 0; i<self.cardArr.count; i++) {
                NSArray *array = [self.cardArr[i] componentsSeparatedByString:@"^"];
                [self.cardIDArr addObject:array[0]];
            }
        }
        
        NSLog(@"----cardID:%ld  %ld",self.cardIDArr.count,self.cardArr.count);
            [self.tableView reloadData];
    } failure:^(NSError *error) {
    }];
}
//添加银行卡
-(void)addCard:(UIBarButtonItem*)sender{
//
//    NSString *name = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]objectForKey:@"user_name"]];
//    if ([name isEqualToString:@"未认证"]) {
//        [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
//    }else{
    [self.navigationController pushViewController:[[TieCardViewController alloc]init] animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
