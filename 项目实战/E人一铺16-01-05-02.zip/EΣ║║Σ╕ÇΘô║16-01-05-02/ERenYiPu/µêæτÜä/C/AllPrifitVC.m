//
//  AllPrifitVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/14.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AllPrifitVC.h"

@interface AllPrifitVC()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UITableView *tableview;
@end
@implementation AllPrifitVC

-(void)viewDidLoad{

    [super viewDidLoad];
    self.title = @"总收益";
    self.view.backgroundColor = YBackGrayColor;
    [self createUI];
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/2-WINSIZEWIDTH/15)];
    firstView.backgroundColor = [UIColor whiteColor];
    //总收益
    UILabel *prifit = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/26, WINSIZEWIDTH/3, WINSIZEWIDTH/10)];
    prifit.textColor = YGrayColor;
    prifit.text = @"总收益";
    prifit.font = YFont(WINSIZEWIDTH/25);
    
    UILabel *moneyLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30, WINSIZEWIDTH/7, WINSIZEWIDTH/2, WINSIZEWIDTH/8)];
    moneyLa.text = @"10000";
    moneyLa.textColor = YRedColor;
    moneyLa.font = YFont(WINSIZEWIDTH/10);
    moneyLa.textAlignment = NSTextAlignmentRight;
    
    UILabel *RMB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(moneyLa.frame)+WINSIZEWIDTH/50,CGRectGetMaxY(moneyLa.frame)-WINSIZEWIDTH/15, WINSIZEWIDTH/4, WINSIZEWIDTH/15)];
    RMB.text = @"元";
    RMB.textColor = YGrayColor;
    RMB.font = YBFont(WINSIZEWIDTH/15);
    
    [firstView addSubview:prifit];
    [firstView addSubview:moneyLa];
    [firstView addSubview:RMB];
    
    self.tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH,WINSIZEHEIGHT - CGRectGetMaxY(firstView.frame) - CGRectGetMaxY(self.navigationController.navigationBar.frame))];
    self.tableview.delegate = self;
    self.tableview.dataSource = self;
    self.tableview.backgroundColor = [UIColor clearColor];
    
    UIView *secView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH/4)];
    secView.backgroundColor = [UIColor whiteColor];
    
   
    
    [self.view addSubview:firstView];
    [self.view addSubview:self.tableview];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 6;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/4;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    return WINSIZEWIDTH/30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    //蒲宝宝第几期
    UILabel *serva = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/8-WINSIZEWIDTH/20, WINSIZEWIDTH/2, WINSIZEWIDTH/20)];
    serva.textColor = YGrayColor;
    serva.text = @"蒲宝宝第几期";
    serva.font = YFont(WINSIZEWIDTH/20);
    //日期
    UILabel *dateLa = [[UILabel alloc]initWithFrame:CGRectMake(serva.x, CGRectGetMaxY(serva.frame), WINSIZEWIDTH/2, WINSIZEWIDTH/20)];
    dateLa.text = @"2015-11-24  15：12";
    dateLa.textColor = YGrayColor;
    dateLa.font = YFont(WINSIZEWIDTH/30);
    //收益
    UILabel *currePri = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, 0, WINSIZEWIDTH/2-WINSIZEWIDTH/20, WINSIZEWIDTH/4)];
    currePri.textColor = YRedColor;
    currePri.text = @"收益100元";
    currePri.textAlignment = NSTextAlignmentRight;
    currePri.font = YFont(WINSIZEWIDTH/15);

    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        [cell.contentView addSubview:serva];
        [cell.contentView addSubview:dateLa];
        [cell.contentView addSubview:currePri];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}

@end
