//
//  BeInvitedFriendsViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/21.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "BeInvitedFriendsViewController.h"
#import "BeInvitedFriendsTableViewCell.h"
#import "SLAlertView.h"
#import "InviteViewController.h"
#define kBeInvitedCell @"beInvitedFriends"

@interface BeInvitedFriendsViewController () <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *dataArray;

@end

@implementation BeInvitedFriendsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"受邀好友";
    
    _dataArray = [NSMutableArray array];
    
    [self.view addSubview:self.tableView];
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton *inveteBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEWIDTH/30+CGRectGetMaxY(self.tableView.frame), WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    inveteBtn.backgroundColor = YRedColor;
    inveteBtn.layer.masksToBounds = YES;
    [inveteBtn setTitle:@"继续邀请" forState:(UIControlStateNormal)];
    [inveteBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [inveteBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    inveteBtn.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [inveteBtn addTarget:self action:@selector(inveteBtnClick:) forControlEvents:(UIControlEventTouchUpInside)];
    inveteBtn.layer.cornerRadius = WINSIZEWIDTH/100;
   // [inveteBtn addSubview:inveteBtn];
    
    [self.view addSubview:inveteBtn];
    
    [self getDate];
}

#pragma mark - 懒加载
- (UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT-65*2)];
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]init];
    }
    return _tableView;
}

#pragma mark - UitableView 代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView registerClass:[BeInvitedFriendsTableViewCell class] forCellReuseIdentifier:kBeInvitedCell];
    BeInvitedFriendsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kBeInvitedCell];
    if (!cell) {
        cell = [[BeInvitedFriendsTableViewCell alloc]initWithStyle:UITableViewCellStyleValue2 reuseIdentifier:kBeInvitedCell];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (_dataArray.count > 0) {
        NSDictionary *dic = [_dataArray objectAtIndex:indexPath.row];
        [cell setDate:dic];
    }
    
    return cell;
}

#pragma mark - 受邀好友数据请求
- (void)getDate
{
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]objectForKey:USER_PHONE];
    NSString *token = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",userPhone,token];
    
    [IKHttpTool postWithURL:@"myInviteFriends" params:@{@"json":param} success:^(id json) {
        
        NSArray *array = json[@"data"];
        
        _dataArray = [NSMutableArray arrayWithArray:array];
        
        [_tableView reloadData];
    } failure:^(NSError *error) {
        
        [SLAlertView showAlertWithStatusString:@"数据请求失败.."];
    }];
    
}

#pragma mark -- 继续邀请
-(void)inveteBtnClick:(UIButton*)sender{

    [self.navigationController pushViewController:[InviteViewController new] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
