//
//  TopUpController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "TopUpController.h"
#import "ChooseCardVC.h"
#import "WebViewController.h"
#import "SLAlertView.h"
#import "WritInfoViewController.h"
@interface TopUpController()<UITextFieldDelegate,UIAlertViewDelegate,PayVIeWDelegate>
@property (nonatomic,strong) UITextField *moneyField;//充值金额
@property (nonatomic,strong) UITextField *cardField;//银行卡
@property (nonatomic,strong) PayVIew *payView;
@end

@implementation TopUpController
-(PayVIew *)payView{

    if (!_payView) {
        _payView = [[PayVIew alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
        _payView.delegate = self;
    }
    return _payView;
}
-(void)viewDidLoad{

    [super viewDidLoad];
    self.title = @"充值";
    self.view.backgroundColor = YBackGrayColor;
    [self.navigationController.view addSubview:self.payView];
    self.payView.hidden = YES;
    [self createUI];
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/4-WINSIZEWIDTH/30)];
    firstView.backgroundColor = [UIColor whiteColor];
    UILabel *moneyLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/8, firstView.height)];
    moneyLal.text = @"金额";
    
    moneyLal.textColor = YGrayColor;
    moneyLal.font = YFont(WINSIZEWIDTH/20);
    self.moneyField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(moneyLal.frame)+WINSIZEWIDTH/15, 0, WINSIZEWIDTH/2, firstView.height)];
    self.moneyField.placeholder = @"请输入充值金额";
   // self.moneyField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    self.moneyField.font = moneyLal.font;
    self.moneyField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    [firstView addSubview:moneyLal];
    [firstView addSubview:self.moneyField];
    
    UIView *secView = [[UIView alloc]initWithFrame:CGRectMake(0, firstView.height+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    secView.backgroundColor = [UIColor whiteColor];
    UILabel *mothLal = [[UILabel alloc]initWithFrame:CGRectMake(moneyLal.x, 0, WINSIZEWIDTH/5, secView.height)];
    mothLal.textColor = YGrayColor;
    mothLal.text = @"付款方式";
    mothLal.font = moneyLal.font;
    UIButton *mothBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(mothLal.frame)+WINSIZEWIDTH/15, 0, WINSIZEWIDTH-WINSIZEWIDTH/4, secView.height)];
    [mothBtn setTitle:@"北京农商银行             >" forState:(UIControlStateNormal)];
    [mothBtn setTitleColor:[UIColor colorWithHexString:@"bcbcbc"] forState:(UIControlStateNormal)];
    [mothBtn addTarget:self action:@selector(chooseCard) forControlEvents:(UIControlEventTouchUpInside)];
    mothBtn.titleLabel.font = moneyLal.font;
    [secView addSubview:mothLal];
    [secView addSubview:mothBtn];
    
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/8, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8)];
    investBtn.backgroundColor = YRedColor;
    [investBtn setTitle:@"确认付款" forState:(UIControlStateNormal)];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius=WINSIZEWIDTH/100;
    
    [self.view addSubview:investBtn];
   // [self.view addSubview:secView];
    [self.view addSubview:firstView];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
//选择银行卡
-(void)chooseCard{

    [self.navigationController pushViewController:[[ChooseCardVC alloc]init] animated:YES];
}
//确认付款
-(void)invest:(UIButton *)sender{

    NSString *status = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_name"];
    if (![status isEqualToString:@"未认证"]) {
        if (self.moneyField.text.length<1) {
            [SLAlertView showAlertWithStatusString:@"充值金额不能为空"];
            //        [MBProgressHUD showError:@"充值金额不能为空"];
            return;
        }
        [self.view endEditing:YES];
        CGFloat moeny = [self.moneyField.text floatValue];
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        NSString *token = [userdefault objectForKey:TOKEN];
        NSString *user_phone = [userdefault objectForKey:USER_PHONE];
        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"amount\":\"%0.2f\",\"user_phone\":\"%@\"}",token,moeny,user_phone];
        [SLAlertView showAlertWithStatusString:@"请稍候..."];
        // [MBProgressHUD showMessage:@"请稍后..."];
        [IKHttpTool postWithURL:@"createHostingDeposit" params:@{@"json":param} success:^(id json) {
            [SLAlertView hide];
            //        [MBProgressHUD hideHUD];
            WebViewController *web = [WebViewController new];
            web.title = @"充值";
            web.webStr = [NSString stringWithFormat:@"%@",json[@"data"]];;
            [self.navigationController pushViewController:web animated:YES];
        } failure:^(NSError *error) {
            
        }];
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
    }
    
    
    

//    self.payView.hidden = NO;
//    [self.payView createUI:@"请输入您的支付密码"];
    
}
-(void)payViewDelegateButton:(NSInteger)buttonIndex textFields:(NSString *)text{

    NSLog(@"-----texss:%@",text);
    self.payView.hidden = YES;
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    UITextField *textField = [alertView textFieldAtIndex:0];
    NSLog(@"------textField:%@",textField.text);
}
@end
