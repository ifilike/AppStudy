//
//  SettingViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SettingViewController.h"
#import "WritInfoViewController.h"
#import "ResiveLoginKeyVC.h"
#import "ReplacePayKeyVC.h"
#import "LogInViewController.h"
#import "GestureController.h"
#import "AboutWeViewController.h"
#import "SLAlertView.h"
#import "RSKImageCropViewController.h"
#import<AssetsLibrary/ALAssetsLibrary.h>

#import "ETabBarViewController.h"
#import "UIImageView+WebCache.h"
#import "ShareViewController.h"
#import "MyIconImageView.h"
#import "BeInvitedFriendsViewController.h"
#import "WebViewController.h"

@interface SettingViewController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,UMSocialUIDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,RSKImageCropViewControllerDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *labArr;
@property(nonatomic,strong)NSArray *imageArr;
@property(nonatomic,assign)int sym;//根据这个判断prompt的点击事件
@property(nonatomic,strong)UIImagePickerController *imagePicker;
@property(nonatomic,strong)UIActionSheet *actionSheet;
@property(nonatomic,strong)UIImage *resultImage;

@end

@implementation SettingViewController
-(UIActionSheet *)actionSheet{
    
    if (!_actionSheet) {
        _actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相册",@"拍照",nil];
        _actionSheet.delegate = self;
    }
    return _actionSheet;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设置";
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    [self createUI];
    self.labArr = @[@"修改登录密码",@"手势密码",@"重置支付密码",@"重置代扣限额",@"联系客服",@"分享给好友",@"受邀好友",@"关于我们"];
    self.imageArr = @[@"xiugaidenglu",@"shoushi",@"zhifu",@"xiane",@"kefu",@"fenxiang",@"shouyao",@"guanyu"];
    
}
-(void)createUI{

    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT-64)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/2)];
    footView.backgroundColor = self.view.backgroundColor;
    UIButton *backCount = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEWIDTH/20, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    backCount.backgroundColor = YRedColor;
    [backCount setTitle:@"退出登录" forState:(UIControlStateNormal)];
    [backCount setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [backCount setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    backCount.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [backCount addTarget:self action:@selector(back:) forControlEvents:(UIControlEventTouchUpInside)];
    backCount.layer.cornerRadius = WINSIZEWIDTH/100;
    [footView addSubview:backCount];
    self.tableView.tableFooterView = footView;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.showsHorizontalScrollIndicator = NO;
    self.tableView.bounces = NO;
    [self.view addSubview:self.tableView];
}
#pragma mark -- tableVIew
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return self.imageArr.count+1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    if (section==8) {
        return 0;
    }
    return WINSIZEWIDTH/30;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/7-WINSIZEWIDTH/WINSIZEWIDTH;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:nil];;
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    if (indexPath.section==0) {
        UIImageView *headImage = [[MyIconImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, WINSIZEWIDTH/100, WINSIZEWIDTH/7-WINSIZEWIDTH/50, WINSIZEWIDTH/7-WINSIZEWIDTH/50)];
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        //NSString *urlString = [NSString stringWithFormat:@"%@%@", @"http://115.28.143.129/EREP/upload/hends/", picString];
        headImage.tag = 12345;
        //[headImage sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:[UIImage imageNamed:@"touxiang"]];
        headImage.image = [ShareViewController sharedViewController].image;
       // [headImage sd_setImageWithURL:[NSURL URLWithString:urlString] ];//placeholderImage:[UIImage imageNamed:@"touxiang"]];

        headImage.layer.cornerRadius = headImage.height/2;
        headImage.layer.masksToBounds = YES;
        UIButton *headBtn = [[UIButton alloc]initWithFrame:CGRectMake(headImage.x, headImage.y, headImage.width, headImage.height)];
        [headBtn setBackgroundImage:[UIImage imageNamed:@"chongzhi"] forState:(UIControlStateHighlighted)];
        headBtn.alpha = 0.3;
        [headBtn addTarget:self action:@selector(changeHead:) forControlEvents:(UIControlEventTouchUpInside)];
        
        [headImage addSubview:headBtn];

        UIButton *infoLab = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/4-WINSIZEWIDTH/50, WINSIZEWIDTH/28, WINSIZEWIDTH/5, WINSIZEWIDTH/14)];
        infoLab.layer.cornerRadius = WINSIZEWIDTH/80;
        infoLab.tag = 1000;
        [infoLab setTitle:@"立刻认证" forState:(UIControlStateNormal)];
        [infoLab setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [infoLab setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
        [infoLab addTarget:self action:@selector(userInfo:) forControlEvents:(UIControlEventTouchUpInside)];
        infoLab.titleLabel.font = YBFont(WINSIZEWIDTH/25);
        infoLab.backgroundColor = YRedColor;
        //用户名字
        UILabel *phoneLal = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(headImage.frame)+WINSIZEWIDTH/25, WINSIZEWIDTH/50, WINSIZEWIDTH/2, WINSIZEWIDTH/20)];

        phoneLal.text = [NSString stringWithFormat:@"%@",[userdefault objectForKey:@"user_name"]];
        phoneLal.textColor = YGrayColor;
        phoneLal.font = YFont(WINSIZEWIDTH/25);
        
        //是否认证
        UILabel *certy = [[UILabel alloc]initWithFrame:CGRectMake(phoneLal.x, CGRectGetMaxY(phoneLal.frame), WINSIZEWIDTH/4, phoneLal.height)];
        certy.text = @"未认证";
        certy.textColor = YRedColor;
        certy.font = YBFont(WINSIZEWIDTH/27);
        
        //判断是否认证
        if(![phoneLal.text isEqualToString:@"未认证"]){
            certy.text = @"已认证";
            [infoLab setTitle:@"已认证" forState:(UIControlStateNormal)];
            [infoLab setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
            infoLab.backgroundColor = [UIColor colorWithHexString:@"aaaaaa"];
            infoLab.enabled = NO;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell.contentView addSubview:phoneLal];
        [cell.contentView addSubview:certy];
        [cell.contentView addSubview:headImage];
        [cell.contentView addSubview:infoLab];
        [cell.contentView addSubview:headBtn];
    }
    if (indexPath.section!=0) {
//        UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/26, cell.height-WINSIZEWIDTH/13, cell.height-WINSIZEWIDTH/13)];
//        image.contentMode = UIViewContentModeScaleAspectFit;
//        NSString *imageStr = self.imageArr[indexPath.section-1];
//        image.image = [UIImage imageNamed:imageStr];
//        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20+CGRectGetMaxX(image.frame), 0, WINSIZEWIDTH/2, cell.height)];
//        label.text = self.labArr[indexPath.section-1];
//        label.textColor = YGrayColor;
//        label.font = YFont(WINSIZEWIDTH/20);
       cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//        [cell.contentView addSubview:image];
//        [cell.contentView addSubview:label];
//
        if (indexPath.section == 5) {
            cell.detailTextLabel.text = @"工作时间9:00~17:30";
        }
        cell.textLabel.text = self.labArr[indexPath.section-1];
        cell.textLabel.font = YFont(WINSIZEWIDTH/20);
        cell.textLabel.textColor =YGrayColor;
        cell.imageView.image = [UIImage imageNamed:self.imageArr[indexPath.section-1]];
    }
//    if (indexPath.section==4){
//        cell.accessoryType = UITableViewCellAccessoryNone;
//        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/2, WINSIZEWIDTH/26, WINSIZEWIDTH/2, cell.height - WINSIZEWIDTH/13)];
//        [button setTitle:@"400-625-0083" forState:(UIControlStateNormal)];
//        [button setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
//        [button addTarget:self action:@selector(callPhone) forControlEvents:(UIControlEventTouchUpInside)];
//        button.titleLabel.font = YFont(WINSIZEWIDTH/20);
//        [button setTitleColor:[UIColor colorWithHexString:@"25b2dd"] forState:(UIControlStateNormal)];
//        //[cell.contentView addSubview:button];
//    }
    return cell;
}
//点击拨打电话
-(void)callPhone{
    UIWebView*callWebview =[[UIWebView alloc] init];
    NSURL *telURL =[NSURL URLWithString:@"tel:4006250083"];
    // 貌似tel:// 或者 tel: 都行
    [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
    //记得添加到view上
    [self.view addSubview:callWebview];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_name = [userdefault objectForKey:@"user_name"];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",token,user_phone];
    NSString *payParam = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",token,user_phone];

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    void(^block1)() = ^(){
    };
    void(^block2)() = ^(){
        [SLAlertView showAlertWithStatusString:@"已是最新版本"];
    };
    void(^blockPay)() = ^(){
            [SLAlertView showAlertWithMessageString:@"请稍侯..."];
            // [MBProgressHUD showMessage:@"请稍后"];
            NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
            NSString *token = [userdefault objectForKey:TOKEN];
            NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
            [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                [SLAlertView hide];
                //        [MBProgressHUD hideHUD];
                WebViewController *webVC = [[WebViewController alloc]init];
                webVC.title = @"设置支付密码";
                webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                [self.navigationController pushViewController:webVC animated:YES];
            } failure:^(NSError *error) {
                
            }];
        };
    void(^block3)() = ^(){
        [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
    };
    switch (indexPath.section) {
        case 1:
            //修改登录密码
            [self.navigationController pushViewController:[[ResiveLoginKeyVC alloc]init] animated:YES];
            break;
        case 2:
            [self.navigationController pushViewController:[GestureController new] animated:YES];
            break;
        case 3:
            //重置支付密码
            if ([user_name isEqualToString:@"未认证"]) {
                [SLAlertView showAlertWithStatusString:@"您还没有认证，是否立即认证？" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block3]];
            }else{
            [self.navigationController pushViewController:[[ReplacePayKeyVC alloc]init] animated:YES];
            }
            break;
            case 4:
            if ([user_name isEqualToString:@"未认证"]) {
                [SLAlertView showAlertWithStatusString:@"您还没有认证，是否立即认证？" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block3]];
            }else{
                [SLAlertView showAlertWithMessageString:@"请稍侯..."];
                [IKHttpTool postWithURL:@"modifyPaypassword" params:@{@"json":payParam} success:^(id json) {
                    [SLAlertView hide];
                    //            [MBProgressHUD hideHUD];
                    NSString *status = [NSString stringWithFormat:@"%@",json[@"status"]];
                    
                    if ([status isEqualToString:@"1"]) {//如果有支付密码
                        //  [SLAlertView showAlertWithStatusString:@"请稍候..."];
                        [SLAlertView showAlertWithMessageString:@"请稍候..."];
                        // [MBProgressHUD showMessage:@"请稍后..."];
                        [IKHttpTool postWithURL:@"modifyWithholdAuthority" params:@{@"json":param} success:^(id json) {
                            [SLAlertView hide];
                            //        [MBProgressHUD hideHUD];
                            WebViewController *web = [WebViewController new];
                            web.title = @"重置代扣限额";
                            web.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];;
                            [self.navigationController pushViewController:web animated:YES];
                        } failure:^(NSError *error) {
                            [SLAlertView hide];
                        }];
                    }else{//如果没有支付密码
                        
                        [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block1,blockPay]];
                    }
                    return ;
                } failure:^(NSError *error) {
                    return ;
                }];

            }
                
                     break;
            case 5:
            [self callPhone];
            break;
            case 6:
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"5652bc2567e58e75e0003108"
                                              shareText:@"赚钱！我要稳稳的收益，就选E人一铺"
                                             shareImage:[UIImage imageNamed:@"E人一铺"]
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToQQ,UMShareToQzone,UMShareToSms,UMShareToEmail,UMShareToWechatSession,UMShareToWechatTimeline,nil]
                                               delegate:self];
            break;
            case 7:
            [self.navigationController pushViewController:[BeInvitedFriendsViewController new] animated:YES];
            
            break;
            case 8:
            //关于我们
            [self.navigationController pushViewController:[AboutWeViewController new] animated:YES];
            break;
//            case 7:
//            //版本升级
//            [SLAlertView showAlertWithStatusString:@"E人一铺新版本升级，更多体验，分分钟赚钱" withButtonTitles:@[@"取消",@"马上升级"] andBlocks:@[block1,block2]];
//           // [self.prompt makePromptWithTitle:@"版本更新" message:@"E人一铺新版本升级，更多体验，分分钟赚钱" buttonleft:@"取消" buttonright:@"马上升级"];
//            break;
        default:
            break;
    }
}
//修改头像
-(void)changeHead:(UIButton *)sender{
    
    NSLog(@"------------");
    [self.actionSheet showInView:self.view];

//    if ([ALAssetsLibrary authorizationStatus] == ALAuthorizationStatusNotDetermined) {
//        
//        ALAssetsLibrary *assetsLibrary = [[ALAssetsLibrary alloc] init];
//        
//        [assetsLibrary enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
//            
//            if (*stop) {
//                //点击“好”回调方法:这里是重点
//
//                NSLog(@"好");
//                return;
//                
//            }
//            *stop = TRUE;
//            
//        } failureBlock:^(NSError *error) {
//            
//            //点击“不允许”回调方法:这里是重点
//            NSLog(@"不允许");
//            [self dismissViewControllerAnimated:YES completion:nil];
//            
//        }];
//    }
    
}




-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    self.imagePicker = [[UIImagePickerController alloc]init];
    self.imagePicker.delegate = self;    
    self.imagePicker.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemDone) target:self action:nil];;

    //    </uigesturerecognizerdelegate>;
    //   [self.imagePicker.navigationItem.leftBarButtonItem.tintColor = (__bridge UIColor *)(YBlackColor.CGColor);
    
    if(buttonIndex==1){
        self.imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
        self.imagePicker.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemDone) target:self action:nil];;
        //        [self.navigationController pushViewController:self.imagePicker animated:YES];
        [self presentViewController:self.imagePicker animated:YES completion:nil];
    }
    if (buttonIndex==0) {
        self.imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:self.imagePicker animated:YES completion:nil];
    }
    NSLog(@"-----%ld",buttonIndex);
}
//UIImagePickerController代理
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    NSLog(@"aaa------");
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    RSKImageCropViewController *imageCrop = [[RSKImageCropViewController alloc]initWithImage:image cropMode:(RSKImageCropModeCircle)];
    //  imageCrop.applyMaskToCroppedImage = YES;
    imageCrop.delegate = self;
    [picker presentViewController:imageCrop animated:YES completion:nil];
}
#pragma mark -- RSKImageCropViewControllerDelegate
-(void)imageCropViewControllerDidCancelCrop:(RSKImageCropViewController *)controller{
    
    [controller dismissViewControllerAnimated:YES completion:nil];
}
//设置头像

-(void)imageCropViewController:(RSKImageCropViewController *)controller didCropImage:(UIImage *)croppedImage usingCropRect:(CGRect)cropRect{
    UIImage *source_img = croppedImage;
    float h = source_img.size.height;
    float w = source_img.size.width;
    CGRect targetRect;
    if (w > h) {  //(w-h)/2  --> w-(w-h)/2
        targetRect = CGRectMake((w-h)/2, 0, w, h);
    }
    else {
        targetRect = CGRectMake(0, (h-w)/2, w, h);
    }
    self.resultImage = [[UIImage alloc]init];
    CGImageRef imageRef = CGImageCreateWithImageInRect(source_img.CGImage, targetRect);
    self.resultImage = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    
    //修正回原scale和方向
    //   self.headImage.contentMode = UIViewContentModeScaleAspectFit;
    self.resultImage = [UIImage imageWithCGImage:self.resultImage.CGImage scale:source_img.scale orientation:source_img.imageOrientation];
    NSData *data = UIImageJPEGRepresentation(self.resultImage, 0.2);;;
    NSUserDefaults *userdalut = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [NSString stringWithFormat:@"%@",[userdalut objectForKey:USER_ID]];
    if (data != nil) {
        [userdalut setObject:data forKey:user_id];
    }
    [ShareViewController sharedViewController].image = [UIImage imageWithData:data];
    ((UIImageView *)[self.view viewWithTag:12345]).image = [ShareViewController sharedViewController].image;
    
//    if (self.resultImage != nil) {
//        imageview.image = self.resultImage;
//    }
    // _resultImage = [self test:_resultImage size:CGSizeMake(80, 80)];
    //    resultImage = [UIImage imageWithCGImage:resultImage.CGImage];
    // save NSData-object to UserDefaults
    
    [controller dismissViewControllerAnimated:NO completion:^{
        
        [self.imagePicker dismissViewControllerAnimated:YES completion:nil];
        
    }];
    //[NSThread detachNewThreadSelector:@selector(setheadData) toTarget:self withObject:nil];
    //self.headImage.image = self.resultImage;
    //self.headImage.image = [self circleImage:self.headImage.image withParam:WINSIZEWIDTH/100];
    // self.judge = 100;
    //R = self.resultImage;{"status":0,"msg":"\u4fee\u6539\u7528\u6237\u4fe1\u606f\u5931\u8d25\uff01"}
}

-(void)setheadData{

//        dispatch_sync(dispatch_get_main_queue(), ^{
//            UIImageView *imageview = (UIImageView *)[self.view viewWithTag:1111];
//            if
//            imageview.image = self.resultImage;
//            UIImage *headImage = [self circleImage:self.resultImage withParam:0.5];
//            NSUserDefaults *userdefatult = [NSUserDefaults standardUserDefaults];
//            NSLog(@"%@", headImage);
//                NSData *imagedata = [[NSData alloc]init];
//                 imagedata = UIImageJPEGRepresentation(headImage, 0.2f);
//                NSString *head = [imagedata base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithCarriageReturn];
//                // [userdefatult setObject:imagedata forKey:@"userhead"];
//            NSLog(@"%zi", head.length);
//                NSString *phone = [userdefatult objectForKey:USER_PHONE];
//            NSString *token = [userdefatult objectForKey:TOKEN];
//                NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\",\"user_pic\":\"%@\"}",phone,token,head];
//    
//                [IKHttpTool postWithURL:@"setPicture" params:@{@"json":str} success:^(id json) {
//                    NSString *picString = json[@"data"][@"user_pic"];
//                    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//                    [userDefaults setObject:picString forKey:@"userIconKey"];
//                    [userDefaults synchronize];
//                    
//                    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadIcon" object:nil];
//                    
//                    //[MBProgressHUD showError:@""];
//                } failure:^(NSError *error) {
//                }];
//        });

}
#pragma mark -- 头像裁剪圆形
-(UIImage*) circleImage:(UIImage*) image withParam:(CGFloat) inset {
    UIGraphicsBeginImageContext(image.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2);
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    CGRect rect = CGRectMake(inset, inset, image.size.width - inset * 2.0f, image.size.height - inset * 2.0f);
    CGContextAddEllipseInRect(context, rect);
    CGContextClip(context);
    
    [image drawInRect:rect];
    CGContextAddEllipseInRect(context, rect);
    CGContextStrokePath(context);
    UIImage *newimg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newimg;
}
-(void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{

    navigationController.navigationBar.tintColor = [UIColor whiteColor];
}
//用户认证
-(void)userInfo:(UIButton *)sender{

    [self.navigationController pushViewController:[[WritInfoViewController alloc]init] animated:YES];
}
//退出登录
-(void)back:(UIButton *)sender{

    self.sym = 20;
    void(^block1)() = ^(){
    };
    void(^block2)() = ^(){
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setObject:@"" forKey:PASSWORD];
        [userDefault setObject:@"" forKey:USER_ID];
        [userDefault setObject:@"" forKey:HAND_PASSWORD];
        [userDefault setObject:@"" forKey:TOKEN];
        //[MBProgressHUD showError:@"back"];
        [self presentViewController:[LogInViewController new] animated:YES completion:nil];
    };
    [SLAlertView showAlertWithStatusString:@"您确定要退出吗？" withButtonTitles:@[@"取消",@"退出"] andBlocks:@[block1,block2]];

}
//-(void)actionWithButtonIndex:(NSInteger)buIndex{
//    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
//
//    switch (self.sym) {
//        case 20:
//            [userDefault setObject:@"" forKey:PASSWORD];
//            [userDefault setObject:@"" forKey:USER_ID];
//            [SLAlertView showAlertWithStatusString:@"back"];
//            //[MBProgressHUD showError:@"back"];
//            [self presentViewController:[LogInViewController new] animated:YES completion:nil];
//            break;
//            case 7:
//            [self.prompt showPromptWithTitle:nil message:@"当前已是最新版本" buttonleft:nil buttonright:nil];
//            break;
//        default:
//            break;
//    }
//    
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
