//
//  ForgetPayKeyVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/16.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ForgetPayKeyVC.h"
#import "ReplaceFIrstVC.h"
#import "SLAlertView.h"
@interface ForgetPayKeyVC ()
@property(nonatomic,strong)UITextField *testField;//验证码
@property(nonatomic,assign)int timer;//倒计时
@end

@implementation ForgetPayKeyVC

-(UITextField *)testField{

    if (!_testField) {
        _testField = [[UITextField alloc]init];
        _testField.layer.borderColor = YRedColor.CGColor;
        _testField.layer.borderWidth = 1.0f;
        _testField.textColor = YBlackColor;
        _testField.font = YFont(WINSIZEWIDTH/22);
    }
    return _testField;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.timer = 60;
    // Do any additional setup after loading the view.
    self.title = @"重置支付密码";
    self.view.backgroundColor = YBackGrayColor;
    [self createUI];
}
-(void)createUI{

    UILabel *hoderLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/8)];
    hoderLa.textColor = YGrayColor;
    hoderLa.font = YFont(WINSIZEWIDTH/22);
    hoderLa.text = @"输入验证码,完成身份认证";
    
    UIView *testView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(hoderLa.frame), WINSIZEWIDTH, WINSIZEWIDTH/7)];
    testView.backgroundColor = [UIColor whiteColor];
    self.testField.frame = CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/50, WINSIZEWIDTH/3, testView.height - WINSIZEWIDTH/25);
    UIButton *getNum = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.testField.frame)+WINSIZEWIDTH/5, WINSIZEWIDTH/50, WINSIZEWIDTH/4+WINSIZEWIDTH/20, testView.height-WINSIZEWIDTH/25)];
    getNum.tag = 1000;
    getNum.backgroundColor = YRedColor;
    [getNum setTitle:@"获取验证码" forState:(UIControlStateNormal)];
    [getNum setTitle:@"验证码已发送..." forState:(UIControlStateSelected)];
    getNum.titleLabel.font = YBFont(WINSIZEWIDTH/22);
    [getNum setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [getNum setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    getNum.layer.cornerRadius = WINSIZEWIDTH/100;
    [getNum addTarget:self action:@selector(getNum:) forControlEvents:(UIControlEventTouchUpInside)];
    getNum.tag = 1000;
    [testView addSubview:self.testField];
    [testView addSubview:getNum];
    //下一步
    UIButton *backCount = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, CGRectGetMaxY(testView.frame)+WINSIZEWIDTH/8, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    backCount.backgroundColor = YRedColor;
    [backCount setTitle:@"下一步" forState:(UIControlStateNormal)];
    [backCount setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [backCount setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    backCount.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [backCount addTarget:self action:@selector(next:) forControlEvents:(UIControlEventTouchUpInside)];
    backCount.layer.cornerRadius = WINSIZEWIDTH/100;

    [self.view addSubview:hoderLa];
    [self.view addSubview:testView];
    [self.view addSubview:backCount];
    
}
#pragma mark -- target
-(void)getNum:(UIButton *)sender{
    [SLAlertView showAlertWithStatusString:@"验证码已发送..."];
//    [MBProgressHUD showSuccess:@"验证码已发送。。。"];
    NSTimer *timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(change:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
}
-(void)change:(NSTimer *)timer{
    
    UIButton *button = [self.view viewWithTag:1000];
    NSString *btnTit = [NSString stringWithFormat:@"已发送..%d",--self.timer];
    [button setTitle:btnTit forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    button.enabled = NO;
    if (self.timer==1) {
        [button setTitle:@"获取验证码" forState:(UIControlStateNormal)];
        button.enabled = YES;
        [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [timer invalidate];
    }

}
//下一步
-(void)next:(UIButton *)sender{

    [self.navigationController pushViewController:[ReplaceFIrstVC new] animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
