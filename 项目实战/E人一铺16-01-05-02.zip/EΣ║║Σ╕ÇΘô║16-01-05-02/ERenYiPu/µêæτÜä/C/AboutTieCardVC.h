//
//  AboutTieCardVC.h
//  ERenYiPu
//
//  Created by babbage on 15/11/14.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutTieCardVC : UIViewController
@property (nonatomic,strong) NSMutableArray *cardData;//银行卡信息

@end
