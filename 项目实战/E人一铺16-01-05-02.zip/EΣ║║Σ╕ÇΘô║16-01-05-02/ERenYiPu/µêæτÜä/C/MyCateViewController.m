//
//  MyCateViewController.m
//  MyCateViewController
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "MyCateViewController.h"
#import "MyCateCell.h"

@interface MyCateViewController () <UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) NSMutableArray *models;

@end

@implementation MyCateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _models = [NSMutableArray array];
    //_models = self.cardListArr;
    [self.view addSubview:self.tableView];
    self.tableView.rowHeight = 80;
    self.navigationItem.title = @"我的卡券";
    
    [self getData];
}

#pragma mark - 代理方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.models.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    MyCateCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cateCell"];
    if (cell == nil) {
        cell = [[NSBundle mainBundle] loadNibNamed:@"MyCateCell" owner:nil options:nil].lastObject;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSDictionary *dict = self.models[indexPath.section];
//    cell.itemLabel.text = dict[@"name"];
//    cell.awardLabel.text = [NSString stringWithFormat:@"+%@",dict[@"rate"]];
//    cell.dateLabel.text = dict[@"end_time"];
    
//    [cell.immdicatyUseButton addTarget:self action:@selector(useCardClick:) forControlEvents:UIControlEventTouchUpInside];
    
    if ([[dict valueForKey:@"is_effective"] isEqualToString:@"0"]) {
        cell.maskView.hidden = NO;
    }
    
    cell.dic = dict;
    
    return cell;
}

//- (void)useCardClick:(UIButton *)bt
//{
//    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
//    NSString *token = [userdefault objectForKey:TOKEN];
//    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
//    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
//    [IKHttpTool postWithURL:@"useIcards" params:@{@"json":param} success:^(id json) {
//        
//    } failure:^(NSError *error) {
//        
//    }];
//}


//- (NSArray *)models {
//    if (_models == nil) {
//        _models = @[
//                    @{
//                        @"item" : @"幸运卡",
//                        @"award" : @"0.1%",
//                        @"date" : @"2015-10-11"
//                        },
//                    @{
//                        @"item" : @"幸运卡",
//                        @"award" : @"0.1%",
//                        @"date" : @"2015-10-11"
//                        },
//                    @{
//                        @"item" : @"幸运卡",
//                        @"award" : @"0.1%",
//                        @"date" : @"2015-10-11"
//                        },
//                    @{
//                        @"item" : @"幸运卡",
//                        @"award" : @"0.1%",
//                        @"date" : @"2015-10-11"
//                        },
//                    @{
//                        @"item" : @"幸运卡",
//                        @"award" : @"0.1%",
//                        @"date" : @"2015-10-11"
//                        },
//                    ];
//    }
//    return _models;
//}

- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
        _tableView.frame = CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT - 64);
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        _tableView.tableFooterView = [[UIView alloc]init];
    }
    return _tableView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 5;
}

/*
 "id":"6", "meter":"1", "rate":"7.6", "level":"1",
 * "end_time":"2015-12-04", "user_phone":"18811426232", "name":"幸运卡",
 * "is_effective":"1", "is_use":"1"
*/
//获取卡券列表
- (void)getData
{
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
    [IKHttpTool postWithURL:@"fetecIcardsList" params:@{@"json":param} success:^(id json) {
        
        NSArray *arr = json[@"data"];
        //_models = arr;
        
        //已过期的
        NSMutableArray *cardArr = [NSMutableArray array];
        //未使用的
        NSMutableArray *noUserArr = [NSMutableArray array];
        //获取系统当前日期
        NSString *currentDay = [self getCurrentDate];
        for (NSDictionary *dic in arr) {
            //获取卡券到期时间
            NSString *effectiveDay = [dic[@"end_time"] stringByReplacingOccurrencesOfString:@"-" withString:@""];
            //使用中
            if ([dic[@"is_use"] intValue] == 1 && [dic[@"is_effective" ]intValue] == 1 && [currentDay intValue] <= [effectiveDay intValue]) {
                [_models addObject:dic];
            }
            //点击使用
            else if([dic[@"is_effective" ]intValue] == 1 && [dic[@"is_use" ]intValue] == 0 && [currentDay intValue] <= [effectiveDay intValue]){
                [noUserArr addObject:dic];
            }
            //已过期
            else{
                [cardArr addObject:dic];
            }
        }
        [_models addObjectsFromArray:noUserArr];
        [_models addObjectsFromArray:cardArr];
        

        
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

//获取系统当前日期
- (NSString *)getCurrentDate
{
    NSString *currentDate;
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyyMMdd"];
    currentDate = [formatter stringFromDate:[NSDate date]];
    //NSLog(@"%@",currentDate);
    return currentDate;
}

////获取卡券列表
//- (void)getData
//{
//    [self.cardListArr removeAllObjects];
//    NSString *userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
//    
//    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
//    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
//    [IKHttpTool postWithURL:@"fetecIcardsList" params:@{@"json":param} success:^(id json) {
//        
//        NSArray *arr = json[@"data"];
//        
//        //self.cardListArr = (NSMutableArray *)arr;
//        //已过期的
//        NSMutableArray *cardArr = [NSMutableArray array];
//        //未使用的
//        NSMutableArray *noUserArr = [NSMutableArray array];
//        addRateCard = 0.0;
//        for (NSDictionary *dic in arr) {
//            if ([dic[@"is_effective" ]intValue] == 1 && [dic[@"is_use" ]intValue] == 1) {
//                addRateCard += [dic [@"rate"]floatValue];
//            }
//            if ([dic[@"is_use"] intValue] == 1 && [dic[@"is_effective" ]intValue] == 1) {
//                [self.cardListArr addObject:dic];
//            }
//            else if([dic[@"is_effective" ]intValue] == 1 && [dic[@"is_use" ]intValue] == 0){
//                [noUserArr addObject:dic];
//            }
//            else{
//                [cardArr addObject:dic];
//            }
//        }
//        [self.cardListArr addObjectsFromArray:noUserArr];
//        [self.cardListArr addObjectsFromArray:cardArr];
//        //        currentPri.text = [ShareViewController sharedViewController].rateStr;
//        //        NSLog(@"%@",[ShareViewController sharedViewController].rateStr);
//        reward.text = [NSString stringWithFormat:@"+%0.2f%%",addRateCard];
//    } failure:^(NSError *error) {
//        
//    }];
//}

@end
