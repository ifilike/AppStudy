//
//  RedeemContrller.h
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RedeemContrller : UIViewController
@property(nonatomic,strong)NSString *base_invest;//用户本金
@property(nonatomic,strong)NSString *leiJiShouYi;//累积收益
@end
