//
//  TradeNotesViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "TradeNotesViewController.h"
#import "TradeNotesCell.h"
#import "SLAlertView.h"
@interface TradeNotesViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,assign)int page;
@property(nonatomic,strong)NSMutableArray *alldataArr;//未过滤的
@end

@implementation TradeNotesViewController
-(NSMutableArray *)dataArr{

    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}
-(NSMutableArray *)alldataArr{

    if (!_alldataArr) {
        _alldataArr = [NSMutableArray array];
    }
    return _alldataArr;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"交易记录";
    self.page = 1;
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    [self createUI];
    //获取数据
    [self getData];
    self.dataArr = [NSMutableArray array];
    // Do any additional setup after loading the view.
}
-(void)createUI{

    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/50, WINSIZEWIDTH, WINSIZEHEIGHT-CGRectGetMaxY(self.navigationController.navigationBar.frame)-WINSIZEWIDTH/30)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView addFooterWithTarget:self action:@selector(headerRefreshing)];
    
    self.tableView.footerPullToRefreshText = @"上拉可以刷新数据!";
    self.tableView.footerRefreshingText = @"数据正在加载请稍后...";
    self.tableView.footerReleaseToRefreshText = @"松开马上加载!";
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return self.dataArr.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/2.5;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dic = self.dataArr[indexPath.section];
    
    TradeNotesCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[TradeNotesCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
    }
    cell.firstImage.hidden = YES;
    if (indexPath.section==0) {
        cell.firstImage.hidden = NO;
    }
    NSString *imageStr =[NSString stringWithFormat:@"jiaoyi%ld",indexPath.section%3+1];
    cell.tradeImage.image = [UIImage imageNamed:imageStr];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    //cell.forwde.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    [cell setdata:dic];
    return cell;
}
#pragma mark -- 获取交易记录数据
-(void)headerRefreshing{

    NSLog(@"++++%ld",self.dataArr.count);
    

    if (self.alldataArr.count%20==0&&self.alldataArr.count>0) {
        self.page++;
    }else{
        self.tableView.footerPullToRefreshText = @"数据已加载完毕!";
        self.tableView.footerRefreshingText = @"数据已加载完毕!";
        
        [self.tableView footerEndRefreshing];
       return;
        //[SLAlertView showAlertWithStatusString:@"数据已加载完毕"];
    }
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *pamra = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\",\"page\":\"%d\"}",token,user_phone,self.page];
    [IKHttpTool postWithURL:@"queryHistoryTradOrder" params:@{@"json":pamra} success:^(id json) {
        //        NSString *str = [NSString stringWithFormat:@"%@",json[@"data"][@"detail_list"]];
        //        self.dataArr = [[str componentsSeparatedByString:@"|"]mutableCopy];
        //        if (self.dataArr.count<1) {
        //            [self.dataArr addObject:str];
        //        }
        //        if (str.length>10) {
        //            [self.tableView reloadData];
        //        }else{
        //            NSLog(@"------str:%@",str);
        //        }
        NSArray *datarr = [NSArray array];
        datarr = json[@"data"];
       // self.dataArr = [NSMutableArray array];
        for (NSDictionary *dic in datarr) {
            [self.alldataArr addObject:dic];
            if ([dic[@"status"] isEqualToString:@"RUNNING"]) {
                continue;
            }else if([dic[@"outer_trade_type"] intValue]>4){
                
                continue;
            }
            [self.dataArr addObject:dic];
            
        }
        NSLog(@"-data%ld++%ld",self.dataArr.count,self.alldataArr.count);
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableView footerEndRefreshing ];

    });

}
-(void)getData{
    [SLAlertView showAlertWithMessageString:@"页面加载中..."];
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *pamra = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\",\"page\":\"%d\"}",token,user_phone,self.page];
    [IKHttpTool postWithURL:@"queryHistoryTradOrder" params:@{@"json":pamra} success:^(id json) {
//        NSString *str = [NSString stringWithFormat:@"%@",json[@"data"][@"detail_list"]];
//        self.dataArr = [[str componentsSeparatedByString:@"|"]mutableCopy];
//        if (self.dataArr.count<1) {
//            [self.dataArr addObject:str];
//        }
//        if (str.length>10) {
//            [self.tableView reloadData];
//        }else{
//            NSLog(@"------str:%@",str);
//        }
        NSArray *datarr = [NSArray array];
        datarr = json[@"data"];
        for (NSDictionary *dic in datarr) {
            [self.alldataArr addObject:dic];

            if ([dic[@"status"] isEqualToString:@"RUNNING"]) {
                continue;
            }else if([dic[@"outer_trade_type"] intValue]>4){
            
                continue;
            }
            [self.dataArr addObject:dic];
        }
        NSLog(@"-data%ld++%ld",self.dataArr.count,self.alldataArr.count);

        [self.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
