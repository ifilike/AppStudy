//
//  MySelfViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MySelfViewController.h"
#import "SettingViewController.h"
#import "AllCountViewController.h"
#import "WritInfoViewController.h"
#import "TradeNotesViewController.h"
#import "TopUpController.h"
#import "RedeemContrller.h"
//#import "AllPrifitVC.h"
#import "ZSYViewController.h"
#import "AboutTieCardVC.h"
#import "MyCateViewController.h"
#import "MyCoinViewController.h"
#import "SignInViewController.h"
#import "CashViewController.h"
#import "SLAlertView.h"
#import "UIImageView+WebCache.h"
#import "ShareViewController.h"
#import "MyIconImageView.h"

@interface MySelfViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    CGFloat addRateCard;
    UILabel *currentPri;
    UILabel *reward;
    UIButton *myCoinBtn;  //我的金币
}
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSString *allcount;//总资产；
@property(nonatomic,strong)NSMutableArray *cardArr;//银行卡信息
@property(nonatomic,assign)BOOL status;//认证状态
@property(nonatomic,strong)NSString *allProft;//总收益
@property(nonatomic,strong)NSString *agoProft;//昨日收益

@property (nonatomic,strong)NSMutableArray *cardListArr;
@property (nonatomic, strong) UIImageView *headIconView;
@property (nonatomic,strong) NSString *avalibleMoney;//可用余额
@property (nonatomic,strong) NSString *capitilMoney;//投资本金
@property (nonatomic,strong) NSString *user_banlance;//用户余额

@end

@implementation MySelfViewController


- (void)setIconImage {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *picString = [userDefaults objectForKey:@"userIconKey"];
    NSString *urlString = [NSString stringWithFormat:@"%@%@",@"http://115.28.143.129/EREP/upload/hends/", picString];
    self.headIconView.image = [UIImage imageNamed:@"touxiang"];
    //[self.headIconView sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:[UIImage imageNamed:@"touxiang"]];
}

-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT - 64) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.bounces = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
       // _tableView.backgroundColor = YRedColor;
    }
    return _tableView;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 7;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{

    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/30)];
    view.alpha = 0;
    return view;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    switch (indexPath.section) {
        case 0:
            return WINSIZEWIDTH/2+WINSIZEWIDTH/9;
            break;
        case 1:
            return WINSIZEWIDTH/4+WINSIZEWIDTH/80;
            break;
        case 2:
            return WINSIZEWIDTH/7;
            break;
        case 3:
            return WINSIZEWIDTH/7;
            break;
        case 4:
            return WINSIZEWIDTH/7;
            break;
        case 5:
            return WINSIZEWIDTH/7;
            break;
        case 6:
            return WINSIZEWIDTH/7;
            break;
        default:
            break;
    }
    return 0;
}



- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section==6) {
        return 0;
    }
    return WINSIZEWIDTH/30;
}

//-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//
//    if (section==6) {
//        return 0;
//    }
//    return WINSIZEWIDTH/30;
//    
//}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
      UITableViewCell  *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:nil];
    
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    
    if(indexPath.section==0){
        //头像
        UIImageView *headView = [[MyIconImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2-WINSIZEWIDTH/13, WINSIZEWIDTH/15, WINSIZEWIDTH/6.5, WINSIZEWIDTH/6.5)];
        headView.layer.cornerRadius = headView.height/2;
        headView.layer.masksToBounds = YES;
        headView.image = [UIImage imageNamed:@"touxiang"];
        headView.layer.borderColor = [UIColor whiteColor].CGColor;
        headView.layer.borderWidth = 2;
       // self.headIconView = headView;
        headView.tag = 5555;
        UIButton *headBtn = [[UIButton alloc]initWithFrame:CGRectMake(headView.x, headView.y, headView.width, headView.height)];
        [headBtn setBackgroundImage:[UIImage imageNamed:@"chongzhi"] forState:(UIControlStateHighlighted)];
        headBtn.alpha = 0.3;
        headBtn.layer.cornerRadius = headView.height/2;
        [headBtn addTarget:self action:@selector(headBtnSet:) forControlEvents:(UIControlEventTouchUpInside)];
        
                //名字
        UILabel *nameLab = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/3, CGRectGetMaxY(headView.frame)+WINSIZEWIDTH/80, WINSIZEWIDTH/3, WINSIZEWIDTH/20)];
        nameLab.tag = 1000;
        nameLab.text = [NSString stringWithFormat:@"%@",[userdefault objectForKey:@"user_name"]];
        nameLab.textAlignment = NSTextAlignmentCenter;
        nameLab.textColor = YRedColor;
        nameLab.font = YFont(WINSIZEWIDTH/20);
        //昨日收益
        UILabel *prift = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, CGRectGetMaxY(nameLab.frame)+WINSIZEWIDTH/9, WINSIZEWIDTH/3, nameLab.height)];
#warning mark 字体改过，是否还要该
        prift.textColor = [UIColor colorWithHexString:@"ff6054"];
        //prift.textColor = YBlackColor;
        prift.textAlignment = NSTextAlignmentCenter;
        prift.text = @"昨日收益(元)";
        prift.font = YFont(WINSIZEWIDTH/23);
        UILabel *priftLab = [[UILabel alloc]initWithFrame:CGRectMake(prift.x, CGRectGetMaxY(prift.frame)+WINSIZEWIDTH/50, prift.width, prift.height*3)];
        priftLab.text = @"-";
        priftLab.tag = 2222;
        priftLab.textColor = prift.textColor;
        priftLab.font = YFont(WINSIZEWIDTH/11);
        priftLab.textAlignment = NSTextAlignmentCenter;
        //当前活期
        UILabel *current = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-priftLab.width-priftLab.x, prift.y,prift.width , prift.height)];
        current.textAlignment = NSTextAlignmentCenter;
        current.text = @"当前活期收益率";
        current.textColor = priftLab.textColor;
        current.font = prift.font;
        currentPri = [[UILabel alloc]initWithFrame:CGRectMake(current.x - 30, priftLab.y, current.width/1.2, priftLab.height)];
        currentPri.textColor = current.textColor;
        currentPri.font = YFont(WINSIZEWIDTH / 13);
        currentPri.textAlignment = NSTextAlignmentRight;
        currentPri.text = @"-";
        //奖励
        reward = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(currentPri.frame), currentPri.y+currentPri.height/2-WINSIZEWIDTH/40, current.width/2 + 25, currentPri.height/1.8)];
        reward.text = @"+ -%";
        reward.textColor = [UIColor colorWithHexString:@"fcc457"];
        reward.font = YBFont(WINSIZEWIDTH/20);
        UIImageView *rewardView = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(reward.frame)-reward.width/1.5, reward.y-WINSIZEWIDTH/20, reward.width/2, WINSIZEWIDTH/21)];;
        rewardView.image = [UIImage imageNamed:@"jiangli"];
//        //设置
//        UIButton *setBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/6, WINSIZEWIDTH/23, WINSIZEWIDTH/13, WINSIZEWIDTH/13)];
//        [setBtn setImage:[UIImage imageNamed:@"shezhi"] forState:(UIControlStateNormal)];
//        [setBtn addTarget:self action:@selector(setting:) forControlEvents:(UIControlEventTouchUpInside)];
        //签到
        UIButton *signIn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(headView.frame)+WINSIZEWIDTH/30, CGRectGetMaxY(headView.frame)-WINSIZEWIDTH/21, WINSIZEWIDTH/8.5, WINSIZEWIDTH/21)];
        [signIn setTitle:@"签到" forState:(UIControlStateNormal)];
        [signIn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        signIn.layer.cornerRadius = signIn.height/4;
        [signIn setBackgroundColor:[UIColor colorWithHexString:@"fcc457"]];
       // [signIn setTitleColor:[UIColor colorWithHexString:@"fcc457"] forState:(UIControlStateNormal)];
        signIn.titleLabel.font = YBFont(WINSIZEWIDTH/30);
        
        UIButton *signBig = [[UIButton alloc]initWithFrame:CGRectMake(signIn.x-WINSIZEWIDTH/30, signIn.y-WINSIZEWIDTH/30, signIn.width+WINSIZEWIDTH/15, signIn.height+WINSIZEWIDTH/15)];
        [signBig setTitleColor:[UIColor colorWithHexString:@"9fdc92"] forState:(UIControlStateHighlighted)];
        [signBig setTitle:@"签到" forState:(UIControlStateHighlighted)];
        signBig.titleLabel.font = YBFont(WINSIZEWIDTH/30);
       // signBig.backgroundColor = YRedColor;
        [signBig addTarget:self action:@selector(signIn:) forControlEvents:(UIControlEventTouchUpInside)];
        //我的金币卡
        myCoinBtn = [[UIButton alloc]initWithFrame:CGRectMake(nameLab.x, CGRectGetMaxY(nameLab.frame), nameLab.width, nameLab.height)];
        [myCoinBtn setTitleColor:[UIColor colorWithHexString:@"fcc457"] forState:(UIControlStateNormal)];
        [myCoinBtn setTitle:@"我的金币:-个" forState:(UIControlStateNormal)];
        myCoinBtn.titleLabel.font = YBFont(WINSIZEWIDTH/28);
        myCoinBtn.enabled = NO;
        [myCoinBtn addTarget:self action:@selector(myCoin:) forControlEvents:(UIControlEventTouchUpInside)];
#warning - 暂时不跳转
//        [myCoinBtn addTarget:self action:@selector(myCoin:) forControlEvents:(UIControlEventTouchUpInside)];
        UIView *backView = [[UIView alloc]initWithFrame:CGRectMake(0, -64, WINSIZEWIDTH, CGRectGetMaxY(headView.frame)-headView.height/2)];
        backView.backgroundColor = [UIColor colorWithHexString:@"ff6054"];
       // [cell.contentView addSubview:backView];
        [cell.contentView addSubview:myCoinBtn];
        [cell.contentView addSubview:reward];
        [cell.contentView addSubview:signIn];
       // [cell.contentView addSubview:setBtn];
        [cell.contentView addSubview:signBig];
        [cell.contentView addSubview:current];
        [cell.contentView addSubview:currentPri];
        [cell.contentView addSubview:priftLab];
        [cell.contentView addSubview:prift];
        [cell.contentView addSubview:nameLab];
        [cell.contentView addSubview:headView];
        [cell.contentView addSubview:rewardView];
        [cell.contentView addSubview:headBtn];
    }else if(indexPath.section==1){
        UILabel *allCount = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, WINSIZEWIDTH/20, WINSIZEWIDTH-WINSIZEWIDTH/5, WINSIZEWIDTH/16)];
        allCount.font = YFont(WINSIZEWIDTH/20);
        allCount.text = @"账户总资产:-元";
        
        allCount.tag = 1111;
        allCount.textColor = YBlackColor;
       // allCount.textColor = [UIColor colorWithHexString:@"9fdc92"];
        //button
        UIButton *countBtn = [[UIButton alloc]initWithFrame:CGRectMake(allCount.x, allCount.y-WINSIZEWIDTH/40, WINSIZEWIDTH/2, allCount.height+WINSIZEWIDTH/20)];
        [countBtn setBackgroundImage:[UIImage imageNamed:@"tixian"] forState:(UIControlStateHighlighted)];
        [countBtn addTarget:self action:@selector(count:) forControlEvents:(UIControlEventTouchUpInside)];
        countBtn.alpha = 0.2;
        //赎回
        UIButton *cashBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/4, WINSIZEWIDTH/29, WINSIZEWIDTH/6, WINSIZEWIDTH/13)];
        [cashBtn setBackgroundImage:[UIImage imageNamed:@"tixian"] forState:(UIControlStateNormal)];
        [cashBtn setTitle:@"赎回" forState:(UIControlStateNormal)];
        [cashBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        cashBtn.titleLabel.font = YBFont(WINSIZEWIDTH/22);
        [cashBtn addTarget:self action:@selector(cash:) forControlEvents:(UIControlEventTouchUpInside)];
        //充值
        UIButton *topUpBtn = [[UIButton alloc]initWithFrame:CGRectMake(cashBtn.x, CGRectGetMaxY(cashBtn.frame)+cashBtn.y, cashBtn.width, cashBtn.height)];
        topUpBtn.titleLabel.font = cashBtn.titleLabel.font;
        [topUpBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [topUpBtn setBackgroundImage:[UIImage imageNamed:@"chongzhi"] forState:(UIControlStateNormal)];
        [topUpBtn setTitle:@"充值" forState:(UIControlStateNormal)];
        [topUpBtn addTarget:self action:@selector(topUp:) forControlEvents:(UIControlEventTouchUpInside)];
        //提现
#pragma mark -- 提现按钮的背景图片待该
        UIButton *getOutBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/8, CGRectGetMaxY(allCount.frame)+WINSIZEWIDTH/25, topUpBtn.width, topUpBtn.height)];
        [getOutBtn setBackgroundImage:[UIImage imageNamed:@"tb"] forState:(UIControlStateNormal)];
        [getOutBtn setTitle:@"提现" forState:(UIControlStateNormal)];
        [getOutBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        getOutBtn.titleLabel.font = topUpBtn.titleLabel.font;
        [getOutBtn addTarget:self action:@selector(getout:) forControlEvents:(UIControlEventTouchUpInside)];
        [cell.contentView addSubview:cashBtn];
        [cell.contentView addSubview:topUpBtn];
        [cell.contentView addSubview:allCount];
        [cell.contentView addSubview:countBtn];
        [cell.contentView addSubview:getOutBtn];
    }else if(indexPath.section==2){
        //绑定银行卡
//        UILabel *tieCard = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/13, 0, WINSIZEWIDTH/2, cell.height)];
//        //tieCard.textColor = [UIColor colorWithHexString:@"fda090"];
//        
//        tieCard.text = @"绑定银行卡";
//        tieCard.font = YBFont(WINSIZEWIDTH/20);
        cell.textLabel.textColor = YBlackColor;
        cell.textLabel.text = @"绑定银行卡";
        cell.textLabel.font = YFont(WINSIZEWIDTH/20);
        cell.imageView.image = [UIImage imageNamed:@"yinhangka"];
        //[cell.contentView addSubview:tieCard];
    }else if(indexPath.section == 3){
//        UILabel *myCate = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/13, 0, WINSIZEWIDTH/2, cell.height)];
//        myCate.textColor = [UIColor colorWithHexString:@"bdbbec"];
//        myCate.text = @"我的卡券";
//        myCate.font = YBFont(WINSIZEWIDTH/20);
//        [cell.contentView addSubview:myCate];
        cell.textLabel.text = @"我的卡券";
        cell.imageView.image = [UIImage imageNamed:@"kaquan"];
    }
    else if(indexPath.section==4){
//        UILabel *allPrift = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/13, 0, WINSIZEWIDTH/3, cell.height)];
//        allPrift.text = @"总收益";
//        allPrift.textColor = [UIColor colorWithHexString:@"7ed8e7"];
//        allPrift.font = YBFont(WINSIZEWIDTH/20);
//        [cell.contentView addSubview:allPrift];
        cell.textLabel.text = @"总收益";
        cell.imageView.image = [UIImage imageNamed:@"shouyi2"];
    }else if(indexPath.section==5){
//        UILabel *notes = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/13, 0, WINSIZEWIDTH/3, cell.height)];
//        notes.textColor = [UIColor colorWithHexString:@"fcc36e"];
//        notes.font = YBFont(WINSIZEWIDTH/20);
//        notes.text = @"交易记录";
//        [cell.contentView addSubview:notes];
        cell.textLabel.text = @"交易记录";
        cell.imageView.image = [UIImage imageNamed:@"jilu"];
    }else if(indexPath.section == 6){
        cell.textLabel.text = @"设置";
        cell.imageView.image = [UIImage imageNamed:@"setting"];
    }
    if (indexPath.section==0||indexPath.section==1) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    if(indexPath.section==2||indexPath.section==3||indexPath.section==4||indexPath.section==5||indexPath.section==6){
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.textLabel.textColor = YBlackColor;
    cell.textLabel.font = YFont(WINSIZEWIDTH/20);
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    AboutTieCardVC *cardVC = [AboutTieCardVC new];
    void(^block1)() = ^(){};
    void(^block2)() = ^(){
        [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
    };
    ZSYViewController *zsyVC = [[ZSYViewController alloc]init];
    double allpro = yTwoPointDouble(self.allProft);
    zsyVC.allProfit = [NSString stringWithFormat:@"%0.2lf",allpro];
    switch (indexPath.section) {
        case 2:
            //绑定银行卡
            if (self.status) {
                [self.navigationController pushViewController:cardVC animated:YES];
            }else{
                [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
                NSLog(@"是否去认证");
            }
            break;
            case 3:
            //我的卡券
            if (self.status) {
                
                MyCateViewController *myCateVC = [[MyCateViewController alloc]init];
                myCateVC.cardListArr = self.cardListArr;
                NSLog(@"%ld",self.cardListArr.count);
                [self.navigationController pushViewController:myCateVC animated:YES];
            }else{
                [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
            }
            break;
            case 4:
            //总收益
            if (self.status) {
                
                [self.navigationController pushViewController:zsyVC animated:YES];
            }else{
                [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];

                NSLog(@"是否去认证");
            }
            break;
          case 5:
            //交易记录
            if (self.status) {
                [self.navigationController pushViewController:[[TradeNotesViewController alloc]init] animated:YES];
            }else{
                [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];

                NSLog(@"是否去认证");
            }
            break;
            case 6://设置
            [self.navigationController pushViewController:[SettingViewController new] animated:YES];
            break;
        default:
            break;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    [self.view addSubview:self.tableView];
    self.cardListArr = [NSMutableArray array];
    self.cardArr = [NSMutableArray array];
    
    // Do any additional setup after loading the view.
}
-(void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
    
    currentPri.text = [NSString stringWithFormat:@"%.2f%%",[[ShareViewController sharedViewController].rateStr floatValue]];
    NSLog(@"%@",[ShareViewController sharedViewController].rateStr);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(setIconImage) name:@"reloadIcon" object:nil];
    self.status = NO;
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *token = [userdefault objectForKey:TOKEN];
    self.status = ![[userdefault objectForKey:@"user_name"] isEqualToString:@"未认证"];
//    NSData *headData = [userdefault objectForKey:@"user_icon"];
    UIImageView *headImage = (UIImageView *)[self.view viewWithTag:5555];
    headImage.image = [ShareViewController sharedViewController].image;
    //user_phone
    //    public function queryIsSetPayPassword(){
    //        以上 这些接口都是将 "user_id" 换成了 "user_phone"
    if (self.status) {
        UILabel *nameLabel = (UILabel *)[self.view viewWithTag:1000];
        nameLabel.text = [userdefault objectForKey:@"user_name"];
        NSString *param =[NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",token,user_phone];
        [IKHttpTool postWithURL:@"queryIsSetPayPassword" params:@{@"json":param} success:^(id json) {
            [self getdata];//获取我的资金列表
            [self getData];//获取卡券

        } failure:^(NSError *error) {
            
        }];
    }
    
}
//获得我的余额
-(void)getdata{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    
//获取我的资金列表
    NSString *param2 = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param2} success:^(id json) {
        //self.user_banlance = [NSString stringWithFormat:@"%@",json[@"data"][@"user_balance"]];//用户余额
        self.capitilMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"base_investment"]];
        //NSString *user_balance = [NSString stringWithFormat:@"%@",json[@"data"][@"user_balance"]];
        //self.allcount = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_capital"]];
        self.allProft = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_profit"]];//总收益
        self.avalibleMoney = [NSString stringWithFormat:@"%@",json[@"data"][@"sina_balance"]];//可用金额
        self.allcount = [NSString stringWithFormat:@"%f",[self.capitilMoney doubleValue]+[self.avalibleMoney doubleValue]];//总资产
        NSLog(@"%@",self.allcount);
       // NSLog(@"------user_banlace:%@--self.allProfit:%@---sself.allcount:%@",self.capitilMoney,self.avalibleMoney,self.allcount);
        //NSLog(@"---%f---%f--%f",[self.allProft floatValue],[self.capitilMoney floatValue],[self.avalibleMoney floatValue]);
        CGFloat yes_in = yTwoPointDouble(json[@"data"][@"yesterday_in"]);
        self.agoProft = [NSString stringWithFormat:@"%.2lf",yes_in];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            UILabel *label = (UILabel *)[self.view viewWithTag:1111];
            CGFloat zong = yTwoPointDouble(self.allcount);
            NSLog(@"%.2lf",zong);
            label.text = [NSString stringWithFormat:@"账户总资产:%.2lf元",zong];
            
            UILabel *prift = (UILabel *)[self.view viewWithTag:2222];
            prift.text = [NSString stringWithFormat:@"%0.2f",[self.agoProft floatValue]];
           
            
        });
        //设置我的金币数量
        [myCoinBtn setTitle:[NSString stringWithFormat:@"我的金币:%@ 个",json[@"data"][@"golds"]] forState:(UIControlStateNormal)];
        //[self.tableView reloadData];

        } failure:^(NSError *error) {
        
    }];
    //获取投资信息
//    [IKHttpTool postWithURL:@"getInvestInfo" params:@{@"json":param} success:^(id json) {
//        NSMutableArray *msuArr = [NSMutableArray array];
//        NSArray *arr = [NSArray array];
//        arr = json[@"data"];
//        for (NSDictionary *dic in arr) {
//            NSString *profit = [NSString stringWithFormat:@"%@",dic[@"interest"]];
//            [msuArr addObject:profit];
//        }
//        CGFloat profi = 0;
//        for (NSString *str in msuArr) {
//            profi += [str floatValue];
//        }
//        self.agoProft = [NSString stringWithFormat:@"%0.2f",profi];
//       // [self.tableView reloadData];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            UILabel *label = (UILabel *)[self.view viewWithTag:1111];
//            label.text = [NSString stringWithFormat:@"账户总资产：%0.2f元",[self.allcount floatValue]];
//            UILabel *prift = (UILabel *)[self.view viewWithTag:2222];
//            prift.text = [NSString stringWithFormat:@"%0.2f",[self.agoProft floatValue]];
//        });
//       
//    } failure:^(NSError *error) {
//        
//    }];
}
#pragma mark -- Target
//提现
-(void)getout:(UIButton *)sender{

    if(self.status){
        CashViewController *cash = [[CashViewController alloc]init];
        cash.title = @"提现";
        cash.cardData = [NSArray arrayWithArray:self.cardArr];
        cash.count = [NSString stringWithFormat:@"%0.2f",yTwoPointDouble(self.avalibleMoney)];
        [self.navigationController pushViewController:cash animated:YES];
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];

    }
    
}
//我的金币
-(void)myCoin:(UIButton *)sender{

    if (self.status) {
        [self.navigationController pushViewController:[MyCoinViewController new] animated:YES];
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
    }
}
//充值
-(void)topUp:(UIButton *)sender{

    if (self.status) {
        [self.navigationController pushViewController:[[TopUpController alloc]init] animated:YES];
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
    }
}
//赎回
-(void)cash:(UIButton *)sender{

    if (self.status) {
        RedeemContrller *reedVC = [[RedeemContrller alloc]init];
        double capitil = yTwoPointDouble(self.capitilMoney);
        reedVC.base_invest = [NSString stringWithFormat:@"%.2f",capitil];
        double allp = yTwoPointDouble(self.allProft);
        reedVC.leiJiShouYi = [NSString stringWithFormat:@"%.2lf",allp];
        NSLog(@"----------------bse_invest:%@",self.capitilMoney);
        [self.navigationController pushViewController:reedVC animated:YES];
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];

    }
}
//签到
-(void)signIn:(UIButton *)sender{
#warning mark -- 签到待该（目前还有不知名的错误）
    if (self.status) {
        if ([self.allcount floatValue]>=1000) {
            [self.navigationController pushViewController:[SignInViewController new] animated:YES];
        }else{
            void(^block1)() = ^(){};
            void(^block2)() = ^(){
                TopUpController *tupVC = [[TopUpController alloc]init];
                tupVC.title = @"充值";
                [self.navigationController pushViewController:tupVC animated:YES];            };
            [SLAlertView showAlertWithStatusString:@"您的账户余额不足1000，不能签到请及时充值" withButtonTitles:@[@"取消",@"去充值"] andBlocks:@[block1,block2]];
           // [SLAlertView showAlertWithImage:[UIImage imageNamed:@"充值"] withButtonTitles:@[@"取消",@"去充值"] andBlocks:@[block1,block2]];
           // [self.promptView makePromptWithTitle:nil message:@"    您好，您的账余额不足，不能签到，请您充值" buttonleft:@"取消" buttonright:@"马上充值"];
        }
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];

    }
        //[self.navigationController pushViewController:[SignInViewController new] animated:YES];
//    [gressHUD showSuccess:@"表现不错"];
//    NSString *user_phone = [[NSUserDefaults standardUserDefaults] objectForKey:USER_PHONE];
//    NSString *str = [NSString stringWithFormat:@"{\"check_code\":\"%@\",\"user_phone\":\"%@\"}",CHECKCODE,user_phone];
//    [IKHttpTool postWithURL:@"sign" params:@{@"json":str} success:^(id json) {
//        
//        NSLog(@"------str:%@",str);
//    } failure:^(NSError *error) {
//        
//    }];
}
-(void)actionWithButtonIndex:(NSInteger)buIndex{

    NSLog(@"100000---%ld",(long)buIndex);
    TopUpController *tupVC = [[TopUpController alloc]init];
    tupVC.title = @"充值";
    [self.navigationController pushViewController:tupVC animated:YES];
}
-(void)headBtnSet:(UIButton *)sender{
    [self.navigationController pushViewController:[[SettingViewController alloc]init] animated:YES];
}
//设置
-(void)setting:(UIButton *)sender{

    [self.navigationController pushViewController:[[SettingViewController alloc]init] animated:YES];
}
//资产总金额 点击事件
-(void)count:(UIButton *)sender{
    if (self.status) {
        AllCountViewController *allVC = [[AllCountViewController alloc]init];
        double allc = yTwoPointDouble(self.allcount);
        double avalib = yTwoPointDouble(self.avalibleMoney);
        allVC.allCount = [NSString stringWithFormat:@"%0.2f元",allc];
        allVC.allProfit = [NSString stringWithFormat:@"%0.2f元",avalib];
        [self.navigationController pushViewController:allVC animated:YES];
    }else{
        void(^block1)() = ^(){};
        void(^block2)() = ^(){
            [self.navigationController pushViewController:[WritInfoViewController new] animated:YES];
        };
        [SLAlertView showAlertWithStatusString:@"您还没有认证，是否现在去认证" withButtonTitles:@[@"取消",@"去认证"] andBlocks:@[block1,block2]];
    }
}


/*
 "id":"6", "meter":"1", "rate":"7.6", "level":"1",
 * "end_time":"2015-12-04", "user_phone":"18811426232", "name":"幸运卡",
 * "is_effective":"1", "is_use":"1"
 */
//获取卡券列表
- (void)getData
{
    [self.cardListArr removeAllObjects];
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
    [IKHttpTool postWithURL:@"fetecIcardsList" params:@{@"json":param} success:^(id json) {
        
        NSArray *arr = json[@"data"];
        
        //self.cardListArr = (NSMutableArray *)arr;
        //已过期的
        NSMutableArray *cardArr = [NSMutableArray array];
        //未使用的
        NSMutableArray *noUserArr = [NSMutableArray array];
        addRateCard = 0.0;
        
        //获取系统当前日期
        NSString *currentDay = [self getCurrentDate];
        
        for (NSDictionary *dic in arr) {
            //获取卡券到期时间
            NSString *effectiveDay = [dic[@"end_time"] stringByReplacingOccurrencesOfString:@"-" withString:@""];
            //NSLog(@"effectiveDay -------   %@",effectiveDay);
            //使用中
            if ([dic[@"is_effective" ]intValue] == 1 && [dic[@"is_use" ]intValue] == 1 && [currentDay intValue] <= [effectiveDay intValue]) {
                addRateCard += [dic [@"rate"]floatValue];
            }
            if ([dic[@"is_use"] intValue] == 1 && [dic[@"is_effective" ]intValue] == 1 && [currentDay intValue] <= [effectiveDay intValue]) {
                [self.cardListArr addObject:dic];
            }
            //点击使用
            else if([dic[@"is_effective" ]intValue] == 1 && [dic[@"is_use" ]intValue] == 0 && [currentDay intValue] <= [effectiveDay intValue]){
                [noUserArr addObject:dic];
            }
            //已过期
            else{
                [cardArr addObject:dic];
            }
        }
        [self.cardListArr addObjectsFromArray:noUserArr];
        [self.cardListArr addObjectsFromArray:cardArr];
//        currentPri.text = [ShareViewController sharedViewController].rateStr;
//        NSLog(@"%@",[ShareViewController sharedViewController].rateStr);
        if (addRateCard == 0.0) {
            reward.text = [NSString stringWithFormat:@"+ -%%"];
        }else{
            reward.text = [NSString stringWithFormat:@"+%0.2f%%",addRateCard];
        }
        
    } failure:^(NSError *error) {
        
    }];
}

//获取系统当前日期
- (NSString *)getCurrentDate
{
    NSString *currentDate;
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyyMMdd"];
    currentDate = [formatter stringFromDate:[NSDate date]];
    //NSLog(@"%@",currentDate);
    return currentDate;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
