//
//  AllCountViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllCountViewController : UIViewController
@property(nonatomic,strong)NSString *allCount;//总资产
@property(nonatomic,strong)NSString *allProfit;//可用余额
@end
