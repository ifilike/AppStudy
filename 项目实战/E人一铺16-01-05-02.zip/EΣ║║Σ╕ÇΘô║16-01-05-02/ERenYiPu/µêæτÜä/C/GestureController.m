//
//  GestureController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/17.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "GestureController.h"
#import "CLLockVC.h"
#import "LogInViewController.h"
@interface GestureController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,assign)NSUInteger section;
@property(nonatomic,strong)UISwitch *geSwithch;
@end

@implementation GestureController
-(UISwitch *)geSwithch{

    if (!_geSwithch) {
        _geSwithch = [[UISwitch alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/5, WINSIZEWIDTH/50, WINSIZEWIDTH/10, WINSIZEWIDTH/10)];
        _geSwithch.onTintColor = YRedColor;
        _geSwithch.tintColor = [UIColor colorWithHexString:@"bcbcbc"];
        _geSwithch.on = NO;
    }
    return _geSwithch;
}
-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH)];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [[UIView alloc]init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.bounces = NO;
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   self.section = [[[NSUserDefaults standardUserDefaults]objectForKey:HANDSTATUS] integerValue]==1?2:1;
    self.view.backgroundColor = YBackGrayColor;
    self.title = @"手势密码";
    [self.view addSubview:self.tableView];
    self.geSwithch.selected = [[[NSUserDefaults standardUserDefaults]objectForKey:HANDSTATUS] integerValue]==1;
    self.geSwithch.on = self.geSwithch.selected;
    [self.geSwithch addTarget:self action:@selector(switchOn:) forControlEvents:(UIControlEventTouchUpInside)];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewDidAppear:(BOOL)animated{

    [self.tableView reloadData];
}
-(void)switchOn:(UISwitch *)sender{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    sender.selected = !sender.selected;
    if (!sender.selected) {
        self.section = 1;
        [userdefault setObject:@"0" forKey:HANDSTATUS];
        [self.tableView reloadData];
    }else{
        [userdefault setObject:@"1" forKey:HANDSTATUS];
        self.section = 2;
        [self.tableView reloadData];
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    if (section==self.section-1) {
        return 0;
    }
    return WINSIZEWIDTH/30;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return self.section;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:nil];
    if (indexPath.section == 0) {
        cell.textLabel.text = @"开启手势密码";
       
        [cell addSubview:self.geSwithch];
        cell.selectionStyle = UITableViewCellSelectionStyleNone
        ;
    }
    if(indexPath.section == 1){
    
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        NSString *handGesture = [userdefault objectForKey:HAND_PASSWORD];
        if (handGesture.length>4) {
            cell.textLabel.text = @"验证手势密码";
        }else{
            cell.textLabel.text = @"设置手势密码";
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.textLabel.textColor = YGrayColor;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section==1) {
#warning mark -- 此处修改过
            //
            BOOL hasPwd = [CLLockVC hasPwd];
           // hasPwd = NO;
            if(!hasPwd){
                [CLLockVC showSettingLockVCInVC:self successBlock:^(CLLockVC *lockVC, NSString *pwd) {
                    NSLog(@"密码设置成功");
                    [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:HANDSTATUS];
                    [lockVC dismiss:0.5f];
                }];
            }else{//验证手势密码
                [CLLockVC showVerifyLockVCInVC:self forgetPwdBlock:^{
                    
                   // [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];
                } successBlock:^(CLLockVC *lockVC, NSString *pwd) {
                    NSLog(@"密码正确-----");
                    [lockVC dismiss:1.0f];
                }];
            }
        }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
