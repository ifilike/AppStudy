//
//  RememberPayKeyVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/16.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "RememberPayKeyVC.h"
#import "ReplaceFIrstVC.h"
#import "SLAlertView.h"

@interface RememberPayKeyVC ()<UITextFieldDelegate>

@end

@implementation RememberPayKeyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = YBackGrayColor;
    self.title = @"重置支付密码";
    [self createUI];
}
-(void)createUI{

    UILabel *hoderLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/8)];
    hoderLa.textColor = YGrayColor;
    hoderLa.font = YFont(WINSIZEWIDTH/22);
    hoderLa.text = @"输入支付密码,完成身份认证";
    
    UIView *payView = [[UIView alloc]initWithFrame:CGRectMake(hoderLa.x, CGRectGetMaxY(hoderLa.frame), WINSIZEWIDTH-hoderLa.x*2, WINSIZEWIDTH/9)];
    payView.backgroundColor = [UIColor whiteColor];
    payView.layer.cornerRadius = WINSIZEWIDTH/80;
    payView.layer.borderColor = [UIColor colorWithHexString:@"bcbcbc"].CGColor;
    payView.layer.borderWidth = 1.0f;
    payView.layer.masksToBounds = YES;
    for (int i = 0; i<6; i++) {
        UITextField *payTextField = [[UITextField alloc]initWithFrame:CGRectMake(payView.width/6*i, 0, payView.width/6, payView.height)];
        payTextField.tag = 1000+i;
        payTextField.font = YFont(WINSIZEWIDTH/20);
        payTextField.textAlignment = NSTextAlignmentCenter;
        payTextField.secureTextEntry = YES;
        payTextField.delegate = self;
        UIView *verView = [[UIView alloc]initWithFrame:CGRectMake(payView.width/6*(i+1), 0, 1, payView.height)];
        verView.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
      
        [payView addSubview:payTextField];
        if (i!=5) {
            [payView addSubview:verView];
        }
    }
    //下一步
    UIButton *backCount = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, CGRectGetMaxY(payView.frame)+WINSIZEWIDTH/8, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    backCount.backgroundColor = YRedColor;
    [backCount setTitle:@"下一步" forState:(UIControlStateNormal)];
    [backCount setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [backCount setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    backCount.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [backCount addTarget:self action:@selector(next:) forControlEvents:(UIControlEventTouchUpInside)];
    backCount.layer.cornerRadius = WINSIZEWIDTH/100;
    
    [self.view addSubview:backCount];
    [self.view addSubview:hoderLa];
    [self.view addSubview:payView];
    
}
//textFieldelegate
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    if ([string isEqualToString:@"\n"])  //按会车可以改变
    {
        return YES;
    }
    if (textField.text.length>0) {
        textField.text = [textField.text substringToIndex:0];
        return YES;
    }
    return YES;
}
//下一步
-(void)next:(UIButton *)sender{

    
    NSString *str = [NSString new];
    for (int i = 0; i<6; i++) {
        UITextField *field = (UITextField *)[self.view viewWithTag:1000+i];
        str = [str stringByAppendingString:field.text];
    }
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *payPassWord = [userdefault objectForKey:PAYPASSWORD];
    if ([payPassWord isEqualToString:str]) {
        [self.view endEditing:YES];
        [self.navigationController pushViewController:[ReplaceFIrstVC new] animated:YES];
    }else{
        [SLAlertView showAlertWithStatusString:@"密码错误,请重新输入"];
//        [MBProgressHUD showError:@"密码错误,请重新输入"];
    }
    NSLog(@"-----str:%@",str);
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
