//
//  ZSYViewController.m
//  ZSY
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "ZSYViewController.h"
#import "ZSYTableHeaderView.h"
#import "ZSYHeaderView.h"
#import "TouZhiHuoDongCell.h"
#import "QianDaoCell.h"
#import "EarningsModel.h"
#import "QDSYModel.h"
#import "SLAlertView.h"
#import "UserData.h"

@interface ZSYViewController () <UITableViewDataSource, UITableViewDelegate>
{
    NSString *userPhone;
}
@property (strong, nonatomic) UITableView * tableView;
@property (strong, nonatomic) NSMutableArray *models;

@property (strong, nonatomic) ZSYHeaderView *mainHeaderView;
@property (strong, nonatomic) ZSYTableHeaderView *tableHeaderView1;
@property (strong, nonatomic) ZSYTableHeaderView *tableHeaderView2;
@property (strong, nonatomic) ZSYTableHeaderView *tableHeaderView3;


@end

@implementation ZSYViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@", self.allProfit);
    //用户手机号
    userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    self.navigationItem.title = @"总收益";
    [self.view addSubview:self.tableView];
}

- (NSMutableArray *)models {
    if (_models == nil) {
        _models = [NSMutableArray arrayWithArray:@[
                                                   @"",
                                                   @[],
                                                   @[],
                                                   @[],
                                                   ]];
    }
    return _models;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self getTouZiShouYi];
    [self getQDShouYi];
    [self getHDShouYi];
}

- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStyleGrouped];
        _tableView.frame = CGRectMake(self.view.bounds.origin.x, self.view.bounds.origin.y, self.view.bounds.size.width, self.view.bounds.size.height - 20);
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _tableView;
}

#pragma mark - 代理方法

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    } else if ([self tableHeaderViewWithSection:section].detailButton.selected) {
        return [self.models[section] count];
    }
    return 0;
}

static NSString *const identifier1 = @"TouZhiHuoDong";
static NSString *const identifier2= @"QianDao";

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 1 ) {
        TouZhiHuoDongCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier1];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"TouZhiHuoDongCell" owner:nil options:nil] lastObject];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }

        cell.dateLabel.text = [self.models[indexPath.section][indexPath.row][@"profit_time"] substringWithRange:NSMakeRange(0, 10)];
        cell.itemLabel.text = self.models[indexPath.section][indexPath.row][@"product_name"];
        double money = yTwoPointDouble(self.models[indexPath.section][indexPath.row][@"profit_money"]);
        cell.moneyLabel.text = [NSString stringWithFormat:@"%.2f",money];
        return cell;
    } else if (indexPath.section == 2) {
        QianDaoCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier2];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"QianDaoCell" owner:nil options:nil] lastObject];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }

        cell.dateLabel.text = [self.models[indexPath.section][indexPath.row][@"time"] substringWithRange:NSMakeRange(0, 10)];
//        cell.moneyLabel.text = [NSString stringWithFormat:@"%.2f",[self.models[indexPath.section][indexPath.row][@"in_profit"] floatValue]];
        double money = yTwoPointDouble(self.models[indexPath.section][indexPath.row][@"in_profit"]);
        cell.moneyLabel.text = [NSString stringWithFormat:@"%.2f",money];
        return cell;
    }else if(indexPath.section == 3){
        TouZhiHuoDongCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier1];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"TouZhiHuoDongCell" owner:nil options:nil] lastObject];
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        
        cell.dateLabel.text = [self.models[indexPath.section][indexPath.row][@"time"] substringWithRange:NSMakeRange(0, 10)];
        cell.itemLabel.text = self.models[indexPath.section][indexPath.row][@"active_name"];
//        cell.moneyLabel.text = [NSString stringWithFormat:@"%.2f",[self.models[indexPath.section][indexPath.row][@"in_profit"] floatValue]];
        double money = yTwoPointDouble(self.models[indexPath.section][indexPath.row][@"in_profit"]);
        cell.moneyLabel.text = [NSString stringWithFormat:@"%.2f",money];
        return cell;
    }
    return nil;
}

#pragma mark - 其他方法

- (ZSYHeaderView *)mainHeaderView {
    if (_mainHeaderView == nil) {
        _mainHeaderView = [[[NSBundle mainBundle] loadNibNamed:@"ZSYHeaderView" owner:nil options:nil] lastObject];
    }
    return _mainHeaderView;
}

- (ZSYTableHeaderView *)tableHeaderView1 {
    if (_tableHeaderView1 == nil) {
        _tableHeaderView1 = [[[NSBundle mainBundle] loadNibNamed:@"ZSYTableHeaderView" owner:nil options:nil] lastObject];
    }
    return _tableHeaderView1;
}

- (ZSYTableHeaderView *)tableHeaderView2 {
    if (_tableHeaderView2 == nil) {
        _tableHeaderView2 = [[[NSBundle mainBundle] loadNibNamed:@"ZSYTableHeaderView" owner:nil options:nil] lastObject];
    }
    return _tableHeaderView2;
}

- (ZSYTableHeaderView *)tableHeaderView3 {
    if (_tableHeaderView3 == nil) {
        _tableHeaderView3 = [[[NSBundle mainBundle] loadNibNamed:@"ZSYTableHeaderView" owner:nil options:nil] lastObject];
    }
    return _tableHeaderView3;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        ZSYHeaderView *mainHeaderView = self.mainHeaderView;
        mainHeaderView.moneyLabel.text = [NSString stringWithFormat:@"%@",self.allProfit];
        return (UIView *)mainHeaderView;
    } else {
        NSArray *array = @[@"",
                           @"累计投资收益",
                           @"累计签到收益",
                           @"累计活动收益"
                           ];
        ZSYTableHeaderView *tableHeaderView = [self tableHeaderViewWithSection:section];
        tableHeaderView.sectionLabel.text = array[section];
        tableHeaderView.detailButton.tag = section + 7777;
        return (UIView *)tableHeaderView;
    }
}

- (ZSYTableHeaderView *)tableHeaderViewWithSection:(NSInteger)section {
    return [self performSelector:NSSelectorFromString([NSString stringWithFormat:@"tableHeaderView%li", section])];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    if (indexPath.section == 2) {
        return 100;
    }
    return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return section ? 60 : 160;
}

#pragma mark - 数据请求
//投资收益
- (void)getTouZiShouYi
{
    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"investProfitDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天

    NSLog(@"11id:%@", [userDefaults objectForKey:USER_ID]);
    NSLog(@"22id:%@", [userDefaults objectForKey:@"old_userID"]);
    
    if ([dateString isEqualToString:nowDataString] && [[userDefaults objectForKey:USER_ID] isEqualToString:[userDefaults objectForKey:@"old_userID"]]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].investProfit) {
            NSArray *arr = [UserData sharedUserData].investProfit;
            if (arr != nil) {
                self.models[1] = arr;
            }
            NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:1];
            [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        }
        return;
    } else {
        NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
        [IKHttpTool postWithURL:@"requestAcitveInvest" params:@{@"json":param} success:^(id json) {
            NSLog(@"一日加载investProfitDateString");
            NSString *dateStr = [fmt stringFromDate:date];
            [userDefaults setObject:dateStr forKey:@"investProfitDateString"];
            [userDefaults setObject:[userDefaults objectForKey:USER_ID] forKey:@"old_userID"];
        
            NSArray *arr = json[@"data"];
            [UserData sharedUserData].investProfit = arr;
            if (arr != nil) {
                self.models[1] = arr;
            }
            NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:1];
            [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        } failure:^(NSError *error) {
        }];
    }
}

//签到收益
- (void)getQDShouYi
{
    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"markProfitsDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天
    if ([dateString isEqualToString:nowDataString] && [[userDefaults objectForKey:USER_ID] isEqualToString:[userDefaults objectForKey:@"old_userID"]]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].markProfit) {
            NSArray *arr = [UserData sharedUserData].markProfit;
            if (arr != nil) {
                self.models[2] = arr;
            }
            NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:2];
            [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    } else {
        NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
        [IKHttpTool postWithURL:@"requestAcitveSign" params:@{@"json":param} success:^(id json) {
            NSLog(@"一日加载markProfitsDateString");
            NSString *dateStr = [fmt stringFromDate:date];
            [userDefaults setObject:dateStr forKey:@"markProfitsDateString"];
            [userDefaults setObject:[userDefaults objectForKey:USER_ID] forKey:@"old_userID"];

            NSArray *arr = json[@"data"];
            [UserData sharedUserData].markProfit = arr;
            if (arr != nil) {
                self.models[2] = arr;
            }
            NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:2];
            [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        } failure:^(NSError *error) {
            
        }];
    }
}

//活动收益
- (void)getHDShouYi
{
    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"activeProfitsDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天
    if ([dateString isEqualToString:nowDataString] && [[userDefaults objectForKey:USER_ID] isEqualToString:[userDefaults objectForKey:@"old_userID"]]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].activeProfit) {
            NSArray *arr = [UserData sharedUserData].activeProfit;
            if (arr != nil) {
                self.models[3] = arr;
            }
            NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:3];
            [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    } else {
        NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
        [IKHttpTool postWithURL:@"requestAcitveProfit" params:@{@"json":param} success:^(id json) {
            NSLog(@"++++++++++++json%@",json);
            NSLog(@"一日加载activeProfitsDateString");
            NSString *dateStr = [fmt stringFromDate:date];
            [userDefaults setObject:dateStr forKey:@"activeProfitsDateString"];
            [userDefaults setObject:[userDefaults objectForKey:USER_ID] forKey:@"old_userID"];

            NSArray *arr = json[@"data"];
            [UserData sharedUserData].activeProfit = arr;
            if (arr != nil) {
                self.models[3] = arr;
            }
            NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:3];
            [_tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
        } failure:^(NSError *error) {
        }];
    }
}

#pragma mark 控制section Header 的位置

//- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
//    if (self.tableHeaderView3.frame.origin.y + self.tableHeaderView3.bounds.size.height > ) {
//        <#statements#>
//    }
//    
//}
//
//- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
//    
//}

//
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
//    CGFloat sectionHeaderHeight = 40;
//    if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
//        scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
//    } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
//        scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
//    }
//}


@end
