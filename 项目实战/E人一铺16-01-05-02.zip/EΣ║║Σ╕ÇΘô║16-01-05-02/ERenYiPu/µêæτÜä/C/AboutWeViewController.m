//
//  AboutWeViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/25.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AboutWeViewController.h"

@interface AboutWeViewController ()

@end

@implementation AboutWeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"关于我们";
    self.view.backgroundColor = [UIColor whiteColor];
    [self createUI];
    // Do any additional setup after loading the view from its nib.
}
-(void)createUI{

    UIImageView *logoView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2 - WINSIZEWIDTH/8.8, WINSIZEWIDTH/6, WINSIZEWIDTH/4.4, WINSIZEWIDTH/4.4)];
    logoView.image = [UIImage imageNamed:@"E人一铺"];
    
    UILabel *logoName = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(logoView.frame)+WINSIZEWIDTH/50, WINSIZEWIDTH, WINSIZEWIDTH/10)];
    logoName.text = @"E人一铺";
    logoName.textColor = YRedColor;
    logoName.font = YFont(WINSIZEWIDTH/11);
    logoName.textAlignment = NSTextAlignmentCenter;
    
    UILabel *contentLab = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, CGRectGetMaxY(logoName.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/7.5, WINSIZEWIDTH/3)];
    contentLab.text = @"       E人一铺是上海奕铢互联网金融服务有限公司推出的P2P理财APP。E人一铺的运营理念就是理财人可以拥有自己的铺子。让你圆梦做房东、坐等收益。";
    contentLab.numberOfLines = 0;
    contentLab.font = YFont(WINSIZEWIDTH/22);
    contentLab.textColor = YGrayColor;
    NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc]initWithString:contentLab.text];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
    [style setLineSpacing:5];
    CGFloat textwidth = contentLab.width;
    NSInteger length = textwidth;
    if (attribute.length < textwidth) {
        length = attribute.length;
    }
    [attribute addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, length)];
    contentLab.attributedText = attribute;
    [self.view addSubview:logoView];
    [self.view addSubview:logoName];
    [self.view addSubview:contentLab];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
