//
//  WebViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/25.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "WebViewController.h"
#import "SLAlertView.h"
#import "MySelfViewController.h"
#import "ETabBarViewController.h"
#import "ShareViewController.h"
#import "InvestViewController.h"
#import "SignInViewController.h"
@interface WebViewController ()<UIWebViewDelegate>

@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [SLAlertView hide];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"完成" style:(UIBarButtonItemStyleDone) target:self action:@selector(maskOver:)];
    UIWebView *webview = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, self.view.height)];
    webview.delegate = self;
    [SLAlertView showAlertWithStatusString:@"页面加载缓慢，请稍候..."];
  //  NSTimer *timer = [NSTimer timerWithTimeInterval:5.0 target:self selector:@selector(loadHide:) userInfo:nil repeats:NO];
   // [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
    [self.view addSubview:webview];
        webview.scrollView.bouncesZoom = YES;
    if(self.webStr.length<150){
        
        NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.webStr]];
            [webview loadRequest:request];
    }else{
        NSString *str = [NSString stringWithFormat:@"%@",self.webStr];
        str = [str stringByReplacingOccurrencesOfString:@"\\\"" withString:@"\""];
        NSLog(@"+++++%@",str);
        [webview loadHTMLString:str baseURL:nil];
    }
  //  [webview loadRequest:request];
    //[webview loadHTMLString:self.webStr baseURL:nil];
    
    // Do any additional setup after loading the view.
}
-(void)loadHide:(UIButton *)sender{
    [SLAlertView hide];
//    [MBProgressHUD hideHUD];
}
//跳转界面
-(void)maskOver:(UIBarButtonItem *)sender{
#pragma mark -- 跳转
    
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[InvestViewController class]]) {
            [self.navigationController popToViewController:vc animated:true];
            return;
        }
    }
    
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[SignInViewController class]]) {
            [self.navigationController popToViewController:vc animated:true];
            return;
        }
    }
    
    
    [self.navigationController popToRootViewControllerAnimated:true];
    
}
-(void)webViewDidStartLoad:(UIWebView *)webView{

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
