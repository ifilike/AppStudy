//
//  RedeemContrller.m
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "RedeemContrller.h"
#import "CashViewController.h"
#import "SLAlertView.h"
#import "ShareViewController.h"
#import "YDReemTableViewCell.h"
#import "ShuHuiViewControllerFix.h"

@interface RedeemContrller()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UILabel *prifit;//总投资金额
@property(nonatomic,strong)UILabel *interest;//期待利息
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *dataArr;
@property(nonatomic,strong)NSMutableArray *goodDataArr;
@property(nonatomic,strong)NSString *good_id;
@property(nonatomic,strong)UILabel *invest;//累积收益
@property (nonatomic,strong)UIViewController *vc;
@end
@implementation RedeemContrller

-(void)viewDidLoad{

    [super viewDidLoad];
    [self createUI];
    self.title = @"赎回资金";
    self.view.backgroundColor = YBackGrayColor;
    
//    [self getGoodsData];
    
    self.prifit.text = [NSString stringWithFormat:@"%0.2f",[self.base_invest floatValue]];
}
-(void)createUI{
//第一块内容
    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/3.7)];
    firstView.backgroundColor = [UIColor whiteColor];
    UILabel *allProfit = [[UILabel alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/30, WINSIZEWIDTH/2, WINSIZEWIDTH/12)];
    allProfit.text = @"总投资金额";
    allProfit.textColor = YGrayColor;
    allProfit.font = YFont(WINSIZEWIDTH/18);
    allProfit.textAlignment = NSTextAlignmentCenter;
#warning 钱数
    // 投资金额额度
    self.prifit = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(allProfit.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH/2, WINSIZEWIDTH/15)];
    self.prifit.textAlignment = NSTextAlignmentCenter;
    self.prifit.font = YFont(WINSIZEWIDTH/12);
    
    self.prifit.text = [NSString stringWithFormat:@"%.2f",[self.base_invest floatValue]];
    NSLog(@"---------------%@",self.base_invest);
    self.prifit.textColor = YRedColor;
    
    UILabel *investLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, allProfit.y, WINSIZEWIDTH/2, allProfit.height)];
    investLal.text = @"累积收益";
    investLal.textAlignment = NSTextAlignmentCenter;
    investLal.textColor = allProfit.textColor;
    investLal.font = allProfit.font;
    self.invest = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, self.prifit.y, WINSIZEWIDTH/2, self.prifit.height)];
    self.invest.textColor = self.prifit.textColor;
    self.invest.font = self.prifit.font;
    self.invest.textAlignment = NSTextAlignmentCenter;
    UIButton *reback = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2+WINSIZEWIDTH/8, firstView.height/2-firstView.height/5,WINSIZEWIDTH/4, firstView.height/2.5)];
    reback.layer.cornerRadius = WINSIZEHEIGHT/80;
    [reback setTitle:@"赎 回" forState:UIControlStateNormal];
    reback.titleLabel.font = YBFont(WINSIZEWIDTH/17);
    [reback setBackgroundImage:[UIImage imageNamed:@"tixian"] forState:(UIControlStateNormal)];
    [reback addTarget:self action:@selector(rebackBtnClick:) forControlEvents:(UIControlEventTouchUpInside)];
    [reback setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    UIView *horView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2-1, WINSIZEWIDTH/30, 2, firstView.height-WINSIZEWIDTH/15)];
    horView.backgroundColor = YBackGrayColor;
    
    [firstView addSubview:allProfit];
    [firstView addSubview:self.prifit];
    //[firstView addSubview:reback];
    //[firstView addSubview:self.interest];
    [firstView addSubview:horView];
    [firstView addSubview:investLal];
    [firstView addSubview:self.invest];
    //投资历史
    UILabel *investHis = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame), WINSIZEWIDTH/3, WINSIZEWIDTH/8)];
    investHis.text = @"投资记录";
    investHis.textColor = YGrayColor;
    investHis.font = YFont(WINSIZEWIDTH/20);
    investHis.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:investHis];
 //第二块内容
    UIView *secView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(investHis.frame), WINSIZEWIDTH, WINSIZEWIDTH/6)];
    secView.backgroundColor = [UIColor whiteColor];
    NSArray *array = @[@"产品名称",@"起投时间",@"本息总额",@"利率"];
    for(int i = 0;i<4;i++){
    
        UILabel *nameLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/4*i, 0, WINSIZEWIDTH/4, secView.height)];
        nameLa.textAlignment = NSTextAlignmentCenter;

        nameLa.textColor = YBlackColor;
        nameLa.font = YBFont(WINSIZEWIDTH/22);
        nameLa.text = array[i];
        [secView addSubview:nameLa];
    }
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secView.frame)+WINSIZEWIDTH/100, WINSIZEWIDTH, WINSIZEHEIGHT - CGRectGetMaxY(secView.frame)-64)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [[UIView alloc]init];
    [self.tableView setLayoutMargins:(UIEdgeInsetsZero)];
    [self.tableView setSeparatorInset:(UIEdgeInsetsZero)];
    self.tableView.backgroundColor = [UIColor clearColor];
    UIView *thirdView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, secView.height)];
    thirdView.backgroundColor = [UIColor whiteColor];
  //蒲宝宝第几期
    UILabel *severa = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH/4, thirdView.height)];
    severa.textAlignment = NSTextAlignmentCenter;
    severa.textColor = YGrayColor;
    severa.font = YFont(WINSIZEWIDTH/23);
    severa.text = @"蒲宝宝-期";
    //起头时间
    UILabel *date = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/4, 0, WINSIZEWIDTH/4, thirdView.height)];
    date.textAlignment = NSTextAlignmentCenter;
    date.textColor = YGrayColor;
    date.font = severa.font;
    date.text = @"2015-11-23";
    //交易金额
    UILabel *tradLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, 0, WINSIZEWIDTH/4, thirdView.height)];
    tradLa.textAlignment = NSTextAlignmentCenter;
    tradLa.textColor = YGrayColor;
    tradLa.font = severa.font;
    tradLa.text = @"-元";
    //所得利息
    UILabel *interest = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/4*3, 0, WINSIZEWIDTH/4, tradLa.height)];
    interest.textAlignment = NSTextAlignmentCenter;
    interest.textColor = YGrayColor;
    interest.font = severa.font;
    interest.text = @"-元";
    
    [thirdView addSubview:severa];
    [thirdView addSubview:date];
    [thirdView addSubview:tradLa];
    [thirdView addSubview:interest];
    
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, CGRectGetMaxY(thirdView.frame)+WINSIZEWIDTH/7, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8)];
    investBtn.backgroundColor = YRedColor;
    [investBtn setTitle:@"赎 回" forState:(UIControlStateNormal)];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius=WINSIZEWIDTH/100;

    //[self.view addSubview:investBtn];
   // [self.view addSubview:thirdView];
    [self.view addSubview:secView];
    [self.view addSubview:firstView];
    [self.view addSubview:self.tableView];
    
}
//赎回
-(void)rebackBtnClick:(UIButton *)sender{

    CashViewController *cash = [[CashViewController alloc]init];
    cash.capitialMoney = self.prifit.text;
    cash.title = @"赎回";
    [self.navigationController pushViewController:cash animated:YES];
    
}
#pragma mark -tableviewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.dataArr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/6;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    
    
    YDReemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    //NSLog(@"%@",dic);

    if (!cell) {
        cell = [[YDReemTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        [cell setLayoutMargins:(UIEdgeInsetsZero)];
        [cell setSeparatorInset:(UIEdgeInsetsZero)];
        
        cell.backgroundColor = [UIColor whiteColor];
    }
    NSDictionary *dic;
    if (self.dataArr.count > 0) {
        dic = self.dataArr[indexPath.row];
    float moey = yTwoPointDouble(dic[@"invest_amount_li"]);
    NSLog(@"%f",moey);

    float invest = [dic[@"interest"] floatValue];

    NSLog(@"%f",moey);
    cell.severa.text = dic[@"product_name"];
    cell.date.text = [dic[@"invest_time"] componentsSeparatedByString:@" "][0];
    cell.tradLa.text = [NSString stringWithFormat:@"%0.2lf",moey];
    cell.interest.text = [NSString stringWithFormat:@"%0.2f%%",invest];
    }
    //cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (self.dataArr.count < 1) {
        return;
    }
    
//    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"ShuHuiViewController" bundle:[NSBundle mainBundle]];
    
   // ShuHuiViewController *shvc = [sb instantiateViewControllerWithIdentifier:@"shuhui"];
    //self.vc = shvc;
//    ShuHuiViewController *shvc = [[ShuHuiViewController alloc]initWithNibName:@"ShuHuiViewController" bundle:nil];
    
//    UINib *nib = [UINib nibWithNibName:@"ShuHuiViewControllerFix" bundle:[NSBundle mainBundle]];
  //  ShuHuiViewControllerFix *shvc = [[NSBundle mainBundle] loadNibNamed:@"ShuHuiViewControllerFix" owner:nil options:nil].lastObject;
    ShuHuiViewControllerFix *shvc = [[ShuHuiViewControllerFix alloc]initWithNibName:@"ShuHuiViewControllerFix" bundle:nil];
    self.vc = shvc;
    shvc.investAmountLabel.text = self.base_invest;
//    NSLog(@"++++ %@",dataDic[@"product_name"]);
//    float moey = [dataDic[@"invest_amount"] floatValue];

//        //severa.text = dic[@"product_name"];
//        //date.text = [dic[@"invest_time"] componentsSeparatedByString:@" "][0];
//       // tradLa.text = [NSString stringWithFormat:@"%0.2f",invest+moey];
//
//    shvc.invest_amount_label.text = [NSString stringWithFormat:@"%.2f",[self.base_invest floatValue]];
//    shvc.invest_date_label.text = [dataDic[@"invest_time"] componentsSeparatedByString:@" "][0];
//    shvc.invest_sum_label.text = [NSString stringWithFormat:@"%0.2f",moey];
//    shvc.interest_label.text = [NSString stringWithFormat:@"%@%%",dataDic[@"interest"]];
//    NSLog(@"%@ ----- %@",shvc.invest_amount_label.text,self.base_invest);
//    shvc.product_id = [NSString stringWithFormat:@"%@",dataDic[@"product_id"]];
    
    
    NSDictionary *dataDic = self.dataArr[indexPath.row];
    NSLog(@"%@",dataDic);
    shvc.dataDic = dataDic;
    float moey = [dataDic[@"invest_amount_li"] floatValue];NSLog(@"%f",moey);

    shvc.benjin = [NSString stringWithFormat:@"%f",moey];
    
//    /**赎回到存钱罐*/
//    //用户的 user_phone  金额 amount   备注： summary   产品id product_id
//    // public function createSingleHostingPayTrade(){
//    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
//    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
//    NSString *token = [userdefault objectForKey:TOKEN];
//    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"amount\":\"%@\",\"summary\":\"赎回\",\"product_id\":\"%@\",\"token\":\"%@\"}",user_phone,@"20",dataDic[@"product_id"],token];
//    [SLAlertView showAlertWithMessageString:@"请稍候..."];
//    [IKHttpTool postWithURL:@"createSingleHostingPayTrade" params:@{@"json":param} success:^(id json) {
//        // [SLAlertView hide];
//        [SLAlertView showAlertWithStatusString:@"提交成功"];
//    } failure:^(NSError *error) {
//        // [SLAlertView hide];
//        
//        
//    }];
    
//    [self presentViewController:shvc animated:true completion:nil];
    shvc.title = dataDic[@"product_name"];
    [self.navigationController pushViewController:shvc animated:true];

    //[self.promot makePromptWithTitle:@"提示" message:@"您确定要赎回本期项目吗？" buttonleft:@"取消" buttonright:@"赎回"];
}
//获取商品信息
-(void)getGoodsData{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *phone = [userdefault objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",phone,token];
    self.dataArr = [NSMutableArray array];
    self.goodDataArr = [NSMutableArray array];
    [IKHttpTool postWithURL:@"getInvestInfo" params:@{@"json":param} success:^(id json) {
        self.dataArr = json[@"data"];
        NSLog(@"====%ld===%@",self.dataArr.count,self.dataArr);
        
        for (NSDictionary *str in self.dataArr) {
            [self.goodDataArr addObject:str[@"product_id"]];
        }
        NSLog(@"----%@",self.goodDataArr);
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

//赎回
-(void)invest:(UIButton *)sender{

    CashViewController *cash = [[CashViewController alloc]init];
    cash.title = @"赎回";
    cash.capitialMoney = self.prifit.text;
    
    [self.navigationController pushViewController:cash animated:YES];
}

//传值改变当前页面 总投资金额
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
//    [self getInvestData];
//    NSLog(@"-----====== %.2f",[[ShareViewController sharedViewController].moneyStr floatValue]);
//    
//    if ([[ShareViewController sharedViewController].moneyStr floatValue] > 0) {
//        self.prifit.text = [NSString stringWithFormat:@"%.2f",[self.base_invest floatValue] - [[ShareViewController sharedViewController].moneyStr floatValue]];
//    }
}
//获取投资收益
-(void)getInvestData{
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *user_phone = [userDefault objectForKey:USER_PHONE];
    NSString *token = [userDefault objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"queryInvestSum" params:@{@"json":param} success:^(id json) {
        NSString *data = [NSString stringWithFormat:@"%@",json[@"data"]];
        // 累积投资收益
        double leiji = yTwoPointDouble(data);
        self.invest.text = [NSString stringWithFormat:@"%0.2f",leiji];
    } failure:^(NSError *error) {
        
    }];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    //获取投资收益
    [self getInvestData];
    
    NSString *user_phone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    NSString *token = [[NSUserDefaults standardUserDefaults]valueForKey:TOKEN];
    
    NSString *param2 = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param2} success:^(id json) {
        //self.user_banlance = [NSString stringWithFormat:@"%@",json[@"data"][@"user_balance"]];//用户余额
        self.base_invest = [NSString stringWithFormat:@"%@",json[@"data"][@"base_investment"]];
        CGFloat abc = yTwoPointDouble(self.base_invest);
        //总投资金额
        self.prifit.text = [NSString stringWithFormat:@"%.2lf",abc];
       // self.leiJiShouYi = [NSString stringWithFormat:@"%@",json[@"data"][@"sum_profit"]];
       // self.invest.text = [NSString stringWithFormat:@"%.2f",[self.leiJiShouYi floatValue]];
    } failure:^(NSError *error) {
        
    }];

    //获取用户铺宝宝投资列表
    [self getGoodsData];
    
}

@end
