//
//  ZSYViewController.h
//  ZSY
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZSYViewController : UIViewController
@property(nonatomic,strong)NSString *allProfit;//总收益
@end
