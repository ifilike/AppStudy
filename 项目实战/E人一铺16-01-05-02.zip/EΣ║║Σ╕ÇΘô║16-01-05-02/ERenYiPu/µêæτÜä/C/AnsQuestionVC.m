//
//  AnsQuestionVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/18.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AnsQuestionVC.h"
#import "SLAlertView.h"

@interface AnsQuestionVC ()<UITextViewDelegate>
@property (nonatomic,strong) UITextView *textView;//回答
@property (nonatomic,strong) UILabel *question;//问题
@end

@implementation AnsQuestionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"回答问题";
    self.view.backgroundColor = [UIColor whiteColor];
    [self createUI];
    // Do any additional setup after loading the view.
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/8)];
    firstView.backgroundColor = [UIColor colorWithHexString:@"ececec"];
    
    UILabel *symbLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH, firstView.height)];
    symbLal.text = @"*回答正确签到金额翻倍、答错减半";
    symbLal.font = YFont(WINSIZEWIDTH/22);
    symbLal.textColor = [UIColor colorWithHexString:@"fcc36e"];
    
    [firstView addSubview:symbLal];
    
    self.question = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/20, WINSIZEWIDTH - WINSIZEWIDTH/10, WINSIZEWIDTH)];
    CGRect fram = self.question.frame;
    self.question.textColor = YRedColor;
    self.question.text = @"请问E人一铺是什么时候上市的？";
    self.question.font = YBFont(WINSIZEWIDTH/22);
    self.question.textAlignment = NSTextAlignmentCenter;
    self.question.frame = [self.question textRectForBounds:fram limitedToNumberOfLines:10];
    self.textView = [[UITextView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/6, CGRectGetMaxY(self.question.frame)+WINSIZEWIDTH/20, WINSIZEWIDTH - WINSIZEWIDTH/3, WINSIZEWIDTH/4)];
    self.textView.layer.cornerRadius = WINSIZEWIDTH/80;
    self.textView.layer.borderColor = YRedColor.CGColor;
    self.textView.layer.borderWidth = 1;
    self.textView.font = YFont(WINSIZEWIDTH/22);
    self.textView.delegate = self;
    self.textView.textContainerInset = UIEdgeInsetsMake(WINSIZEWIDTH/50, WINSIZEWIDTH/50, WINSIZEWIDTH/50, WINSIZEWIDTH/50);
    //textview的提示语
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/50, WINSIZEWIDTH/50, WINSIZEWIDTH/6, WINSIZEWIDTH/20)];
    label.text = @"请回答";
    label.tag = 1000;
    label.font = YFont(WINSIZEWIDTH/22);
    label.textColor = [UIColor colorWithHexString:@"bcbcbc"];
    [self.textView addSubview:label];
    UIButton *ansBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2-WINSIZEWIDTH/10-WINSIZEWIDTH/60, CGRectGetMaxY(self.textView.frame)+WINSIZEWIDTH/8, WINSIZEWIDTH/5+WINSIZEWIDTH/30, WINSIZEWIDTH/10)];
    [ansBtn setTitle:@"答题" forState:(UIControlStateNormal)];
    [ansBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [ansBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    ansBtn.backgroundColor = YRedColor;
    ansBtn.titleLabel.font = YBFont(WINSIZEWIDTH/15);
    [ansBtn addTarget:self action:@selector(answer:) forControlEvents:(UIControlEventTouchUpInside)];
    ansBtn.layer.cornerRadius = WINSIZEWIDTH/60;
    [self.view addSubview:ansBtn];
    [self.view addSubview:self.question];
    [self.view addSubview:self.textView];
    [self.view addSubview:firstView];
}
-(void)textViewDidChange:(UITextView *)textView{

    UILabel *label = (UILabel *)[self.view viewWithTag:1000];
    if (textView.text.length == 0) {
        label.text = @"请回答";
    }else{
    
        label.text  =@"";
    }
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
-(void)answer:(UIButton *)sender{

    if (self.textView.text.length < 1) {
        //[SLAlertView showAlertWithStatusString:@"回到内容不呢过为空"];
//        [MBProgressHUD showError:@"回答内容不能为空"];
        return;
    }else{
    
        [self.view endEditing:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
