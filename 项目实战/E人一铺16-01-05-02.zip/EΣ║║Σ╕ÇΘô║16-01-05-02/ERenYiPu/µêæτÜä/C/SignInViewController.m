//
//  SignInViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/17.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SignInViewController.h"
#import "AnsQuestionVC.h"
#import "SLAlertView.h"
#import "TopUpController.h"
#import "InviteViewController.h"
@interface SignInViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>
{
    UIButton *makTask;  //做任务 按钮
    CGFloat todayMoney; //今日充值
}
@property(nonatomic,strong)UICollectionView *collection;
@property(nonatomic,assign)NSUInteger days;//本月天数
@property(nonatomic,assign)NSUInteger nilDays;//一起周空白几天
@property(nonatomic,assign)NSUInteger nowday;//今天几号
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,assign)int sym;//根据值跳转界面
@property(nonatomic,strong)NSArray *signdays;//签到的日期
@property(nonatomic,strong)UILabel *taskLa;//任务
@end

@implementation SignInViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.sym = 0;
    self.title = @"签到";
    self.view.backgroundColor = YBackGrayColor;
    
    [self getSign];//获取签到信息
    [self createUI];

    // Do any additional setup after loading the view.
}
-(void)createUI{

    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH - WINSIZEWIDTH/5.8)];
    firstView.backgroundColor = [UIColor whiteColor];
    UIView *outerView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/7, WINSIZEWIDTH-WINSIZEWIDTH/5, firstView.height - WINSIZEWIDTH/5.7)];
    outerView.layer.cornerRadius = WINSIZEWIDTH/60;
    outerView.layer.borderColor = [UIColor colorWithHexString:@"bcbcbc"].CGColor;
    outerView.layer.borderWidth = 2.0f;
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.minimumInteritemSpacing = 1;
    flowLayout.minimumLineSpacing = 1;
    [flowLayout setItemSize:CGSizeMake((outerView.width - WINSIZEWIDTH/10-6-2)/7, (outerView.height - WINSIZEWIDTH/10 - WINSIZEWIDTH/20-5.5)/6)];
    flowLayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.collection = [[UICollectionView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/10, outerView.width - WINSIZEWIDTH/10 , outerView.height - WINSIZEWIDTH/10 - WINSIZEWIDTH/20 ) collectionViewLayout:flowLayout];
    self.collection.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
    self.collection.delegate = self;
    self.collection.dataSource = self;
    self.collection.layer.borderWidth = 1;
    self.collection.layer.borderColor = YGrayColor.CGColor;
    self.collection.showsHorizontalScrollIndicator = NO;
    self.collection.showsVerticalScrollIndicator = YES;
    for (int i = 0; i<7; i++) {
        UILabel *weedbal = [[UILabel alloc]initWithFrame:CGRectMake(self.collection.x+self.collection.width/7*i, self.collection.y-self.collection.height/6, self.collection.width/7, self.collection.height/6)];
        weedbal.textColor = YRedColor;
        weedbal.font = YBFont(WINSIZEWIDTH/21);
        weedbal.textAlignment = NSTextAlignmentCenter;
        switch (i) {
            case 0:
                weedbal.text = @"日";
                break;
                case 1:
                weedbal.text = @"一";
                break;
                case 2:
                weedbal.text = @"二";
                break;
                case 3:
                weedbal.text = @"三";
                break;
                case 4:
                weedbal.text = @"四";
                break;
                case 5:
                weedbal.text = @"五";
                break;
                case 6:
                weedbal.text = @"六";
                break;
            default:
                break;
        }
        [outerView addSubview:weedbal];
    }
    [outerView addSubview:self.collection];

    UILabel *sybmLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH/2, outerView.y)];
    sybmLal.textColor = YRedColor;
    sybmLal.text = @"每日签到";
    sybmLal.font = YBFont(WINSIZEWIDTH/20);
    
    [firstView addSubview:sybmLal];
    [firstView addSubview:outerView];
    
    UIView *secView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame), WINSIZEWIDTH, WINSIZEHEIGHT - firstView.height-64)];
    secView.backgroundColor = [UIColor whiteColor];
   
    UIView *vorView = [[UIView alloc]initWithFrame:CGRectMake(outerView.x, 0, outerView.width, WINSIZEWIDTH/8.4)];
    vorView.layer.borderColor = [UIColor colorWithHexString:@"bcbcbc"].CGColor;
    vorView.layer.borderWidth = 1.0f;
    vorView.layer.cornerRadius = WINSIZEWIDTH/80;
    self.taskLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH/2, vorView.height)];
    self.taskLa.text = @"充值";
    self.taskLa.font = YFont(WINSIZEWIDTH/20);
    self.taskLa.textColor = YBlackColor;
    makTask = [[UIButton alloc]initWithFrame:CGRectMake(vorView.width-WINSIZEWIDTH/5.8, WINSIZEWIDTH/35, WINSIZEWIDTH/7, vorView.height - WINSIZEWIDTH/17.5)];
    makTask.backgroundColor = YRedColor;
    [makTask setTitle:@"做任务" forState:(UIControlStateNormal)];
    [makTask setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [makTask setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    [makTask addTarget:self action:@selector(maktask:) forControlEvents:(UIControlEventTouchUpInside)];
    makTask.titleLabel.font = YBFont(WINSIZEWIDTH/25);
    makTask.layer.cornerRadius = WINSIZEWIDTH/80;
    [vorView addSubview:self.taskLa];
    [vorView addSubview:makTask];
    UIView *vorView2 = [[UIView alloc]initWithFrame:CGRectMake(vorView.x, CGRectGetMaxY(vorView.frame)+WINSIZEWIDTH/30, vorView.width, vorView.height)];
    vorView2.layer.cornerRadius = WINSIZEWIDTH/80;
    vorView2.layer.borderWidth = 1.0f;
    vorView2.layer.borderColor = vorView.layer.borderColor;
    //邀请
    UILabel *investBa = [[UILabel alloc]initWithFrame:CGRectMake(self.taskLa.x, self.taskLa.y, self.taskLa.width, self.taskLa.height)];
    investBa.text = @"邀请";
    investBa.textColor = self.taskLa.textColor;
    investBa.font = self.taskLa.font;
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(makTask.x, makTask.y, makTask.width, makTask.height)];
    [investBtn setTitle:@"做任务" forState:(UIControlStateNormal)];
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    [investBtn setBackgroundColor:YRedColor];
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.layer.cornerRadius = makTask.layer.cornerRadius;
    investBtn.titleLabel.font = makTask.titleLabel.font;
    [vorView2 addSubview:investBa];
    [vorView2 addSubview:investBtn];
    
    //温馨提示
    UIButton *promBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEHEIGHT/35, CGRectGetMaxY(vorView2.frame)+WINSIZEWIDTH/15, WINSIZEWIDTH/4.5, WINSIZEWIDTH/13)];
    promBtn.layer.cornerRadius = WINSIZEWIDTH/80;
    [promBtn setBackgroundColor:[UIColor colorWithHexString:@"f7c34d"]];
    [promBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [promBtn setTitle:@"温馨提示" forState:(UIControlStateNormal)];
    promBtn.titleLabel.font = YBFont(WINSIZEWIDTH/25);
    
    UILabel *taskcont = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/12, CGRectGetMaxY(promBtn.frame)+WINSIZEWIDTH/50, WINSIZEWIDTH-WINSIZEWIDTH/6, WINSIZEWIDTH/4)];
    taskcont.textColor = YGrayColor;
    taskcont.font = YFont(WINSIZEWIDTH/26);
    taskcont.text = @" * 因系统升级，凡总投资高于1000元者每日签到、每日邀请活动正常使用，但每日任务（每日签到、每日充值、每日邀请）5元奖励活动暂停使用，升级结束再行恢复，如有不便敬请谅解。";
    taskcont.numberOfLines = 0;
    NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc]initWithString:taskcont.text];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
    [style setLineSpacing:WINSIZEWIDTH/80];
    CGFloat textwidth = taskcont.width;
    NSInteger length = textwidth;
    if (attribute.length < textwidth) {
        length = attribute.length;
    }
    [attribute addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, length)];
    taskcont.attributedText = attribute;
    UILabel *investCont = [[UILabel alloc]initWithFrame:CGRectMake(taskcont.x, CGRectGetMaxY(taskcont.frame)+WINSIZEWIDTH/100, taskcont.width, WINSIZEWIDTH/6)];
    investCont.font = taskcont.font;
    investCont.textColor = taskcont.textColor;
    investCont.text = @" * 新系统上线后一铺用户分享并邀请好友注册下载APP2.0版本，只要被邀请人填写邀请人邀请码、并成功充值100元认证绑卡成功后双方即可各自获得10元现金红包，红包金额次日到账并可提现";
    attribute = [[NSMutableAttributedString alloc]initWithString:investCont.text];
    investCont.numberOfLines = 0;
    textwidth = investCont.width;
    length = textwidth;
    if (attribute.length < textwidth) {
        length = attribute.length;
    }
    [attribute addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, length)];
   // investCont.attributedText = attribute;

    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(outerView.x+self.collection.x, outerView.y, self.collection.width, secView.height - outerView.y)];
    self.tableView.delegate = self;
    self.tableView.dataSource  =self;
    self.tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.bounces = NO;
   // [secView addSubview:self.tableView];
    
    [secView addSubview:taskcont];
    [secView addSubview:vorView];
    [secView addSubview:vorView2];
    [secView addSubview:promBtn];
  //  [secView addSubview:investCont];
    UIView *thirdView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH/4.6)];
    thirdView.backgroundColor = [UIColor whiteColor];
    UILabel *monthTask = [[UILabel alloc]initWithFrame:CGRectMake(sybmLal.x, 0, sybmLal.width, WINSIZEWIDTH/7.5)];
    monthTask.textColor = YRedColor;
    monthTask.font = sybmLal.font;
    monthTask.text = @"每月任务";
    UILabel *monthCont = [[UILabel alloc]initWithFrame:CGRectMake(taskcont.x, CGRectGetMaxY(monthTask.frame)-WINSIZEWIDTH/30, taskcont.width, thirdView.height - monthTask.height)];
    monthCont.text = @" * 每月任务完成可获得18元红包+一铺金币80枚。";
    
    monthCont.numberOfLines = 2;
    monthCont.textColor = YGrayColor;
    monthCont.font = taskcont.font;
 //   UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(tableView.width-WINSIZEWIDTH/6, WINSIZEWIDTH/9/5+1, WINSIZEWIDTH/7, WINSIZEWIDTH/9 - 1 - WINSIZEWIDTH/9/2.5)];

    UIButton *statuBtn = [[UIButton alloc]initWithFrame:CGRectMake(makTask.x+vorView.x,WINSIZEWIDTH/30,  makTask.width,makTask.height)];
    statuBtn.backgroundColor = YRedColor;
    [statuBtn setTitle:@"未完成" forState:(UIControlStateNormal)];
    [statuBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [statuBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    [statuBtn addTarget:self action:@selector(task:) forControlEvents:(UIControlEventTouchUpInside)];
    statuBtn.titleLabel.font = YFont(WINSIZEWIDTH/24);
    statuBtn.layer.cornerRadius = WINSIZEWIDTH/80;
    statuBtn.tag = 1100;
    
    [thirdView addSubview:statuBtn];
    [thirdView addSubview:monthTask];
    [thirdView addSubview:monthCont];
    
    [self.view addSubview:firstView];
    [self.view addSubview:secView];
//获取本月日历
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSRange range  = [calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSMonthCalendarUnit forDate:[NSDate date]];
    NSUInteger numberOfDaysInMonth = range.length;
    
    NSDate *date =[NSDate date];
    NSLog(@"-------number:%ld  date:%@",numberOfDaysInMonth,date);
 
    unsigned unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit |  NSDayCalendarUnit | NSWeekdayCalendarUnit | NSCalendarUnitWeekdayOrdinal;
    NSDateComponents *components = [calendar components:unitFlags fromDate:[NSDate date]];
    
//    NSInteger iCurYear = [components year];  //当前的年份
//    NSInteger iCurMonth = [components month];  //当前的月份
//    NSInteger iiii  = [components weekday];
    
    NSInteger iCurDay = [components day];  // 当前的号数

    self.nowday = iCurDay;
    NSUInteger weekday = [components weekday];;
    self.days = numberOfDaysInMonth;
    self.nilDays = (weekday + 7 - self.nowday%7)%7;
    NSLog(@"------day:%ld nilday:%ld %ld %ld",self.days,self.nilDays,weekday,[components weekday]);
}
//充值
-(void)maktask:(UIButton *)sender{
    
    [self.navigationController pushViewController:[TopUpController new] animated:YES];
    //  [MBProgressHUD showError:@"没做那还"];
}
//邀请
-(void)invest:(UIButton *)sender{

    [self.navigationController pushViewController:[InviteViewController new] animated:YES];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self getAllDepostOneDay];
}

#pragma mark -- collectionDelegate
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{

    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{

    return 42;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    [self.collection registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, cell.width, cell.height)];
    label.tag = 100000+indexPath.row;
    label.font = YFont(WINSIZEWIDTH/23);
    label.textAlignment = NSTextAlignmentCenter;
    label.backgroundColor = [UIColor whiteColor];
    [cell.contentView addSubview:label];
    
    label.textColor = YBlackColor;
    if (indexPath.row>=self.nilDays&&indexPath.row<self.days+self.nilDays) {
        label.text = [NSString stringWithFormat:@"%ld",indexPath.row-self.nilDays+1];
        if ([label.text integerValue]==self.nowday) {
            label.textColor = YRedColor;
        }
        UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(cell.width/4, cell.height/2, cell.width/2, cell.height/2)];
        image.image = [UIImage imageNamed:@"duigou"];
        image.tag = 1000+indexPath.row;
        image.hidden = YES;
        for (int i = 0; i<self.signdays.count; i++) {
            if ([label.text isEqualToString:self.signdays[i]]) {
                image.hidden = NO;
            }
        }
        [cell.contentView addSubview:image];
        //NSLog(@"%ld-------------%ld",indexPath.row,image.tag);
    }

    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
//    UIImageView *imageview = (UIImageView *)[collectionView viewWithTag:1000+indexPath.row];
//
//    imageview.hidden = !imageview.hidden;
    [SLAlertView showAlertWithMessageString:@"请稍候..."];
    BOOL status = YES;
    for (int i = 0; i<self.signdays.count; i++) {
        if ([[NSString stringWithFormat:@"%lu",(unsigned long)self.nowday] isEqualToString:self.signdays[i]]) {
            [SLAlertView showAlertWithStatusString:@"您已经签过了，下次再来吧"];
            //[SLAlertView showAlertWithImage:[UIImage imageNamed:@"签到"]];
            //[self.promptView showPromptWithTitle:@"tishi" message:@"您已签到成功" buttonleft:@"取消" buttonright:@"回答问题"];
            return;
        }
    }
    if (status) {
        
        
        
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
    [IKHttpTool postWithURL:@"sign" params:@{@"json":param} success:^(id json) {
       // NSLog(@"------user_phone:%@",user_phone);

        [SLAlertView showAlertWithImage:[UIImage imageNamed:@"签到"]];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            UIImageView *imageview = (UIImageView *)[self.collection viewWithTag:10000000+indexPath.row];
//            //NSLog(@"%ld",imageview.tag);
//            imageview.hidden = NO;
//        });
        
        [self getSign];
    } failure:^(NSError *error) {
        
    }];
    }
   // [self.navigationController pushViewController:[AnsQuestionVC new] animated:YES];
    //NSLog(@"-------------collec:%ld",indexPath.row);
}

-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.row<self.nilDays||indexPath.row>self.nilDays+self.days-1) {
        return NO;
    }
    NSLog(@"----");
    if (indexPath.row==self.nilDays+self.nowday-1) {
        return YES;
    }
    return NO;
}
#pragma mark -- getsign
-(void)getSign{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *phone = [userdefault objectForKey:USER_PHONE];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",phone,token];
    [IKHttpTool postWithURL:@"signListInfo" params:@{@"json":param} success:^(id json) {
        NSLog(@"-----json:%@",json);
        NSString *str = [NSString stringWithFormat:@"%@",json[@"data"]];
        self.signdays = [str componentsSeparatedByString:@":"];
        NSLog(@"-----singday:%@",self.signdays);
        [self.collection reloadData];
    } failure:^(NSError *error) {
        
    }];
    
}
#pragma mark -- tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 5;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return WINSIZEWIDTH/9;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    NSArray *array = @[@"签到",@"投标",@"推送",@"充值",@"提现"];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    UILabel *textlabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 1, WINSIZEWIDTH/3, WINSIZEWIDTH/9-1)];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0,0, tableView.width, 1)];
        view.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
        
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(tableView.width-WINSIZEWIDTH/6, WINSIZEWIDTH/9/5+1, WINSIZEWIDTH/7, WINSIZEWIDTH/9 - 1 - WINSIZEWIDTH/9/2.5)];
        button.tag = 1000+indexPath.row;
        [button addTarget:self action:@selector(task:) forControlEvents:(UIControlEventTouchUpInside)];
        [button setTitle:@"未完成" forState:(UIControlStateNormal)];
        [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        [button setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
        button.titleLabel.font = YFont(WINSIZEWIDTH/24);
        button.backgroundColor = YRedColor;
        button.layer.cornerRadius = WINSIZEWIDTH/80;
        
        textlabel.textColor = YGrayColor;
        textlabel.font = YBFont(WINSIZEWIDTH/20);
        [cell addSubview:textlabel];
        [cell addSubview:button];
        [cell addSubview:view];
         cell.selectionStyle = UITableViewCellSelectionStyleNone;

    }
    
    textlabel.text = array[indexPath.row];
    return cell;
}
//任务
-(void)task:(UIButton *)sender{

    UIAlertView *alertView = [UIAlertView new];
    alertView.tintColor = YRedColor;//[UIColor colorWithHexString:@"bcbcbc"];
    switch (sender.tag) {
        case 1000:
            alertView = [[UIAlertView alloc]initWithTitle:@"签到" message:@"当日签到即可完成任务" delegate:self cancelButtonTitle:@"返回" otherButtonTitles:nil, nil];
            [alertView show];
            break;
            case 1001:
            alertView = [[UIAlertView alloc]initWithTitle:@"投标" message:@"当日投资一个标，即可完成" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"去投标", nil];
            [alertView show];
            break;
            case 1002:
            break;
            case 1003:
            break;
            case 1100:
            //[self.promptView makePromptWithTitle:@"每日任务" message:@"做满每日任务一个月一天不落的即算完成每月任务" buttonleft:@"返回" buttonright:nil];
          //  alertView = [[UIAlertView alloc]initWithTitle:@"每月任务" message:@"做满每日任务一个月一天不落的即算完成每月任务" delegate:self cancelButtonTitle:@"去返回" otherButtonTitles: nil];
           // [alertView show];
            break;
        default:
            break;
    }
}
-(void)actionWithButtonIndex:(NSInteger)buIndex{

    if (self.sym==1) {
        [self.navigationController pushViewController:[AnsQuestionVC new] animated:YES];
    }
    NSLog(@"------------");
}

//查询当天充值总金额
- (void)getAllDepostOneDay
{
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]valueForKey:USER_PHONE];
    NSString *token = [[NSUserDefaults standardUserDefaults]valueForKey:TOKEN];
    
    NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",userPhone,token];
    
    [IKHttpTool postWithURL:@"queryDepositWithDay" params:@{@"json":param} success:^(id json) {
        
        todayMoney = [json[@"data"] floatValue];
        
        if (todayMoney >= 1000) {
            [makTask setBackgroundColor:[UIColor grayColor]];
            makTask.enabled = NO;
            [makTask setTitle:@"已完成" forState:(UIControlStateNormal)];
        }
        
    } failure:^(NSError *error) {
        
    }];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
