//
//  AnsQuestionVC.h
//  ERenYiPu
//
//  Created by babbage on 15/11/18.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnsQuestionVC : UIViewController

@end
