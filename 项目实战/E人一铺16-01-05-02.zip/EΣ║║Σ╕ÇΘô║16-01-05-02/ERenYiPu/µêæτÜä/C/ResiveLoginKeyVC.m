//
//  ResiveLoginKeyVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/16.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ResiveLoginKeyVC.h"
#import "SLAlertView.h"

@interface ResiveLoginKeyVC ()
@property(nonatomic,strong)UITextField *currentKeyField;//当前登录密码
@property(nonatomic,strong)UITextField *NewKeyField;//新的登录密码
@property(nonatomic,strong)UITextField *seckeyField;//确认新的登录密码
@end

@implementation ResiveLoginKeyVC
-(UITextField *)currentKeyField{

    if (!_currentKeyField) {
        _currentKeyField = [[UITextField alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/4*3, WINSIZEWIDTH/7)];
        _currentKeyField.placeholder = @"当前登录密码";
        _currentKeyField.font = YFont(WINSIZEWIDTH/20);
    }
    return _currentKeyField;
}
-(UITextField *)NewKeyField{

    if (!_NewKeyField) {
        _NewKeyField = [[UITextField alloc]initWithFrame:CGRectMake(self.currentKeyField.x, self.currentKeyField.y, self.currentKeyField.width, self.currentKeyField.height)];
        _NewKeyField.placeholder = @"请输入新的登录密码";
        _NewKeyField.font = self.currentKeyField.font;
        _NewKeyField.secureTextEntry = YES;
    }
    return _NewKeyField;
}
-(UITextField *)seckeyField{

    if (!_seckeyField) {
        _seckeyField = [[UITextField alloc]initWithFrame:CGRectMake(self.currentKeyField.x, self.currentKeyField.y, self.currentKeyField.width, self.currentKeyField.height)];
        _seckeyField.placeholder = @"请确认新的登录密码";
        _seckeyField.font = YFont(WINSIZEWIDTH/20);
        _seckeyField.secureTextEntry = YES;
    }
    return _seckeyField;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"修改登录密码";
    self.view.backgroundColor = YBackGrayColor;
    [self createUI];
    // Do any additional setup after loading the view.
}
-(void)createUI{

    for (int i = 0; i<3; i++) {
        UIView *view = [[UIView alloc]init];
        view.frame = CGRectMake(0, (WINSIZEWIDTH/7+WINSIZEWIDTH/30)*i, WINSIZEWIDTH, WINSIZEWIDTH/7);
        [self.view addSubview:view];
        view.backgroundColor = [UIColor whiteColor];
        switch (i) {
            case 0:
                [view addSubview:self.currentKeyField];
                break;
                case 1:
                [view addSubview:self.NewKeyField];
                break;
                case 2:
                [view addSubview:self.seckeyField];
                break;
            default:
                break;
        }
    }
    //确认按钮
    UIButton *backCount = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, WINSIZEWIDTH/2+WINSIZEWIDTH/5, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8-WINSIZEWIDTH/100)];
    backCount.backgroundColor = YRedColor;
    [backCount setTitle:@"完 成" forState:(UIControlStateNormal)];
    [backCount setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [backCount setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    backCount.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [backCount addTarget:self action:@selector(resiveOver:) forControlEvents:(UIControlEventTouchUpInside)];
    backCount.layer.cornerRadius = WINSIZEWIDTH/100;
    [self.view addSubview:backCount];
}
//完成
-(void)resiveOver:(UIButton *)sender{

    if (self.currentKeyField.text.length<1) {
        [SLAlertView showAlertWithStatusString:@"当前登录密码不能为空"];
//        [MBProgressHUD showError:@"当前登录密码不能为空"];
        return;
    }else if(self.NewKeyField.text.length<1){
        [SLAlertView showAlertWithStatusString:@"新的登录密码不能为空"];
//        [MBProgressHUD showError:@"新的登录密码不能为空"];
        return;
    }else if (self.NewKeyField.text.length < 6){
        [SLAlertView showAlertWithStatusString:@"新的登录密码不能小于6位"];
        return;
    }else if (self.NewKeyField.text.length > 20){
        [SLAlertView showAlertWithStatusString:@"密码长度不能大于20"];
        return;
    }else if(![self.NewKeyField.text isEqualToString:self.seckeyField.text]){
        [SLAlertView showAlertWithStatusString:@"两次密码输入不一致，请重新输入"];
//        [MBProgressHUD showError:@"两次密码输入不一致，请重新输入"];
        return;
    }
    [SLAlertView showAlertWithMessageString:@"请稍候..."];
    [self.view endEditing:YES];
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *phone = [userDefault objectForKey:@"user_phone"];
    NSString *token = [userDefault objectForKey:TOKEN];
    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"password\":\"%@\",\"new_password\":\"%@\",\"token\":\"%@\"}",phone,self.currentKeyField.text,self.NewKeyField.text,token];
    [IKHttpTool postWithURL:@"changePassword" params:@{@"json":str} success:^(id json) {
        [SLAlertView showAlertWithStatusString:json[@"msg"]];
//        [MBProgressHUD showSuccess:json[@"msg"]];
        NSLog(@"--------json:%@",json);
        [userDefault setObject:json[@"data"][@"password"] forKey:@"password"] ;
        [self.navigationController popViewControllerAnimated:YES];
    } failure:^(NSError *error) {
        //[SLAlertView showAlertWithStatusString:@"修改密码失败,请稍候再试"];
    }];
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{

    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
