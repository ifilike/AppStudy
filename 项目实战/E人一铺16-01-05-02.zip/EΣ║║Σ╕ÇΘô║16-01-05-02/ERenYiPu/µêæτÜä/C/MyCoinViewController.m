//
//  MyCoinViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/17.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MyCoinViewController.h"

@interface MyCoinViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *comtableView;//金币来源
@property(nonatomic,strong)UITableView *cantableView;//我能兑换
@property(nonatomic,strong)UIView *myView;//我的金币界面

@end

@implementation MyCoinViewController
-(UIView *)myView{

    if (!_myView) {
        _myView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/20, WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/8)];
        _myView.backgroundColor = [UIColor whiteColor];
        _myView.layer.cornerRadius = WINSIZEWIDTH/80;
    }
    return _myView;
}
-(UITableView *)comtableView{

    if (!_comtableView) {
        _comtableView = [[UITableView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/20+CGRectGetMaxY(self.myView.frame), WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/2+WINSIZEWIDTH/20)];
        _comtableView.layer.cornerRadius = WINSIZEWIDTH/80;
        _comtableView.dataSource = self;
        _comtableView.dataSource = self;
        _comtableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _comtableView.tableFooterView = [[UIView alloc]init];
        _comtableView.bounces = NO;
        _comtableView.showsVerticalScrollIndicator = NO;
    }
    return _comtableView;
}
-(UITableView *)cantableView{

    if (!_cantableView) {
        _cantableView = [[UITableView alloc]initWithFrame:CGRectMake(self.comtableView.x, CGRectGetMaxY(self.comtableView.frame)+WINSIZEWIDTH/20, self.comtableView.width, self.comtableView.height+WINSIZEWIDTH/15)];
        _cantableView.layer.cornerRadius = WINSIZEWIDTH/80;
        _cantableView.dataSource = self;
        _cantableView.delegate = self;
       _cantableView.separatorStyle = UITableViewCellSeparatorStyleNone
        ;
        _cantableView.tableFooterView = [[UIView alloc]init];
        _cantableView.bounces = NO;
        _cantableView.showsVerticalScrollIndicator = NO;
    }
    return _cantableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title  = @"我的金币";
    self.view.backgroundColor = YBackGrayColor;
    
    UILabel *mycoin = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH/2, WINSIZEWIDTH/8)];
    mycoin.text = @"我的金币";
    mycoin.font = YBFont(WINSIZEWIDTH/18);
    mycoin.textColor = YRedColor;
    UILabel *coin = [[UILabel alloc]initWithFrame:CGRectMake(self.myView.width-WINSIZEWIDTH/2.1, 0, WINSIZEWIDTH/2.5, WINSIZEWIDTH/8)];
    coin.textColor = YGrayColor;
    coin.text = @"0个";
    coin.textAlignment = NSTextAlignmentRight;
    coin.font = YFont(WINSIZEWIDTH/20);
    
    [self.myView addSubview:mycoin];
    [self.myView addSubview:coin];
    [self.view addSubview:self.myView];
    [self.view addSubview:self.comtableView];
    [self.view addSubview:self.cantableView];
    
    // Do any additional setup after loading the view.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if (tableView == self.comtableView) {
        return 4;
    }
    if (tableView == self.cantableView) {
        return 3;
    }
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (tableView==self.comtableView) {
        return WINSIZEWIDTH/8;
    }
    if (tableView == self.cantableView) {
        if (indexPath.row==0) {
            return WINSIZEWIDTH/8;
        }
        return WINSIZEWIDTH/4;
    }
    return 0;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (tableView==self.comtableView) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"fCell"];
        //任务来源
        UILabel *leftLab = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, 0, WINSIZEWIDTH/4, WINSIZEWIDTH/8)];
        leftLab.textColor = YGrayColor;
        leftLab.font = YFont(WINSIZEWIDTH/20);
        //个数
        UILabel *qualtLa = [[UILabel alloc]initWithFrame:CGRectMake(tableView.width - WINSIZEWIDTH/3, 0, WINSIZEWIDTH/4, WINSIZEWIDTH/8)];
        qualtLa.textColor = YGrayColor;
        qualtLa.font = leftLab.font;
        qualtLa.textAlignment = NSTextAlignmentRight;
        if (!cell) {
            cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"fCell"];
            if(indexPath.row==0){
                UILabel *symBal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH/2, cell.height)];
                symBal.textColor = YRedColor;
                symBal.text = @"任务来源";
                symBal.font = YBFont(WINSIZEWIDTH/18);
                [cell.contentView addSubview:symBal];
            }
            if (indexPath.row!=0) {
                [cell.contentView addSubview:leftLab];
                [cell.contentView addSubview:qualtLa];
            }
            UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, cell.height-1, tableView.width-WINSIZEWIDTH/7.5, 1)];
            lineView.backgroundColor = YBackGrayColor;
            [cell.contentView addSubview:lineView];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
          //  cell.backgroundColor = YBlackColor;
        }
#warning mark -- 任务定之后要该
        NSArray *array = @[@"",@"每日任务",@"天降金币",@"每月任务"];
        leftLab.text = array[indexPath.row];
        qualtLa.text = @"0个";
        return cell;
    }
#pragma mark -- 我能兑换
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"canCell"];
    //能兑换的东西，现在是加息卡
    UIImageView *canImage = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/30, WINSIZEWIDTH/3, WINSIZEWIDTH/4-WINSIZEWIDTH/15)];
    canImage.image = [UIImage imageNamed:@"testjiaxi"];
    //金币
    UILabel *coinLab = [[UILabel alloc]initWithFrame:CGRectMake(tableView.width-WINSIZEWIDTH/3, WINSIZEWIDTH/100, WINSIZEWIDTH/4, WINSIZEWIDTH/10)];
    coinLab.text = @"0个金币";
    coinLab.textColor = YGrayColor;
    coinLab.font = YFont(WINSIZEWIDTH/20);
    coinLab.textAlignment = NSTextAlignmentRight;
    //兑换
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(tableView.width-WINSIZEWIDTH/4-WINSIZEWIDTH/50, CGRectGetMaxY(coinLab.frame)+WINSIZEWIDTH/50, WINSIZEWIDTH/6+WINSIZEWIDTH/50, WINSIZEWIDTH/11)];
    button.backgroundColor = YRedColor;
    [button setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [button setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    [button setTitle:@"兑换" forState:(UIControlStateNormal)];
    button.titleLabel.font = YBFont(WINSIZEWIDTH/15);
    button.layer.cornerRadius = WINSIZEWIDTH/60;
    [button addTarget:self action:@selector(change:) forControlEvents:(UIControlEventTouchUpInside)];
    button.tag = 1000+indexPath.row;
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"canCell"];

        if(indexPath.row==0){
            UILabel *symBal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, 0, WINSIZEWIDTH/2, cell.height)];
            symBal.textColor = YRedColor;
            symBal.text = @"我能兑换";
            symBal.font = YBFont(WINSIZEWIDTH/18);
            [cell.contentView addSubview:symBal];
           // cell.backgroundColor = [];
        }

        if(indexPath.row!=0){
        [cell.contentView addSubview:button];
        [cell.contentView addSubview:coinLab];
        [cell.contentView addSubview:canImage];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    //cell.backgroundColor = YRedColor;
    return cell;
}
//兑换
-(void)change:(UIButton *)sender{

    NSLog(@"--------sender:%ld",sender.tag);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
