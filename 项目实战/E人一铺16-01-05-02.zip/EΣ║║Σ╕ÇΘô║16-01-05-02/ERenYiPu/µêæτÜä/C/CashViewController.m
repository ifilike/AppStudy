//
//  CashViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/13.
//  Copyright © 2015年 babbage. All rights reserved.
//



#import "CashViewController.h"
#import "PayVIew.h"
#import "SLAlertView.h"
#import "RedeemContrller.h"
#import "ShareViewController.h"
@interface CashViewController()<PayVIeWDelegate,UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITextField *moneyField;//提现金额
@property(nonatomic,strong)UILabel *cashMoney;//可提现金额
@property(nonatomic,strong)UITextField *redeemField;//备注
@property(nonatomic,strong)PayVIew *payView;
@property(nonatomic,strong)UILabel *bankName;//银行卡名字
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *cardArr;
@property(nonatomic,strong)NSArray *allCardArr;
@property(nonatomic,strong)NSArray *allCardNLArr;
@property(nonatomic,strong)NSMutableArray *cardIDArr;
@property(nonatomic,strong)NSString *card_id;
@property(nonatomic,assign)BOOL operte;



@end
@implementation CashViewController

-(PayVIew *)payView{
    
    if (!_payView) {
        _payView = [[PayVIew alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT)];
        _payView.delegate = self;
    }
    return _payView;
}
-(void)viewDidLoad{
    
    [super viewDidLoad];
    self.view.backgroundColor = YBackGrayColor;
    [self createUI];
    self.operte = NO;
    [self.navigationController.view addSubview:self.payView];
    self.payView.hidden = YES;
    if([self.title isEqualToString:@"赎回"]){
        [self getAllCard];
    }
    NSString *banks = @"ICBC,CCB,ABC,BOC,COMM,CMB,CEB,GDB,CITIC,CIB,CMBC,HXB,CBHB,BCCB,BOS,CZB,EGBANK,GDB,PSBC,SHRCB,SPDB,SZPAB";
    NSString *cardStr = @"工商银行(ICBC),建设银行(CCB),农业银行(ABC),中国银行(BOC),交通银行(COMM),招商银行(CMB),光大银行(CEB),广发银行(GDB),中信银行(CITIC),兴业银行(CIB),民生银行(CMBC),华夏银行(HXB),渤海银行(CBHB),中国银行(BCCB),上海银行(BOS),浙商银行(CZB),恒丰银行(EGBANK),广发银行(GDB),邮政储蓄(PSBC),上海农商银行(SHRCB),浦东发展(SPDB),平安银行(SZPAB)";
    self.allCardArr = [cardStr componentsSeparatedByString:@","];
    self.allCardNLArr = [banks componentsSeparatedByString:@","];
    
}
-(void)createUI{
    UIView *firstView = [[UIView alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/7, WINSIZEWIDTH, WINSIZEWIDTH/4-WINSIZEWIDTH/30)];
    if ([self.title isEqualToString:@"赎回"]) {
        firstView.y = 0;
    }
    firstView.backgroundColor = [UIColor whiteColor];
    UILabel *moneyLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/8, firstView.height)];
    moneyLal.text = @"金额";
    
    moneyLal.textColor = YBlackColor;
    moneyLal.font = YFont(WINSIZEWIDTH/20);
    
    self.moneyField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(moneyLal.frame)+WINSIZEWIDTH/15, 0, WINSIZEWIDTH/4*3, firstView.height)];
    self.moneyField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    self.moneyField.placeholder = @"请输入要提现的金额";
    self.moneyField.font = moneyLal.font;
    self.moneyField.textColor = YBlackColor;
    //self.moneyField.keyboardType = UIKeyboardTypeNumberPad;
    [firstView addSubview:moneyLal];
    [firstView addSubview:self.moneyField];
    
    UIView *secView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    secView.backgroundColor = [UIColor whiteColor];
    UILabel *redLal = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, WINSIZEWIDTH/8, firstView.height)];
    redLal.text = @"备注";
    self.redeemField = [[UITextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(redLal.frame)+WINSIZEWIDTH/15, 0, WINSIZEWIDTH/2, firstView.height)];
    self.redeemField.placeholder = @"20字以内";
    self.redeemField.font = self.moneyField.font;
    self.redeemField.textColor = YBlackColor;
    [secView addSubview:redLal];
    [secView addSubview:self.redeemField];
    
    UIView *thirView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, firstView.height)];
    thirView.backgroundColor = [UIColor whiteColor];
    UILabel *mothLal = [[UILabel alloc]initWithFrame:CGRectMake(moneyLal.x, 0, WINSIZEWIDTH/5, secView.height)];
    mothLal.textColor = YGrayColor;
    mothLal.text = @"到账银行";
    mothLal.font = moneyLal.font;
    UIButton *countImage = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH-WINSIZEWIDTH/7, 0, WINSIZEWIDTH/8, thirView.height)];
    [countImage addTarget:self action:@selector(choose:) forControlEvents:(UIControlEventTouchUpInside)];
    [countImage setImage:[UIImage imageNamed:@"choose"] forState:(UIControlStateNormal)];
    self.bankName = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(mothLal.frame), 0, WINSIZEWIDTH-CGRectGetMaxX(moneyLal.frame)-WINSIZEWIDTH/8, thirView.height)];
    self.bankName.text = @"请选择到账银行";
    self.bankName.textAlignment = NSTextAlignmentCenter;
    self.bankName.textColor = [UIColor colorWithHexString:@"bcbcbc"];
    self.bankName.font = self.moneyField.font;
    // countImage.backgroundColor = YRedColor;
    [thirView addSubview:mothLal];
    [thirView addSubview:self.bankName];
    [thirView addSubview:countImage];
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, CGRectGetMaxY(thirView.frame), WINSIZEWIDTH/2, 0)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
    [self.tableView setSeparatorInset:(UIEdgeInsetsZero)];
    [self.tableView setLayoutMargins:(UIEdgeInsetsZero)];
    self.tableView.tableFooterView = [[UIView alloc]init];
    UIButton *investBtn = [[UIButton alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/14, CGRectGetMaxY(secView.frame)+WINSIZEWIDTH/10, WINSIZEWIDTH-WINSIZEWIDTH/7, WINSIZEWIDTH/8)];
    investBtn.backgroundColor = YRedColor;
    [investBtn setTitle:@"确认提现" forState:(UIControlStateNormal)];
    if ([self.title isEqualToString:@"赎回"]) {
        [investBtn setTitle:@"确认赎回" forState:(UIControlStateNormal)];
        self.moneyField.placeholder = @"请输入要赎回的金额";
    }
    [investBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [investBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    investBtn.titleLabel.font = YBFont(WINSIZEWIDTH/18);
    [investBtn addTarget:self action:@selector(invest:) forControlEvents:(UIControlEventTouchUpInside)];
    investBtn.layer.cornerRadius = WINSIZEWIDTH/100;
    
    //可提现金额
    self.cashMoney = [[UILabel alloc]init];
    self.cashMoney.frame = CGRectMake(WINSIZEWIDTH/17, WINSIZEWIDTH * 0.045, WINSIZEWIDTH-20, WINSIZEWIDTH/16);
    NSLog(@"%@", [self.count class]);
    NSLog(@"%@", self.count);
    CGFloat a = yTwoPointDouble(self.count);
    
    self.cashMoney.text = [NSString stringWithFormat:@"账户可提现总金额%.2f元",a];
    if ([self.count isEqualToString:@"(null)"]) {
        self.cashMoney.text = @"账户可提现总金额0元";
    }
    self.cashMoney.font = YFont(WINSIZEWIDTH/25);
    self.cashMoney.textColor = YGrayColor;
    self.cashMoney.textAlignment = NSTextAlignmentJustified;
    [self.view addSubview:investBtn];
    [self.view addSubview:firstView];
    if(![self.title isEqualToString:@"赎回"]){
        [self.view addSubview:self.cashMoney];
        investBtn.y = CGRectGetMaxY(firstView.frame)+WINSIZEWIDTH/10;
        //[self.view addSubview:thirView];
        // [self.view addSubview:self.tableView];
    }else{
        [self.view addSubview:secView];
    }
    
}
-(void)viewDidAppear:(BOOL)animated{

    [super viewDidAppear:animated];
    if (self.operte) {
        NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
        NSString *token = [userdefault objectForKey:TOKEN];
        NSString *user_phone = [userdefault objectForKey:USER_PHONE];
        
        //获取我的资金列表
        NSString *param2 = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
        [IKHttpTool postWithURL:@"fetchAssests" params:@{@"json":param2} success:^(id json) {
            
            self.count = [NSString stringWithFormat:@"%@",json[@"data"][@"sina_balance"]];//可用金额
            
            dispatch_async(dispatch_get_main_queue(), ^{
                CGFloat a = yTwoPointFloat(self.count);
                
                self.cashMoney.text = [NSString stringWithFormat:@"账户可提现总金额%.2f元",a];
                if ([self.count isEqualToString:@"(null)"]) {
                    self.cashMoney.text = @"账户可提现总金额0元";
                }
            });
            self.operte = NO;
        } failure:^(NSError *error) {
            
        }];
    }
    
}
#pragma mark --tableviewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.cardData.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return WINSIZEWIDTH/6+WINSIZEWIDTH/100;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *str = self.cardData[indexPath.row];
    NSArray *dataArr = [str componentsSeparatedByString:@"^"];
    NSLog(@"---%@",dataArr);
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        [cell setLayoutMargins:(UIEdgeInsetsZero)];
        [cell setSeparatorInset:(UIEdgeInsetsZero)];
    }
    for (int i = 0; i<self.allCardNLArr.count; i++) {
        if ([dataArr[1] isEqualToString:self.allCardNLArr[i]]) {
            cell.textLabel.text = self.allCardArr[i];
        }
    }
    cell.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
    cell.textLabel.textColor = YBlackColor;
    cell.textLabel.font = YFont(WINSIZEWIDTH/20);
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    self.card_id = self.cardIDArr[indexPath.row];
    NSLog(@"+++%@",self.card_id);
    self.bankName.text = self.allCardArr[indexPath.row];
    self.bankName.textColor = YBlackColor;
    self.tableView.size = CGSizeMake(WINSIZEWIDTH/2, 0);
}
-(void)getAllCard{
    self.cardIDArr = [NSMutableArray array];
    for (int i = 0; i<self.cardData.count; i++) {
        NSString *str = [NSString stringWithFormat:@"%@",self.cardArr[i]];
        NSLog(@"----%@",str);
        NSArray *array = [str componentsSeparatedByString:@"^"];
        NSLog(@"++++%@ --- %@",array,array[0]);
        [self.cardIDArr addObject:array[0]];
    }
    //    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    //    NSString *token = [userdefault objectForKey:TOKEN];
    //    NSString *user_id = [userdefault objectForKey:USER_ID];
    //    NSString *param = [NSString stringWithFormat:@"{\"user_id\":\"%@\",\"token\":\"%@\"}",user_id,token];
    //    [IKHttpTool postWithURL:@"queryBankCard" params:@{@"json":param} success:^(id json) {
    //        NSString *data = [NSString stringWithFormat:@"%@",json[@"data"][@"card_list"]];
    //        self.cardArr = [[data componentsSeparatedByString:@"|"]mutableCopy];
    //        if (self.cardArr.count<1) {
    //            [self.cardArr addObject:data];
    //        }
    //        for (int i = 0; i<self.cardArr.count; i++) {
    //            NSString *str = [NSString stringWithFormat:@"%@",self.cardArr[i]];
    //            NSLog(@"----%@",str);
    //            NSArray *array = [str componentsSeparatedByString:@"^"];
    //            NSLog(@"++++%@ --- %@",array,array[0]);
    //            [self.cardIDArr addObject:array[0]];
    //        }
    //        NSLog(@"--%@--%@",self.cardArr,self.cardIDArr);
    //        [self.tableView reloadData];
    //    } failure:^(NSError *error) {
    //
    //    }];
}
#pragma mark -- target

//选择到账银行
-(void)choose:(UIButton *)sender{
    
    NSLog(@"----------");
    sender.selected = !sender.selected;
    if (sender.selected) {
        [UIView animateWithDuration:0.5 animations:^{
            self.tableView.size = CGSizeMake(WINSIZEWIDTH/2, self.view.height - self.tableView.y);
        }];
    }else{
        [UIView animateWithDuration:0.5 animations:^{
            self.tableView.size = CGSizeMake(WINSIZEWIDTH/2, 0);
        }];
    }
  //  [SLAlertView showAlertWithStatusString:@"xuanChooseCard"];
    //[MBProgressHUD showError:@"xuanChooseCard"];
}
//确认提现 (赎回)
-(void)invest:(UIButton *)sender{
    
    [self.view endEditing:YES];
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
    if ([self.title isEqualToString:@"赎回"]) {
        if (self.moneyField.text.length<1) {
            [SLAlertView showAlertWithStatusString:@"金额不能为空"];
            //  [self.prompt showPromptWithTitle:@"error" message:@"  金额不呢过为空" buttonleft:nil buttonright:nil];
            return;
        } else if(self.redeemField.text.length<1){
//            [SLAlertView showAlertWithStatusString:@"备注信息不能为空"];
            
            //[self.prompt showPromptWithTitle:@"error" message:@" 备注信息不能为空" buttonleft:nil buttonright:nil];
//            return;
            self.redeemField.text = @"20字以内";
        }
        if ([self.moneyField.text floatValue] > [self.capitialMoney floatValue]) {
            [SLAlertView showAlertWithStatusString:@"赎回金额不得大于投资本金!"];
            return ;
        }
        [self.view endEditing:YES];
        //        else if(self.bankName.text.length<1){
        //            [self.prompt showPromptWithTitle:@"error" message:@" 请选择您的到账银行" buttonleft:nil buttonright:nil];
        //            return;
        //        }
//        NSString *uuid = [userdefault objectForKey:@"uuid"];
        NSString *user_phone = [userdefault objectForKey:USER_PHONE];
        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"amount\":\"%@\",\"summary\":\"%@\",\"user_phone\":\"%@\"}",token,self.moneyField.text,self.redeemField.text,user_phone];
        [SLAlertView showAlertWithMessageString:@"请稍候..."];
        [IKHttpTool postWithURL:@"createSingleHostingPayTrade" params:@{@"json":param} success:^(id json) {
            [SLAlertView hide];
            //            [MBProgressHUD hideHUD];
            [SLAlertView showAlertWithStatusString:json[@"msg"]];
            
            
            //赎回成功,跳转到上个页面
            
            [self.navigationController popViewControllerAnimated:YES];
            
            //[self.prompt showPromptWithTitle:@"tishi" message:@"    赎回成功" buttonleft:nil buttonright:nil];
        } failure:^(NSError *error) {
            
        }]; 
    }else{/////////提现
        
        if ([self.moneyField.text doubleValue] > [self.count doubleValue]) {
            [SLAlertView showAlertWithStatusString:@"提现金额不能大于账户可提现金额"];
            return;
        }
        if ([self.moneyField.text doubleValue] < 0.01) {
            [SLAlertView showAlertWithStatusString:@"提现金额过小"];
            return;
        }
        if ([self.moneyField.text doubleValue] < 100) {
            [SLAlertView showAlertWithStatusString:@"提现金额不能小于100"];
            return;
        }
        if ([self.moneyField.text floatValue]>50000) {
            [SLAlertView showAlertWithStatusString:@"当日提现金额不能超过50000"];
            return;
        }
        //判断今天剩余可提现金额
        [SLAlertView showAlertWithMessageString:@"请稍候..."];
        
        NSString *paramStr = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
        [IKHttpTool postWithURL:@"allowTixian" params:@{@"json":paramStr} success:^(id json) {
            [SLAlertView hide];
            if ([json[@"status"] intValue] == 1) {
                NSString *TiXianToDay = [NSString stringWithFormat:@"%@",json[@"data"][@"amount"]];
                NSLog(@"-tixianToday%@-%f",TiXianToDay,[TiXianToDay doubleValue]);
                if ([self.moneyField.text doubleValue] <= 50000 - [TiXianToDay doubleValue]) {
                    // 如果用户填的金额少于 ( 5000 - 今天已提现 ) 金额 提现
                   // NSLog(@"-----json.moneyField.text:%f",[json[@"data"][@"amount"] doubleValue]);
                    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                    // 判断是否设置支付密码
                    [SLAlertView showAlertWithMessageString:@"请稍候..."];
                    
                    [IKHttpTool postWithURL:@"queryIsSetPayPassword" params:@{@"json":str} success:^(id json) {
                        //[SLAlertView hide];
                        //            [MBProgressHUD hideHUD];
                        NSString *status = [NSString stringWithFormat:@"%@",json[@"data"][@"is_set_paypass"]];
                        if ([status isEqualToString:@"Y"]) {
                            NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\",\"amount\":\"%@\"}",user_phone,token,self.moneyField.text];
                            // 提现
                            [SLAlertView showAlertWithMessageString:@"请稍候..."];
                            [IKHttpTool postWithURL:@"createHostingWithdraw" params:@{@"json":param} success:^(id json) {
                                [SLAlertView hide];
                                self.operte = YES;
                                WebViewController *webVC = [[WebViewController alloc]init];
                                webVC.title = @"提现";
                                webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"]];
                                [self.navigationController pushViewController:webVC animated:YES];
                            } failure:^(NSError *error) {
                                
                            }];
                        }else{
                            void(^block)() = ^(){
                            };
                            void(^block2)() = ^(){
                                [SLAlertView showAlertWithMessageString:@"请稍候..."];
                                NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                                NSString *user_id = [userdefault objectForKey:USER_ID];
                                NSString *token = [userdefault objectForKey:TOKEN];
                                NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                                [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                                    [SLAlertView hide];
                                    //        [MBProgressHUD hideHUD];
                                    WebViewController *webVC = [[WebViewController alloc]init];
                                    webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"]];
                                    [self.navigationController pushViewController:webVC animated:YES];
                                } failure:^(NSError *error) {
                                    
                                }];
                            };
                            [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];
                        }
                        
                        return ;
                    } failure:^(NSError *error) {
                        return ;
                    }];
                }else{
                    [SLAlertView showAlertWithStatusString:[NSString stringWithFormat:@"您今天剩余可提现金额为%.2f元",50000 - [TiXianToDay doubleValue]]];
                    return ;
                }
            }
        } failure:^(NSError *error) {
            
        }];
        
        
//        NSString *paramStr = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
//        [IKHttpTool postWithURL:@"allowTixian" params:@{@"json":paramStr} success:^(id json) {
//            if ([json[@"status"] intValue] == 1) {
//
//                NSString *str = [NSString stringWithFormat:@"%@",[json[@"data"] valueForKey:@"amount"]];
//                NSLog(@"%@",str);
//                if ([str isEqualToString:@"<null>"]) {
//                    str = @"0";
//                }
//                
//                if ([self.moneyField.text doubleValue] <= 50000 - [str doubleValue]) {
//                    // 如果用户填的金额少于 ( 5000 - 今天已提现 ) 金额 提现
//                    
//                    
//                }else{
//                    double da = yTwoPointDouble(json[@"data"][@"amount"]);
//                    [SLAlertView showAlertWithStatusString:[NSString stringWithFormat:@"您今天剩余可提现金额为%.2lf 元",50000 - da]];
//                    return ;
//                }
//            }
//        } failure:^(NSError *error) {
//            
//        }];
        
//        NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
//
//        [IKHttpTool postWithURL:@"queryIsSetPayPassword" params:@{@"json":str} success:^(id json) {
//            [SLAlertView hide];
//            //            [MBProgressHUD hideHUD];
//            NSString *status = [NSString stringWithFormat:@"%@",json[@"data"][@"is_set_paypass"]];
//            if ([status isEqualToString:@"Y"]) {
//                NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\",\"amount\":\"%@\"}",user_phone,token,self.moneyField.text];
//                [IKHttpTool postWithURL:@"createHostingWithdraw" params:@{@"json":param} success:^(id json) {
//                    WebViewController *webVC = [[WebViewController alloc]init];
//                    webVC.title = @"提现";
//                    webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"]];
//                    [self.navigationController pushViewController:webVC animated:YES];
//                } failure:^(NSError *error) {
//                    
//                }];
//            }else{
//                void(^block)() = ^(){
//                };
//                void(^block2)() = ^(){
//                    [SLAlertView showAlertWithMessageString:@"请稍候..."];
//                    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
//                    NSString *user_id = [userdefault objectForKey:USER_ID];
//                    NSString *token = [userdefault objectForKey:TOKEN];
//                    NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
//                    [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
//                        [SLAlertView hide];
//                        //        [MBProgressHUD hideHUD];
//                        WebViewController *webVC = [[WebViewController alloc]init];
//                        webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"]];
//                        [self.navigationController pushViewController:webVC animated:YES];
//                    } failure:^(NSError *error) {
//                        
//                    }];
//                };
//                [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];
//            }
//            
//            return ;
//        } failure:^(NSError *error) {
//            return ;
//        }];

        
    }
    //    金额：amount   摘要：summary  标的号：goods_id   收款的卡:card_id
    //    public function createSingleHostingPayToCardTrade()
    //    self.payView.hidden = NO;
    //    [self.payView createUI:@"请输入支付密码"];
    
}
-(void)payViewDelegateButton:(NSInteger)buttonIndex textFields:(NSString *)text{
    
    NSLog(@"-----text:%@",text);
    self.payView.hidden = YES;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
}

@end
