//
//  ReplacePayKeyVC.m
//  ERenYiPu
//
//  Created by babbage on 15/11/16.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "ReplacePayKeyVC.h"
#import "RememberPayKeyVC.h"
#import "ForgetPayKeyVC.h"
#import "SLAlertView.h"
@interface ReplacePayKeyVC ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,assign)BOOL status;
@end

@implementation ReplacePayKeyVC

-(UITableView *)tableView{

    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH)];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [[UIView alloc]init];
        [_tableView setLayoutMargins:(UIEdgeInsetsZero)];
        [_tableView setSeparatorInset:(UIEdgeInsetsZero)];
        _tableView.bounces = NO;
        _tableView.backgroundColor = YBackGrayColor;
        
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"重置支付密码";
    self.view.backgroundColor = YBackGrayColor;
    [self.view addSubview:self.tableView];
    self.status = YES;
//    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
//    NSString *user_id = [userdefault objectForKey:USER_ID];
//    NSString *token = [userdefault objectForKey:TOKEN];
//    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
//    NSString *str = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
//    [IKHttpTool postWithURL:@"queryIsSetPayPassword" params:@{@"json":str} success:^(id json) {
//        NSString *status = [NSString stringWithFormat:@"%@",json[@"data"][@"is_set_paypass"]];
//        if ([status isEqualToString:@"Y"]) {
//            self.status = YES;
//        }else{
//            [SLAlertView showAlertWithStatusString:@"请先设置支付密码"];
//            //[self.prompt makePromptWithTitle:@"提示" message:@"请先设置支付密码" buttonleft:@"取消" buttonright:@"去设置"];
//        }
//    } failure:^(NSError *error) {
//    }];
    // Do any additional setup after loading the view.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return WINSIZEWIDTH/7;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:nil];;
    if (indexPath.row==0) {
        cell.textLabel.text = @"我记得原支付密码";
    }else if(indexPath.row == 1){
    
        cell.textLabel.text = @"我忘记支付密码了";
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.textColor = YBlackColor;
    cell.textLabel.font = YFont(WINSIZEWIDTH/20);
    [cell setLayoutMargins:(UIEdgeInsetsZero)];
    [cell setSeparatorInset:(UIEdgeInsetsZero)];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (!self.status) {
 
        void(^block)() = ^(){
        };
        void(^block2)() = ^(){
            [SLAlertView showAlertWithMessageString:@"请稍候..."];
            // [MBProgressHUD showMessage:@"请稍后"];
            NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
            NSString *user_id = [userdefault objectForKey:USER_ID];
            NSString *user_phone = [userdefault objectForKey:USER_PHONE];
            NSString *token = [userdefault objectForKey:TOKEN];
            NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
            [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                [SLAlertView hide];
                //        [MBProgressHUD hideHUD];
                WebViewController *webVC = [[WebViewController alloc]init];
                webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                [self.navigationController pushViewController:webVC animated:YES];
            } failure:^(NSError *error) {
                
            }];
        };
        [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];

        return;
    }
    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *user_id = [userdefault objectForKey:USER_ID];
    NSString *token = [userdefault objectForKey:TOKEN];
    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
       if (indexPath.row==0) {
        
        //[self.navigationController pushViewController:[[RememberPayKeyVC alloc]init] animated:YES];
           [SLAlertView showAlertWithMessageString:@"请稍候..."];
        NSString *param = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
        [IKHttpTool postWithURL:@"modifyPaypassword" params:@{@"json":param} success:^(id json) {
            if(![json[@"status"] intValue]==0){
                WebViewController *webVC = [[WebViewController alloc]init];
                webVC.title = @"重置支付密码";
                webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                [self.navigationController pushViewController:webVC animated:YES];
            }else{
                NSLog(@"status == 0");
                void(^block)() = ^(){
                };
                void(^block2)() = ^(){
                    [SLAlertView showAlertWithMessageString:@"请稍候..."];
                    // [MBProgressHUD showMessage:@"请稍后"];
                    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                    NSString *user_id = [userdefault objectForKey:USER_ID];
                    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
                    NSString *token = [userdefault objectForKey:TOKEN];
                    NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                    [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                        [SLAlertView hide];
                        //        [MBProgressHUD hideHUD];
                        WebViewController *webVC = [[WebViewController alloc]init];
                        webVC.title = @"设置支付密码";
                        webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                        [self.navigationController pushViewController:webVC animated:YES];
                    } failure:^(NSError *error) {
                        
                    }];
                };
                [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];
            }
           
        } failure:^(NSError *error) {
           // [SLAlertView showAlertWithStatusString:@"如果您没有设置过支付密码请进入充值界面设置"];

        }];
    }else if(indexPath.row == 1){
        [SLAlertView showAlertWithMessageString:@"请稍候..."];

        NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",token,user_phone];
        [IKHttpTool postWithURL:@"findPaypassword" params:@{@"json":param} success:^(id json) {
            if (![json[@"status"] intValue]==0) {
                WebViewController *webVC = [[WebViewController alloc]init];
                webVC.title = @"找回支付密码";
                webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                [self.navigationController pushViewController:webVC animated:YES];
            }else{
               // [SLAlertView showAlertWithStatusString:@"如果您没有设置过支付密码请进入充值界面设置"];
                void(^block)() = ^(){
                };
                void(^block2)() = ^(){
                    [SLAlertView showAlertWithMessageString:@"请稍候..."];
                    // [MBProgressHUD showMessage:@"请稍后"];
                    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                    NSString *user_id = [userdefault objectForKey:USER_ID];
                    NSString *user_phone = [userdefault objectForKey:USER_PHONE];
                    NSString *token = [userdefault objectForKey:TOKEN];
                    NSString *parame = [NSString stringWithFormat:@"{\"user_phone\":\"%@\",\"token\":\"%@\"}",user_phone,token];
                    [IKHttpTool postWithURL:@"setPaypassword" params:@{@"json":parame} success:^(id json) {
                        [SLAlertView hide];
                        //        [MBProgressHUD hideHUD];
                        WebViewController *webVC = [[WebViewController alloc]init];
                        webVC.title = @"设置支付密码";
                        webVC.webStr = [NSString stringWithFormat:@"%@",json[@"data"][@"redirect_url"]];
                        [self.navigationController pushViewController:webVC animated:YES];
                    } failure:^(NSError *error) {
                        
                    }];
                };
                
                [SLAlertView showAlertWithStatusString:@"请先设置支付密码" withButtonTitles:@[@"取消",@"去设置"] andBlocks:@[block,block2]];
                NSLog(@"---状态为0");
            }
            
        } failure:^(NSError *error) {
            
        }];
        //[self.navigationController pushViewController:[[ForgetPayKeyVC alloc]init] animated:YES];
    }
}
-(void)actionWithButtonIndex:(NSInteger)buIndex{

    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
