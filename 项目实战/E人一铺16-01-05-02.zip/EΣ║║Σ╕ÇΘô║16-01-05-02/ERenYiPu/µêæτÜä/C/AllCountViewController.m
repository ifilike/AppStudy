//
//  AllCountViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "AllCountViewController.h"
#import "DrawView.h"
#import "CashViewController.h"
@interface AllCountViewController ()

{
    CGFloat _maxMoney;
    CGFloat _minMoney;
    
    NSString *_beginDate;
    NSString *_endDate;
    
    UIView *secondView;
}

@property(nonatomic,strong)DrawView *drawView;

@end

@implementation AllCountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    self.title = @"总资产";
    [self createUI];

    [self getTouZiShouYiData];
   // self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"提现" style:(UIBarButtonItemStyleDone) target:self action:@selector(tixian:)];
}
-(void)createUI{

    UIView *first = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/7)];
    first.backgroundColor = [UIColor whiteColor];
    UILabel *allCount = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, 0, first.width-first.x, first.height)];
    double allc = yTwoPointDouble(self.allCount);
    NSLog(@"%lf ---------- %@",allc,self.allCount);
    allCount.text = [NSString stringWithFormat:@"账户总资产：%.2lf元",allc];
    
    allCount.textColor = YGrayColor;
    allCount.font = YFont(WINSIZEWIDTH/20);
    //allCount.backgroundColor = YGrayColor;
    [first addSubview:allCount];
    
    secondView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(first.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, first.height)];
    secondView.backgroundColor = [UIColor whiteColor];
    UILabel *allPrift = [[UILabel alloc]initWithFrame:CGRectMake(allCount.x, 0, allCount.width, secondView.height)];
    allPrift.textColor = YGrayColor;
    allPrift.font = allCount.font;
    double allp = yTwoPointDouble(self.allProfit);
    allPrift.text = [NSString stringWithFormat:@"可用余额：%.2lf",allp];
    
    [secondView addSubview:allPrift];
    
    //画图
    self.drawView = [[DrawView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH-WINSIZEWIDTH/10)];
    self.drawView.backgroundColor = [UIColor whiteColor];

    [self.view addSubview:secondView];
    [self.view addSubview:first];
    [self.view addSubview:self.drawView];
}

- (void)getTouZiShouYiData
{
    _maxMoney = 0;
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *userPhone = [[NSUserDefaults standardUserDefaults]objectForKey:USER_PHONE];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
    [IKHttpTool postWithURL:@"requestAcitveInvest" params:@{@"json":param} success:^(id json) {
        NSArray *arr = json[@"data"];
        if (arr.count > 0) {
            CGFloat money;
            NSMutableArray *lineArr = [NSMutableArray array];
            NSMutableArray *dateArr = [NSMutableArray array];
            
            [dateArr addObject:[[arr objectAtIndex:0][@"profit_time"] substringWithRange:NSMakeRange(5, 5)]];
            if (arr.count > 1) {
                [dateArr addObject:[[arr objectAtIndex:arr.count - 1][@"profit_time"] substringWithRange:NSMakeRange(5, 5)]];
            }
            
            for (NSDictionary *dic in arr) {
                
                money = [dic[@"profit_money"] floatValue];
                
                _maxMoney = _maxMoney > money ? _maxMoney : money;
                
                [lineArr addObject:[NSNumber numberWithFloat:money]];
            }
            
            self.drawView = [[DrawView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH-WINSIZEWIDTH/10)];
            self.drawView.backgroundColor = [UIColor whiteColor];
            self.drawView.maxPrice = _maxMoney;
            self.drawView.lineArr = lineArr;
            self.drawView.dateArr = dateArr;
            [self.view addSubview:self.drawView];
        }else{
            self.drawView = [[DrawView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH-WINSIZEWIDTH/10)];
            self.drawView.backgroundColor = [UIColor whiteColor];
            self.drawView.maxPrice = 0;
            self.drawView.lineArr = @[];
            self.drawView.dateArr = @[@"0",@"0"];
            [self.view addSubview:self.drawView];
        }
        
        
    } failure:^(NSError *error) {
        
    }];
}

//- (void)getTouZiShouYiData
//{
//    _maxMoney = 0;
//    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
//    NSString *userPhone = [[NSUserDefaults standardUserDefaults]objectForKey:USER_PHONE];
//    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"user_phone\":\"%@\"}",tokoen,userPhone];
//    [IKHttpTool postWithURL:@"requestAcitveInvest" params:@{@"json":param} success:^(id json) {
//        NSArray *arr = json[@"data"];
//        CGFloat money;
//        NSMutableArray *lineArr = [NSMutableArray array];
//        NSMutableArray *dateArr = [NSMutableArray array];
//        
//        [dateArr addObject:[[arr objectAtIndex:0][@"profit_time"] substringWithRange:NSMakeRange(5, 5)]];
//        [dateArr addObject:[[arr objectAtIndex:arr.count - 1][@"profit_time"] substringWithRange:NSMakeRange(5, 5)]];
//        
//        for (NSDictionary *dic in arr) {
//            money = [dic[@"profit_money"] floatValue];
//            
//            _maxMoney = _maxMoney > money ? _maxMoney : money;
//            
//            [lineArr addObject:[NSNumber numberWithFloat:money]];
//        }
//        
//        self.drawView = [[DrawView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(secondView.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH, WINSIZEWIDTH-WINSIZEWIDTH/10)];
//        self.drawView.backgroundColor = [UIColor whiteColor];
//        self.drawView.maxPrice = _maxMoney;
//        self.drawView.lineArr = lineArr;
//        self.drawView.dateArr = dateArr;
//        [self.view addSubview:self.drawView];
//        
//    } failure:^(NSError *error) {
//        
//    }];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
