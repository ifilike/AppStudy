//
//  TradeNotesCell.h
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TradeNotesCell : UITableViewCell
@property(nonatomic,strong)UIImageView *tradeImage;
@property(nonatomic,strong)UILabel *forwde;//日期
@property(nonatomic,strong)UILabel *operate;
@property(nonatomic,strong)UILabel *money;
@property(nonatomic,strong)UILabel *operateDate;
@property(nonatomic,strong)UILabel *date;
@property(nonatomic,strong)UIImageView *firstImage;//第一个圆球
-(void)setdata:(NSDictionary *)dic;
@end
 