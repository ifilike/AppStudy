//
//  YDReemTableViewCell.m
//  ERenYiPu
//
//  Created by babbage on 15/12/24.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "YDReemTableViewCell.h"

@implementation YDReemTableViewCell
//-(instancetype)initWithFrame:(CGRect)frame{
//
//    self = [super initWithFrame:frame];
//    if (self) {
//        [self createUI];
//    }
//    return self;
//}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    //蒲宝宝第几期
    self.severa = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH/4, WINSIZEWIDTH/6)];
   self.severa.textAlignment = NSTextAlignmentCenter;
    self.severa.textColor = YGrayColor;
    self.severa.font = YFont(WINSIZEWIDTH/23);
    self.severa.numberOfLines = 2;
    self.severa.text = @"蒲宝宝01期";
    //起头时间
    self.date = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/4, 0, WINSIZEWIDTH/4, self.severa.height)];
    self.date.textAlignment = NSTextAlignmentCenter;
    self.date.textColor = YGrayColor;
    self.date.font = self.severa.font;
    self.date.text = @"-----";
    //交易金额
    self.tradLa = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/2, 0, WINSIZEWIDTH/4, self.severa.height)];
    self.tradLa.textAlignment = NSTextAlignmentCenter;
    self.tradLa.textColor = YGrayColor;
    self.tradLa.font = self.severa.font;
    self.tradLa.text = @"0元";
    //所得利息
    self.interest = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/4*3, 0, WINSIZEWIDTH/4, self.tradLa.height)];
    self.interest.textAlignment = NSTextAlignmentCenter;
    self.interest.textColor = YGrayColor;
    self.interest.font = self.severa.font;
    self.interest.text = @"0元";
    [self.contentView addSubview:self.severa];
    [self.contentView addSubview:self.date];
    [self.contentView addSubview:self.tradLa];
    [self.contentView addSubview:self.interest];


}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
