//
//  YDReemTableViewCell.h
//  ERenYiPu
//
//  Created by babbage on 15/12/24.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YDReemTableViewCell : UITableViewCell
@property(nonatomic,strong)UILabel *severa;
@property(nonatomic,strong)UILabel *date;
@property(nonatomic,strong)UILabel *tradLa;
@property(nonatomic,strong)UILabel *interest;
@end
