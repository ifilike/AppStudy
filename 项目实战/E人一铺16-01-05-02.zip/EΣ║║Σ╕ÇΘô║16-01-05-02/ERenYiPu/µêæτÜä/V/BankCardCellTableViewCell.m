//
//  BankCardCellTableViewCell.m
//  ERenYiPu
//
//  Created by babbage on 15/12/1.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "BankCardCellTableViewCell.h"

@implementation BankCardCellTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    //银行卡标识
    self.imageSym = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/20, WINSIZEWIDTH/10, WINSIZEWIDTH/10)];
    self.imageSym.image = [UIImage imageNamed:@"headimage"];
    self.imageSym.layer.cornerRadius = self.imageSym.height/2;
    self.imageSym.layer.masksToBounds = YES;
    //银行卡名字
    self.cardName = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.imageSym.frame)+WINSIZEWIDTH/30, WINSIZEWIDTH/20, WINSIZEWIDTH/2, WINSIZEWIDTH/20)];
    self.cardName.text = @"北京农商银行";
    self.cardName.textColor = [UIColor whiteColor];
    self.cardName.font = YFont(WINSIZEWIDTH/22);
    self.cardType = [[UILabel alloc]initWithFrame:CGRectMake(self.cardName.x, CGRectGetMaxY(self.cardName.frame)+WINSIZEWIDTH/80, WINSIZEWIDTH/2, WINSIZEWIDTH/27)];
    self.cardType.text = @"储蓄卡";
    self.cardType.font = YFont(WINSIZEWIDTH/30);
    self.cardType.textColor = [UIColor whiteColor];
    //银行卡尾号
    self.cardNum = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.cardType.frame)+WINSIZEWIDTH/50, WINSIZEWIDTH-WINSIZEWIDTH/9.5, WINSIZEWIDTH/12)];
    self.cardNum.text = @"**** **** **** 5179";
    self.cardNum.textColor = [UIColor whiteColor];
    self.cardNum.font = YFont(WINSIZEWIDTH/13);
    self.cardNum.textAlignment = NSTextAlignmentRight;
    
    self.backView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/60, WINSIZEWIDTH/100, WINSIZEWIDTH-WINSIZEWIDTH/30, WINSIZEWIDTH/3.5)];
    self.backView.backgroundColor = YRedColor;
    self.backView.layer.cornerRadius = WINSIZEWIDTH/60;
    [self.backView addSubview:self.imageSym];
    [self.backView addSubview:self.cardName];
    [self.backView addSubview:self.cardType];
    [self.backView addSubview:self.cardNum];
   
    self.backgroundColor = [UIColor clearColor];
    [self addSubview:self.backView];
}
-(void)setdata:(NSArray *)dataArr{

    
}
- (void)awakeFromNib {
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
