//
//  BeInvitedFriendsTableViewCell.m
//  ERenYiPu
//
//  Created by mac on 15/12/21.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "BeInvitedFriendsTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation BeInvitedFriendsTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}

- (void)createUI
{
    [self.contentView addSubview:self.headImageView];
    [self.contentView addSubview:self.dataLabel];
    [self.contentView addSubview:self.nameLabel];
    [self.contentView addSubview:self.phoneLabel];
    [self.contentView addSubview:self.lingquImageView];
    [self.contentView addSubview:self.lingquLabel];
    
    
#warning 测试数据
//    _dataLabel.text = @"2015-02-19 19:10";
//    _nameLabel.text = @"张****";
//    _phoneLabel.text = @"150****2938";
}

//设置数据
- (void)setDate:(NSDictionary *)dic
{
    //头像
    NSString *dicStr = [NSString stringWithFormat:@"%@",dic[@"user_pic"]];
    if (dicStr.length > 10 || ![dicStr isEqualToString:@"<null>"]) {
        NSString *urlString = [NSString stringWithFormat:@"%@%@",@"http://115.28.143.129/EREP/upload/hends/", dic[@"user_pic"]];
        [self.headImageView sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:[UIImage imageNamed:@"touxiang"]];
    }
    _dataLabel.text = [NSString stringWithFormat:@"%@",[[dic valueForKey:@"reg_time"] substringToIndex:16]];
    NSString *nameStr = dic[@"user_name"];
    _nameLabel.text = [dic[@"user_name"] stringByReplacingCharactersInRange:NSMakeRange(1, nameStr.length - 1) withString:@"**"];
    _phoneLabel.text = [dic[@"user_phone"] stringByReplacingCharactersInRange:NSMakeRange(3, 4) withString:@"****"];
    
    NSString *isDistributionStr = [NSString stringWithFormat:@"%@",dic[@"is_distribution"]];
    if ([isDistributionStr isEqualToString:@"0"]) {
        _lingquImageView.image = [UIImage imageNamed:@"geiqian_no"];
        _lingquLabel.textColor = YGrayColor;
        _lingquLabel.text = @"未领取";
    }else if ([isDistributionStr isEqualToString:@"1"]){
        _lingquImageView.image = [UIImage imageNamed:@"geiqian"];
        _lingquLabel.textColor = YRedColor;
        _lingquLabel.text = @"已领取";
    }
    
}

#pragma mark - 懒加载
- (UIImageView *)headImageView
{
    if (_headImageView == nil) {
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 40, 40)];
        _headImageView.layer.cornerRadius = 20;
        _headImageView.backgroundColor = [UIColor grayColor];
        
    }
    return _headImageView;
}

- (UILabel *)dataLabel
{
    if (_dataLabel == nil) {
        _dataLabel = [[UILabel alloc ]initWithFrame:CGRectMake(CGRectGetMaxX(_headImageView.frame) + 10, 8, 200, 20)];
        _dataLabel.font = YFont(16);
        _dataLabel.textColor = [UIColor grayColor];
        
    }
    return _dataLabel;
}

- (UILabel *)nameLabel
{
    if (_nameLabel == nil) {
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMinX(_dataLabel.frame), 32, 50, 20)];
        _nameLabel.font = YFont(16);
        _nameLabel.textColor = [UIColor blackColor];
        
    }
    return _nameLabel;
}

- (UILabel *)phoneLabel
{
    if (_phoneLabel == nil) {
        _phoneLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_nameLabel.frame) + 3, CGRectGetMinY(_nameLabel.frame), 150, 20)];
        _phoneLabel.font = YFont(16);
        _phoneLabel.textColor = [UIColor blackColor];
        
    }
    return _phoneLabel;
}

- (UIImageView *)lingquImageView
{
    if (_lingquImageView == nil) {
        _lingquImageView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH - 90, 18, 24, 24)];
        _lingquImageView.layer.cornerRadius = 12;
        _lingquImageView.backgroundColor = [UIColor grayColor];
        
    }
    return _lingquImageView;
}

- (UILabel *)lingquLabel
{
    if (_lingquLabel == nil) {
        _lingquLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_lingquImageView.frame) + 2, CGRectGetMinY(_lingquImageView.frame) + 2, 60, 20)];
        _lingquLabel.font = YFont(16);
        
    }
    return _lingquLabel;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
