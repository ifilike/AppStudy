//
//  TradeNotesCell.m
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "TradeNotesCell.h"

@implementation TradeNotesCell

- (void)awakeFromNib {
    // Initialization code
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    UIImageView *backView = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/9, WINSIZEWIDTH/2.7)];
    backView.image = [UIImage imageNamed:@"jiaoyiback"];
    //第几期
    self.forwde = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/5, WINSIZEWIDTH/15, backView.width/2, 0)];
    self.forwde.text = @"101502期";
    self.forwde.textColor = YGrayColor;
    self.forwde.font = YBFont(WINSIZEWIDTH/20);
    self.forwde.textAlignment = NSTextAlignmentCenter;
    //存入金额
    self.operate = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/10, CGRectGetMaxY(self.forwde.frame), WINSIZEWIDTH/3, WINSIZEWIDTH/8)];
    self.operate.textColor = YGrayColor;
    self.operate.font = YFont(WINSIZEWIDTH/22);
    self.operate.text = @"存入金额";
    self.operate.numberOfLines = 2;
    self.money = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.operate.frame)+10, self.operate.y, WINSIZEWIDTH/2.5, self.operate.height)];
    self.money.text = @"0元";
    self.money.textColor = YGrayColor;
    self.money.font =self.operate.font;
    self.money.textAlignment = NSTextAlignmentCenter;
    //存入时间
    self.operateDate = [[UILabel alloc]initWithFrame:CGRectMake(self.operate.x, CGRectGetMaxY(self.operate.frame), self.operate.width, self.operate.height)];
    self.operateDate.textColor = self.operate.textColor;
    self.operateDate.font = self.operate.font;
    self.operateDate.text = @"交易时间";
    self.date = [[UILabel alloc]initWithFrame:CGRectMake(self.money.x, self.operateDate.y, self.money.width, self.money.height)];
    self.date.textColor = YGrayColor;
    self.date.font = self.money.font;
    self.date.text = @"2015-03-23";
    //[backView addSubview:self.forwde];
    [backView addSubview:self.operate];
    [backView addSubview:self.money];
    [backView addSubview:self.operateDate];
    [backView addSubview:self.date];
    
    UIView *verView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/15, 0, 2, WINSIZEWIDTH/2)];
    verView.backgroundColor = [UIColor colorWithHexString:@"fda090"];
    self.tradeImage = [[UIImageView alloc]initWithFrame:CGRectMake(verView.x-WINSIZEWIDTH/48+1, WINSIZEWIDTH/9.1, WINSIZEWIDTH/24, WINSIZEWIDTH/24)];
    self.tradeImage.image = [UIImage imageNamed:@"jiaoyi1"];
    self.firstImage = [[UIImageView alloc]initWithFrame:CGRectMake(verView.x-WINSIZEWIDTH/80+1, 0, WINSIZEWIDTH/40, WINSIZEWIDTH/40)];
    self.firstImage.image = [UIImage imageNamed:@"jiaoyi"];
    
    [self addSubview:backView];
    [self addSubview:verView];
    [self addSubview:self.firstImage];
    [self addSubview:self.tradeImage];
}
-(void)setdata:(NSDictionary *)dic{

    self.forwde.text = [NSString stringWithFormat:@"%@",dic[@"finsh_time"]];
    self.operate.numberOfLines = 2;
    NSString *type = [NSString stringWithFormat:@"%@",dic[@"outer_trade_type"]];
    //self.operate.text = [NSString stringWithFormat:@"%@",dic[0]];
    switch ([type intValue]) {
        case 1:
            self.operate.text  =@"充值";
            break;
           case 2:
            self.operate.text = @"提现";
            break;
            case 3:
            self.operate.text = @"赎回";

            break;
            case 4:
            self.operate.text = @"投资";

            break;
        default:
            self.operate.text = @"交易金额";
            break;
    }
    self.money.text = [NSString stringWithFormat:@"%.2f元",floorf([dic[@"amount"] floatValue]*100)/100 ];
    NSString *date = [NSString stringWithFormat:@"%@",dic[@"create_time"]];
    NSString *dataStr = [date substringToIndex:16];
    self.date.text = [NSString stringWithFormat:@"%@",dataStr];
  //  self.date.text = [NSString stringWithFormat:@"%@",[date substringWithRange:NSMakeRange(0, 4)],[date substringWithRange:NSMakeRange(4, 2)],[date substringWithRange:NSMakeRange(6, 2)]];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
