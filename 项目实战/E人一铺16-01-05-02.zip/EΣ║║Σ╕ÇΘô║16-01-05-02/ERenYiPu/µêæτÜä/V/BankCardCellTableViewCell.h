//
//  BankCardCellTableViewCell.h
//  ERenYiPu
//
//  Created by babbage on 15/12/1.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BankCardCellTableViewCell : UITableViewCell
@property(nonatomic,strong)UIImageView *imageSym;
@property(nonatomic,strong)NSString *cardSym;//银行卡标识
@property(nonatomic,strong)UILabel *cardType;//银行卡类型
@property(nonatomic,strong)UILabel *cardName;
@property(nonatomic,strong)UILabel *cardNum;//银行卡号
@property(nonatomic,strong)UIView *backView;//背景
-(void)setdata:(NSArray *)dataArr;
@end
