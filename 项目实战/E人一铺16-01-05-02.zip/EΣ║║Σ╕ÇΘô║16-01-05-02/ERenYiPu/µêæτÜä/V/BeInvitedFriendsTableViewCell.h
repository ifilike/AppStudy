//
//  BeInvitedFriendsTableViewCell.h
//  ERenYiPu
//
//  Created by mac on 15/12/21.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeInvitedFriendsTableViewCell : UITableViewCell

@property (nonatomic,strong)UIImageView *headImageView;
@property (nonatomic,strong)UILabel *dataLabel;
@property (nonatomic,strong)UILabel *nameLabel;
@property (nonatomic,strong)UILabel *phoneLabel;

@property (nonatomic,strong)UIImageView *lingquImageView;
@property (nonatomic,strong)UILabel *lingquLabel;

- (void)setDate:(NSDictionary *)dic;

@end
