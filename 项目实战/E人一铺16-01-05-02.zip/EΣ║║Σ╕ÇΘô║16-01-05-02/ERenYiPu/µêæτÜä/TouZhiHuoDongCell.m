//
//  TouZhiHuoDongCell.m
//  ZSY
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "TouZhiHuoDongCell.h"

@implementation TouZhiHuoDongCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
