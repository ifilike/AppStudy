//
//  ZSYTableHeaderView.m
//  ZSY
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import "ZSYTableHeaderView.h"

@implementation ZSYTableHeaderView


- (IBAction)detailButtonClick:(UIButton *)sender {
    sender.selected = !sender.selected;
    UITableView *tableView = (UITableView *)self.nextResponder;
    [tableView reloadSections:[NSIndexSet indexSetWithIndex:sender.tag - 7777] withRowAnimation:UITableViewRowAnimationNone];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self detailButtonClick:self.detailButton];
}

@end
