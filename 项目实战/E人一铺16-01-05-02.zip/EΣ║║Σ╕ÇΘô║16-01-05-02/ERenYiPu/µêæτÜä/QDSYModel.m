//
//  QDSYModel.m
//  ERenYiPu
//
//  Created by mac on 15/12/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "QDSYModel.h"

@implementation QDSYModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    [super setValue:value forUndefinedKey:key];
}

@end
