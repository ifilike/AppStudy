//
//  ZSYHeaderView.h
//  ZSY
//
//  Created by mac on 15/12/2.
//  Copyright © 2015年 sl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZSYHeaderView : UIView

@property (weak, nonatomic) IBOutlet UILabel *moneyLabel;

@end
