//
//  UIBarButtonItem+CG.h
//  ChaoGu
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 潘俊霞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (CG)
+ (instancetype)itemWithImage:(NSString *)image highImage:(NSString *)highImage target:(id)target action:(SEL)action;

@end
