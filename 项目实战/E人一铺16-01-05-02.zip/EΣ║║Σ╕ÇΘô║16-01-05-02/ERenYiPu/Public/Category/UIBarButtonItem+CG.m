//
//  UIBarButtonItem+CG.m
//  ChaoGu
//
//  Created by mac on 15/7/13.
//  Copyright (c) 2015年 潘俊霞. All rights reserved.
//

#import "UIBarButtonItem+CG.h"

@implementation UIBarButtonItem (CG)
+ (instancetype)itemWithImage:(NSString *)image highImage:(NSString *)highImage target:(id)target action:(SEL)action
{
    UIButton *btn = [[UIButton alloc] init];
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:highImage] forState:UIControlStateHighlighted];
    
    btn.size = btn.currentBackgroundImage.size;
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}


@end
