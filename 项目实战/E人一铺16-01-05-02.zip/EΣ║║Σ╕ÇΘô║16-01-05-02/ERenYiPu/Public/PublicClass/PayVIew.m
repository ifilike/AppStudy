//
//  PayVIew.m
//  ERenYiPu
//
//  Created by babbage on 15/11/16.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "PayVIew.h"

@interface PayVIew()<UITextFieldDelegate>

@end
@implementation PayVIew
-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithHexString:@"2c2c2c" alpha:0.5];
    }
    return self;
}
-(void)createUI:(NSString *)symbolTitle{

    self.symbol = symbolTitle;
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/3, WINSIZEWIDTH-WINSIZEWIDTH/10, WINSIZEWIDTH/2)];
    view.backgroundColor = [UIColor whiteColor];
    view.layer.cornerRadius = WINSIZEHEIGHT/80;
    UILabel *symbol = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, view.width, WINSIZEWIDTH/6)];
    symbol.text = symbolTitle;
    symbol.font = YFont(WINSIZEWIDTH/18);
    symbol.textAlignment = NSTextAlignmentCenter;
    symbol.textColor = YGrayColor;
    
    UIView *payView = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/30, CGRectGetMaxY(symbol.frame), view.width - WINSIZEWIDTH/15, WINSIZEWIDTH/8)];
    payView.backgroundColor = [UIColor whiteColor];
    payView.layer.cornerRadius = WINSIZEWIDTH/80;
    payView.layer.borderColor = [UIColor colorWithHexString:@"bcbcbc"].CGColor;
    payView.layer.borderWidth = 1.0f;
    payView.layer.masksToBounds = YES;
    for (int i = 0; i<6; i++) {
        UITextField *payTextField = [[UITextField alloc]initWithFrame:CGRectMake(payView.width/6*i, 0, payView.width/6, payView.height)];
        payTextField.tag = 100000+i;
        payTextField.font = YFont(WINSIZEWIDTH/20);
        payTextField.textAlignment = NSTextAlignmentCenter;
        payTextField.secureTextEntry = YES;
        payTextField.delegate = self;
        UIView *verView = [[UIView alloc]initWithFrame:CGRectMake(payView.width/6*(i+1), 0, 1, payView.height)];
        verView.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
        [payView addSubview:payTextField];
       // payTextField.keyboardType = UIKeyboardTypeNumberPad;
        if (i!=5) {
            [payView addSubview:verView];
        }
    }
    //取消按钮
    UIButton *cacleBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, view.height-WINSIZEWIDTH/7, view.width/2, WINSIZEWIDTH/7)];
    cacleBtn.tag = 10000;
    [cacleBtn setTitle:@"取消" forState:(UIControlStateNormal)];
    [cacleBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [cacleBtn setTitleColor:YBackGrayColor forState:(UIControlStateHighlighted)];
    [cacleBtn addTarget:self action:@selector(cancle:) forControlEvents:(UIControlEventTouchUpInside)];
    
    //确定按钮
    UIButton *OKBtn = [[UIButton alloc]initWithFrame:CGRectMake(view.width/2, cacleBtn.y, cacleBtn.width, cacleBtn.height)];
    [OKBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [OKBtn setTitleColor:YBackGrayColor forState:(UIControlStateHighlighted)];
    [OKBtn setTitle:@"确定" forState:(UIControlStateNormal)];
    OKBtn.tag = 10001;
    [OKBtn addTarget:self action:@selector(OKBtn:) forControlEvents:(UIControlEventTouchUpInside)];
    //横线
    UIView *verView = [[UIView alloc]initWithFrame:CGRectMake(0, OKBtn.y, view.width, 1)];
    verView.backgroundColor = [UIColor colorWithHexString:@"bcbcbc"];
    //竖线
    UIView *horView = [[UIView alloc]initWithFrame:CGRectMake(OKBtn.x-0.5, OKBtn.y, 1.0f, OKBtn.height)];
    horView.backgroundColor = verView.backgroundColor;
    
    [view addSubview:symbol];
    [view addSubview:payView];
    [view addSubview:cacleBtn];
    [view addSubview:OKBtn];
    [view addSubview:verView];
    [view addSubview:horView];
    [self addSubview:view];
}
#pragma mark -- tatget
-(void)cancle:(UIButton *)sender{

    NSLog(@"取消了");
    [self endEditing:YES];
    self.hidden = YES;
}
-(void)OKBtn:(UIButton *)sender{

    [self endEditing:YES];
    NSLog(@"------确定");
    if ([self.delegate respondsToSelector:@selector(payViewDelegateButton:textFields:)]) {
        [self.delegate payViewDelegateButton:sender.tag textFields:[self textFieldtexts]];
    }
}
//textFieldelegate
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if ([string isEqualToString:@"\n"])  //按会车可以改变
    {
        return YES;
    }
    if (textField.text.length>0) {
        textField.text = [textField.text substringToIndex:0];
        return YES;
    }
    return YES;
}
-(NSString *)textFieldtexts{
    
    NSString *str = [NSString new];
    for (int i = 0; i<6; i++) {
        UITextField *field = (UITextField *)[self viewWithTag:100000+i];
        str = [str stringByAppendingString:field.text];
    }
    NSLog(@"-----str:%@",str);
    return str;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self endEditing:YES];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
