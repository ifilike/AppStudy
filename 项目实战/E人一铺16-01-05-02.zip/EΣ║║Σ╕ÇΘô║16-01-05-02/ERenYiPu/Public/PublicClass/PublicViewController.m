//
//  PublicViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "PublicViewController.h"
#import "SLAlertView.h"
#import "TTTAttributedLabel.h"
#import "LogInViewController.h"
#import "RegisViewController.h"
@interface PublicViewController ()<UMSocialUIDelegate>
@property (strong, nonatomic) UIScrollView *sv;
@property (strong, nonatomic) UIButton *shareBtn;
@property (strong, nonatomic) UIButton *rightBtn;

@end

@implementation PublicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = self.pageTitle;
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    [self createUI];
}
-(void)createUI{

    NSLog(@"%@", self.idName);
    NSLog(@"%@", self.pageTitle);
    NSLog(@"%@", self.contentText);
    NSLog(@"%@", self.contentTitleText);
    NSLog(@"%@", self.contentId);
    
    UIScrollView *sv = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    self.sv = sv;
    [self.view addSubview:sv];
    
    // titleLabel
    self.titleLabel = [[UILabel alloc] init];
    [sv addSubview:self.titleLabel];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = YGrayColor;
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.font = YBFont(WINSIZEWIDTH/20);
    self.titleLabel.text = self.pageTitle;

    // textLabel
    self.contentTextLabel = [[TTTAttributedLabel alloc] init];
    [self.view addSubview:self.contentTextLabel];
    [sv addSubview:self.contentTextLabel];
    self.contentTextLabel.textColor = [UIColor colorWithHexString:@"8c8c8c"];
    self.contentTextLabel.textAlignment = NSTextAlignmentNatural;
    self.contentTextLabel.font = YFont(WINSIZEWIDTH/23);
    self.contentTextLabel.numberOfLines = 0;
    self.contentTextLabel.lineSpacing = 5;
    self.contentTextLabel.text = self.contentText;
    
    
    UIButton *rightBtn = [UIButton buttonWithType:(UIButtonTypeDetailDisclosure)];
    self.rightBtn = rightBtn;
    [sv addSubview:rightBtn];
    [rightBtn setImage:[UIImage imageNamed:@"dianzan"] forState:(UIControlStateNormal)];
    rightBtn.hidden = 0;
    [rightBtn setTitle:@"  点赞" forState:(UIControlStateNormal)];
    rightBtn.hidden = true;
    [rightBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [rightBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    rightBtn.titleLabel.font = YBFont(WINSIZEWIDTH/15);
    [rightBtn setTintColor:YGrayColor];
    //[rightBtn addTarget:self action:@selector(right:) forControlEvents:(UIControlEventTouchUpInside)];
    //    rightBtn.frame = CGRectMake(self.content.x, view.height-WINSIZEWIDTH/8, view.width/4, WINSIZEWIDTH/9);
    
    
    UIButton *shareBtn = [UIButton buttonWithType:(UIButtonTypeDetailDisclosure)];
    
//#warning 修改
//    shareBtn.backgroundColor = [UIColor redColor];
//    self.contentTextLabel.backgroundColor = [UIColor blueColor];
    
    self.shareBtn = shareBtn;
    [sv addSubview:shareBtn];
    [shareBtn setImage:[UIImage imageNamed:@"fenxiang"] forState:(UIControlStateNormal)];
    [shareBtn setTitle:@"  分享" forState:(UIControlStateNormal)];
    [shareBtn setTitleColor:YGrayColor forState:(UIControlStateNormal)];
    [shareBtn setTitleColor:YGrayColor forState:(UIControlStateHighlighted)];
    shareBtn.titleLabel.font = shareBtn.titleLabel.font;
    [shareBtn setTintColor:YGrayColor];
    [shareBtn addTarget:self action:@selector(share:) forControlEvents:(UIControlEventTouchUpInside)];
    //    shareBtn.frame = CGRectMake(view.width-rightBtn.width-rightBtn.x, rightBtn.y, rightBtn.width, rightBtn.height);

    
    self.titleLabel.translatesAutoresizingMaskIntoConstraints = false;
    self.contentTextLabel.translatesAutoresizingMaskIntoConstraints = false;
    rightBtn.translatesAutoresizingMaskIntoConstraints = false;
    shareBtn.translatesAutoresizingMaskIntoConstraints = false;
    sv.translatesAutoresizingMaskIntoConstraints = false;
    
    NSMutableArray *constraints = [NSMutableArray array];
    NSDictionary *metrics = @{@"btnHeight" : @(WINSIZEWIDTH/9),
                              @"titleEdgeMargin" : @(WINSIZEHEIGHT/15),
                              @"edgeMargin" : @(WINSIZEWIDTH/30),
                              @"btnWidth" : @(WINSIZEWIDTH/4),
                              @"btnHeight" : @(WINSIZEWIDTH/9),
                              };
    
    NSDictionary *subviews = @{
                               @"title" : self.titleLabel,
                               @"content" : self.contentTextLabel,
                               @"rightBtn" : rightBtn,
                               @"share" : shareBtn
                               };
    
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[sv]-0-|" options:0 metrics:nil views:@{@"sv":sv}]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[sv]-0-|" options:0 metrics:nil views:@{@"sv":sv}]];

    [constraints addObject:[NSLayoutConstraint constraintWithItem:sv attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:self.view.bounds.size.width]];
    
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-20-[title]-20-[content]" options:0 metrics:metrics views:subviews]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-titleEdgeMargin-[title]-titleEdgeMargin-|" options:0 metrics:metrics views:subviews]];
    [constraints addObjectsFromArray:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-edgeMargin-[content]-edgeMargin-|" options:0 metrics:metrics views:subviews]];
    
    [constraints addObject:[NSLayoutConstraint constraintWithItem:self.contentTextLabel attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:self.view.bounds.size.width - WINSIZEWIDTH/15]];

    
    [constraints addObject:[NSLayoutConstraint constraintWithItem:rightBtn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:WINSIZEWIDTH/4]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:rightBtn attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:WINSIZEWIDTH/9]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:rightBtn attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:sv attribute:NSLayoutAttributeLeading multiplier:1.0 constant:WINSIZEWIDTH/30]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:rightBtn attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentTextLabel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:30]];
    
    
    [constraints addObject:[NSLayoutConstraint constraintWithItem:shareBtn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:WINSIZEWIDTH/4]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:shareBtn attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:WINSIZEWIDTH/9]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:shareBtn attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:sv attribute:NSLayoutAttributeTrailing multiplier:1.0 constant:-WINSIZEWIDTH/30]];
    [constraints addObject:[NSLayoutConstraint constraintWithItem:shareBtn attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.contentTextLabel attribute:NSLayoutAttributeBottom multiplier:1.0 constant:30]];

    
    [self.view addConstraints:constraints];
    

}


- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    self.sv.contentSize = CGSizeMake(self.sv.bounds.size.width, self.shareBtn.frame.origin.y + WINSIZEHEIGHT/6);
}


//点赞
-(void)right:(UIButton *)sender{

    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *user_phone = [userDefault objectForKey:USER_PHONE];
    NSString *user_id = [userDefault objectForKey:USER_ID];
    
    NSString *token = [userDefault objectForKey:TOKEN];
    if ([user_id intValue]<5) {
        [SLAlertView showAlertWithRegisterWithRegisterBlock:^{
            [UIApplication sharedApplication].keyWindow.rootViewController = [RegisViewController new];
        } LoginBlock:^{
            [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];;
        }];
    }else{
        NSString *contentId = [userDefault objectForKey:user_id];

    if ([contentId isEqualToString:self.contentId]) {
        [SLAlertView showAlertWithStatusString:@"您已经赞过了"];
      //  [MBProgressHUD showError:@"您已经赞过了"];
        return;
    }
    [SLAlertView showAlertWithStatusString:@"dianzan"];
   // [MBProgressHUD showError:@"dianzan"];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\",\"%@\":\"%@\"}",token,self.idName,self.contentId];
    [IKHttpTool postWithURL:@"giveASupport" params:@{@"json":param} success:^(id json) {
        NSLog(@"---json%@",json);
        [userDefault setObject:self.contentId forKey:user_id];
        [SLAlertView showAlertWithStatusString:@"点赞成功"];
      //  [MBProgressHUD showSuccess:@"点赞成功"];
    } failure:^(NSError *error) {
        
    }];
    }
}
//分享
-(void)share:(UIButton *)sender{

    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
    NSString *token = [userdefault objectForKey:TOKEN];
    if (token.length<10) {
        [SLAlertView showAlertWithRegisterWithRegisterBlock:^{
            [UIApplication sharedApplication].keyWindow.rootViewController = [RegisViewController new];
        } LoginBlock:^{
            [UIApplication sharedApplication].keyWindow.rootViewController = [LogInViewController new];;
        }];
    }else{
    //[SLAlertView showAlertWithStatusString:@"分享"];
    [UMSocialSnsService presentSnsIconSheetView:self
                                appKey:@"5652bc2567e58e75e0003108"
                                      shareText:self.pageTitle
                                     shareImage:[UIImage imageNamed:@"邀请.jpg"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToQQ,UMShareToQzone,UMShareToSms,UMShareToEmail,UMShareToWechatSession,UMShareToWechatTimeline,nil]
                                       delegate:self];
    }
   // [MBProgressHUD showError:@"fenxiang"];
}


@end
