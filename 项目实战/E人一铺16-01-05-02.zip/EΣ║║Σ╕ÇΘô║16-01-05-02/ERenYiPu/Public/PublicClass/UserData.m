//
//  UserData.m
//  ERenYiPu
//
//  Created by mac on 15/12/27.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "UserData.h"



@implementation UserData

@synthesize newsArr = _newsArr;
@synthesize arrat = _arrat;
@synthesize products = _products;
@synthesize investProfit = _investProfit;
@synthesize markProfit = _markProfit;
@synthesize activeProfit = _activeProfit;

+ (instancetype)sharedUserData {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (void)setNewsArr:(NSArray *)newsArr {
    _newsArr = newsArr;
    if (newsArr) {
        // 本地存储
        NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
        [defaults setObject:newsArr forKey:@"newsArrData"];
        if ([defaults synchronize]) {
            NSLog(@"newsArr本地持久化成功");
        } else {
            NSLog(@"newsArr本地持久化失败");
        }
    } else {
        NSLog(@"newsArr为空");
    }
}

- (void)setArrat:(NSArray *)arrat {
    _arrat = arrat;
    if (arrat) {
        // 本地存储
        NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
        [defaults setObject:arrat forKey:@"arratData"];
        if ([defaults synchronize]) {
            NSLog(@"arrat本地持久化成功");
        } else {
            NSLog(@"arrat本地持久化失败");
        }
    } else {
        NSLog(@"arrat为空");
    }
}

- (void)refreshProducts {
    NSString *tokoen = [[NSUserDefaults standardUserDefaults]objectForKey:TOKEN];
    NSString *param = [NSString stringWithFormat:@"{\"token\":\"%@\"}",tokoen];
    [IKHttpTool postWithURL:@"showProduct" params:@{@"json":param} success:^(id json) {
        NSLog(@"一日加载userdata请求往期产品数据");

        NSMutableArray *productsArray = [NSMutableArray array];
        NSDictionary *productDic = [NSDictionary dictionary];
        NSArray *array = json[@"data"];
        for (NSDictionary *dic in array) {
            if ([dic[@"product_status"]isEqualToString:@"1"]) {
                productDic = dic;
            }else{
                [productsArray addObject:dic];
            }
        }
        self.products = productsArray.copy;
     } failure:^(NSError *error) {
     }];
}

- (void)setProducts:(NSArray *)products {
    _products = products;
    if (products) {
        // 本地存储
        NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
        [defaults setObject:products forKey:@"productsData"];
        if ([defaults synchronize]) {
            NSLog(@"products本地持久化成功");
        } else {
            NSLog(@"products本地持久化失败");
        }
    } else {
        NSLog(@"products为空");
    }
}

// 设置投资收益
- (void)setInvestProfit:(NSArray *)investProfit {
    _investProfit = investProfit;
    if (investProfit) {
        // 本地存储
        NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
        [defaults setObject:investProfit forKey:@"investProfitsData"];
        if ([defaults synchronize]) {
            NSLog(@"investProfits本地持久化成功");
        } else {
            NSLog(@"investProfits本地持久化失败");
        }
    } else {
        NSLog(@"investProfits为空");
    }
}

- (NSArray *)investProfit {
    NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
    NSArray *array = [defaults objectForKey:@"investProfitsData"];
    if (array) {
        return array;
    } else {
        NSLog(@"investProfitsData本地获取失败");
        return nil;
    }
}

// 签到收益表
- (void)setMarkProfit:(NSArray *)markProfit {
    _markProfit = markProfit;
    if (markProfit) {
        // 本地存储
        NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
        [defaults setObject:markProfit forKey:@"markProfitsData"];
        if ([defaults synchronize]) {
            NSLog(@"markProfits本地持久化成功");
        } else {
            NSLog(@"markProfits本地持久化失败");
        }
    } else {
        NSLog(@"markProfits为空");
    }
}

- (NSArray *)markProfit {
    NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
    NSArray *array = [defaults objectForKey:@"markProfitsData"];
    if (array) {
        return array;
    } else {
        NSLog(@"markProfits本地获取失败");
        return nil;
    }
}

// 活动收益表
- (void)setActiveProfit:(NSArray *)activeProfit {
    _activeProfit = activeProfit;
    if (activeProfit) {
        // 本地存储
        NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
        [defaults setObject:activeProfit forKey:@"activeProfitsData"];
        if ([defaults synchronize]) {
            NSLog(@"activeProfits本地持久化成功");
        } else {
            NSLog(@"activeProfits本地持久化失败");
        }
    } else {
        NSLog(@"activeProfits为空");
    }
}

- (NSArray *)activeProfit {
    NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
    NSArray *array = [defaults objectForKey:@"activeProfitsData"];
    if (array) {
        return array;
    } else {
        NSLog(@"activeProfits本地获取失败");
        return nil;
    }
}

- (NSArray *)newsArr {
    NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
    NSArray *array = [defaults objectForKey:@"newsArrData"];
    if (array) {
        return array;
    } else {
        NSLog(@"newsArrData本地获取失败");
        return nil;
    }
}

- (NSArray *)arrat {
    NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
    NSArray *array = [defaults objectForKey:@"arratData"];
    if (array) {
        return array;
    } else {
        NSLog(@"arratData本地获取失败");
        return nil;
    }
}

- (NSArray *)products {
    NSUserDefaults *defaults = [[NSUserDefaults alloc] init];
    NSArray *array = [defaults objectForKey:@"productsData"];
    if (array) {
        return array;
    } else {
        NSLog(@"productsData本地获取失败");
        return nil;
    }
}

@end
