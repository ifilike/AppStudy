//
//  EMenuView.m
//  ERenYiPu
//
//  Created by babbage on 15/11/6.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "EMenuView.h"

@implementation EMenuView

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}
-(NSMutableArray *)menuArr{
    
    if (!_menuArr) {
        _menuArr = [NSMutableArray array];
    }
    return _menuArr;
}
-(void)creatUI:(NSMutableArray *)array{
    
    self.menuArr = array;
    NSLog(@"----------%@",self.menuArr);
    for (int i=0; i<self.menuArr.count; i++) {
        UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(i*WINSIZEWIDTH/self.menuArr.count,0 , WINSIZEWIDTH/self.menuArr.count, self.height-1)];
        button.tag = 10000+i;
        [button setTitle:self.menuArr[i] forState:(UIControlStateNormal)];
        [button setTitleColor:YBlackColor forState:(UIControlStateNormal)];
        [button setTitleColor:YRedColor forState:(UIControlStateSelected)];
        [button setTitleColor:[UIColor blueColor] forState:(UIControlStateHighlighted)];
        button.titleLabel.font = self.menuFont>10? [UIFont boldSystemFontOfSize:self.menuFont]:[UIFont systemFontOfSize:WINSIZEWIDTH/20];
        [button addTarget:self action:@selector(btnChange:) forControlEvents:(UIControlEventTouchUpInside)];
        [self addSubview:button];
        if (i==0) {
            button.selected = YES;
        }
        UIView *redView = [[UIView alloc]initWithFrame:CGRectMake(button.x, CGRectGetMaxY(button.frame)-2, button.width, 2)];
        redView.backgroundColor = [UIColor clearColor];
        redView.tag = button.tag*10;
        if (redView.tag == 100000) {
            redView.backgroundColor = YRedColor;
        }
        [self addSubview:redView];   
        //NSLog(@"+++++++++");
    }
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, self.height-1, self.width, 1)];
    view.backgroundColor = [UIColor grayColor];
    //[self addSubview:view];
    self.backgroundColor = [UIColor whiteColor];
}
-(void)changeStatus:(NSInteger)sender{
    
    for (int i =10000; i<self.menuArr.count+10000; i++) {
        UIView *view = (UIView *)[self viewWithTag:i*10];
        view.backgroundColor = [UIColor clearColor];
        UIButton *button = (UIButton *)[self viewWithTag:i];
        button.selected = NO;
       // NSLog(@"-------%@",view);
    }
    
    UIButton *button = (UIButton *)[self viewWithTag:sender];
    button.selected = YES;
    [UIView animateWithDuration:1.0 animations:^{
        
        UIView *view = [self viewWithTag:sender*10];
        view.backgroundColor = YRedColor;
        
    }];
   
}
-(void)btnChange:(UIButton *)sender{
    
    for (int i =10000; i<10000+self.menuArr.count; i++) {
        UIView *view = (UIView *)[self viewWithTag:i*10];
        view.backgroundColor = [UIColor clearColor];
        UIButton *button = (UIButton *)[self viewWithTag:i];
        button.selected = NO;
       // NSLog(@"-------%@",view);
    }
    sender.selected = YES;
    
    UIView *view = (UIView *)[self viewWithTag:sender.tag*10];
    view.backgroundColor = YRedColor;
    if ([self.delegate respondsToSelector:@selector(changeMenuStatus:)]) {
        [self.delegate changeMenuStatus:sender.tag];
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
