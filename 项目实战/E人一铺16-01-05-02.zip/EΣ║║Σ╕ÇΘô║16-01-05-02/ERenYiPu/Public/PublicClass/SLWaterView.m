//
//  SLWaterView.m
//  WaterView
//
//  Created by mac on 15/11/13.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import "SLWaterView.h"

@interface SLWaterView ()

@property (strong, nonatomic) WaterView * waterView;

@end

@implementation SLWaterView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self != nil) {
        float leng = (int)self.frame.size.width > (int)self.frame.size.height ? self.frame.size.height : self.frame.size.width;
        self.frame = CGRectMake(frame.origin.x, frame.origin.y, leng, leng);
        self.waterView = [[WaterView alloc] initWithFrame:self.bounds];
        [self addSubview:self.waterView];
        self.layer.cornerRadius = self.frame.size.width/2;
        self.layer.masksToBounds = true;
    }
    return self;
}


- (void)setWaterPercent:(float)waterPercent {
    NSAssert(waterPercent <= 1, @"\n\nClass\t: %@\n_cmd\t\t: %@\nself\t\t: %@\nError\t: \"waterPercent 这里需要 <= 1\"\n", self.class, NSStringFromSelector(_cmd), self);
    _waterPercent = waterPercent;
    self.waterView.currentLinePointY = waterPercent;
}

@end

@interface WaterView ()

{
    UIColor *_currentWaterColor;
    float b;
    BOOL jia;
}

@property (assign, nonatomic) float newLine;
@property (assign, nonatomic) float a;
@property (strong, nonatomic) NSTimer * timer;


@end

@implementation WaterView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self setBackgroundColor:[UIColor colorWithHexString:@"e0dfdf"]];
        
        _a = 0;
        b = 0;
        jia = NO;
        
        _currentWaterColor = YRedColor;
        _currentLinePointY = frame.size.width/2;
        
        [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
        
    }
    return self;
}

- (NSTimer *)timer {
    if (_timer == nil) {
        _timer = [NSTimer timerWithTimeInterval:0.02 target:self selector:@selector(animateWave) userInfo:nil repeats:true];
    }
    return _timer;
}

- (void)setCurrentLinePointY:(float)currentLinePointY {
    NSLog(@"%f", currentLinePointY);
    _currentLinePointY = (1 - currentLinePointY) * self.frame.size.height;
    if (currentLinePointY > 0.999999 ) {
        _a = 0;
        _currentLinePointY = (1 - currentLinePointY) * self.frame.size.height - 50;

    } else if (currentLinePointY > 0.98) {
        _a = 0.1;
    } else if (currentLinePointY > 0.95) {
        _a = 0.2;
    } else if (currentLinePointY > 0.9) {
        _a = 1.0;
    } else if (currentLinePointY > 0.8){
        _a = 1.5;
    } else {
        _a = 2.0;
    }
}



-(void)animateWave
{
    if (jia) {
        _a += 0.01;
    }else{
        _a -= 0.01;
    }
    
    
    if (_a<=1) {
        jia = YES;
    }
    
    if (_a>=1.5) {
        jia = NO;
    }
    
    
    b+=0.1;
    
    [self setNeedsDisplay];
}



- (void)drawRect:(CGRect)rect

{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGMutablePathRef path = CGPathCreateMutable();
    
    //画水
    CGContextSetLineWidth(context, 1);
    CGContextSetFillColorWithColor(context, [_currentWaterColor CGColor]);
    
    float y=_currentLinePointY;
    CGPathMoveToPoint(path, NULL, 0, y);
    for(float x=0;x<= ((int)rect.size.width);x++){
        y= _a * sin( x/180*M_PI + 4*b/M_PI ) * 5 + _currentLinePointY;
        CGPathAddLineToPoint(path, nil, x, y);
    }
    
    CGPathAddLineToPoint(path, nil, rect.size.width, rect.size.height);
    CGPathAddLineToPoint(path, nil, 0, rect.size.height);
    CGPathAddLineToPoint(path, nil, 0, _currentLinePointY);
    
    CGContextAddPath(context, path);
    CGContextFillPath(context);
    CGContextDrawPath(context, kCGPathStroke);
    CGPathRelease(path);
    
}

@end