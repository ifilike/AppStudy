//
//  SLAlertButton.h
//  SLAlertView
//
//  Created by SL🐰鱼子酱 on 15/12/3.
//  Copyright © 2015年 SL🐰鱼子酱. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLAlertButton : UIButton

@property (strong, nonatomic) void(^handle)();

@end
