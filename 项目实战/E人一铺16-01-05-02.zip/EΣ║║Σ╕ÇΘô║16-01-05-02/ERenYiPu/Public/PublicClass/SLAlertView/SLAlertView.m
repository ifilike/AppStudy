//
//  SLAlertView.m
//  SLAlertView
//
//  Created by SL🐰鱼子酱 on 15/12/3.
//  Copyright © 2015年 SL🐰鱼子酱. All rights reserved.
//

#import "SLAlertView.h"
#import "AlertWindow.h"
#import "SLAlertButton.h"

@interface SLAlertView ()

@property (strong, nonatomic) AlertWindow *alertWindow;
@property (strong, nonatomic) UIWindow *keyWindow;
@property (assign, nonatomic) NSTimeInterval keepTime;
@property (strong, nonatomic) UILabel *alertLabel;
@property (strong, nonatomic) UIColor *color;

@end

@implementation SLAlertView

+ (instancetype)sharedSLAlertView {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    if (self = [super init]) {
        self.keepTime = 2;
    }
    return self;
}

+ (void)showAlertWithView:(UIView *)view {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithView:view];
}

- (void)showAlertWithView:(UIView *)view {
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    view.frame = CGRectMake(0, 0, 240, 100);
    [self.alertWindow.mainView addSubview:view];
    [bgView addSubview:self.alertWindow];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.alertWindow = nil;
        [bgView removeFromSuperview];
    });
}

+ (void)showAlertWithView:(UIView *)view withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithView:view withButtonTitles:titlesString andBlocks:blocks];
}

- (void)showAlertWithView:(UIView *)view withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks {
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    view.frame = CGRectMake(0, 0, 240, 100);
    [self.alertWindow.mainView addSubview:view];
    [bgView addSubview:self.alertWindow];
    if (titlesString.count > 0) {
        self.alertWindow.buttonView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        CGFloat btnWidth = (240.0 - 1 * (titlesString.count - 1)) /titlesString.count;
        for (NSInteger i = 0; i < titlesString.count; i++) {
            SLAlertButton *btn = [[SLAlertButton alloc] init];
            [btn setTitle:titlesString[i] forState:UIControlStateNormal];
            [self.alertWindow.buttonView addSubview:btn];
            btn.handle = blocks[i];
            btn.frame = CGRectMake(i * btnWidth + i * 1, 1, btnWidth, 39);
        }
    }
    
}


+ (void)showAlertWithRegisterWithRegisterBlock:(void(^)())registerBlock LoginBlock:(void(^)())loginBlock {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithRegisterWithRegisterBlock:registerBlock LoginBlock:loginBlock];
}

- (void)showAlertWithRegisterWithRegisterBlock:(void(^)())registerBlock LoginBlock:(void(^)())loginBlock {
    
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    NSArray *titlesString = @[@"注册", @"登录"];
    if (registerBlock && loginBlock) {
        
        NSArray *blocks = @[registerBlock, loginBlock];
        self.alertLabel.text = @"对不起, 您还未登录账号";
        [self.alertWindow addSubview:self.alertLabel];
        [bgView addSubview:self.alertWindow];
        
        self.alertWindow.buttonView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        CGFloat btnWidth = (240.0 - 1 * (titlesString.count - 1)) /titlesString.count;
        for (NSInteger i = 0; i < titlesString.count; i++) {
            SLAlertButton *btn = [[SLAlertButton alloc] init];
            [btn setTitle:titlesString[i] forState:UIControlStateNormal];
            [self.alertWindow.buttonView addSubview:btn];
            btn.handle = blocks[i];
            btn.frame = CGRectMake(i * btnWidth + i * 1, 1, btnWidth, 39);
        }
        
        UIButton *closeButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
        [bgView addSubview:closeButton];
        closeButton.center = CGPointMake(self.alertWindow.frame.origin.x + self.alertWindow.bounds.size.width, self.alertWindow.frame.origin.y);
        [closeButton setImage:[UIImage imageNamed:@"close"] forState:UIControlStateNormal];
        [closeButton addTarget:self action:@selector(closeButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    } else {
        NSAssert(0, @"\n\nClass\t: %@\n_cmd\t\t: %@\nself\t\t: %@\nError\t: \"register login block 未设置\"\n", self.class, NSStringFromSelector(_cmd), self);
    }
}

- (void)closeButtonClick:(UIButton *)sender {
    [sender.superview removeFromSuperview];
}

+ (void)showAlertWithMessageString:(NSString *)string {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithMessageString:string];
}

- (void)showAlertWithMessageString:(NSString *)string {
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    self.alertLabel.text = string;
    [self.alertWindow addSubview:self.alertLabel];
    [bgView addSubview:self.alertWindow];
    
    
}

+ (void)hide {
    [[SLAlertView sharedSLAlertView].alertWindow.superview removeFromSuperview];
    [SLAlertView sharedSLAlertView].alertWindow = nil;
}



+ (void)showAlertWithStatusString:(NSString *)string {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithStatusString:string];
}

- (void)showAlertWithStatusString:(NSString *)string {
    
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    self.alertLabel.text = string;
    [self.alertWindow addSubview:self.alertLabel];
    [bgView addSubview:self.alertWindow];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.alertWindow = nil;
        [bgView removeFromSuperview];
    });
}


+ (void)showAlertWithStatusString:(NSString *)string withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithStatusString:string withButtonTitles:titlesString andBlocks:blocks];
}

- (void)showAlertWithStatusString:(NSString *)string withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks {
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    UILabel *label = [[UILabel alloc] init];
    label.text = string;
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentCenter;
    label.frame = CGRectMake(20, 40, 200, 100);
    [self.alertWindow addSubview:label];
    [bgView addSubview:self.alertWindow];    if (titlesString.count > 0) {
        self.alertWindow.buttonView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        CGFloat btnWidth = (240.0 - 1 * (titlesString.count - 1)) /titlesString.count;
        for (NSInteger i = 0; i < titlesString.count; i++) {
            SLAlertButton *btn = [[SLAlertButton alloc] init];
            [btn setTitle:titlesString[i] forState:UIControlStateNormal];
            [self.alertWindow.buttonView addSubview:btn];
            btn.handle = blocks[i];
            btn.frame = CGRectMake(i * btnWidth + i * 1, 1, btnWidth, 39);
        }
    }
}


+ (void)showAlertWithImage:(UIImage *)image {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithImage:image];
}


- (void)showAlertWithImage:(UIImage *)image {
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    UIImageView *imgv = [[UIImageView alloc] init];
    imgv.image = image;
    imgv.frame = CGRectMake(0, 0, 240, 100);
    [self.alertWindow.mainView addSubview:imgv];
    [bgView addSubview:self.alertWindow];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.alertWindow = nil;
        [bgView removeFromSuperview];
    });
}

+ (void)showAlertWithImage:(UIImage *)image withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks {
    [SLAlertView hide];
    [[SLAlertView sharedSLAlertView] showAlertWithImage:image withButtonTitles:titlesString andBlocks:blocks];
}

- (void)showAlertWithImage:(UIImage *)image withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks {
    UIView *bgView = [[UIView alloc] initWithFrame:self.keyWindow.bounds];

    bgView.backgroundColor = self.color;
    [self.keyWindow addSubview:bgView];
    
    self.alertWindow.bounds = CGRectMake(0, 0, 240, 180);
    self.alertWindow.center = bgView.center;
    
    UIImageView *imgv = [[UIImageView alloc] init];
    imgv.image = image;
    imgv.frame = CGRectMake(0, 0, 240, 100);
    [self.alertWindow.mainView addSubview:imgv];
    [bgView addSubview:self.alertWindow];    if (titlesString.count > 0) {
        self.alertWindow.buttonView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        CGFloat btnWidth = (240.0 - 1 * (titlesString.count - 1)) /titlesString.count;
        for (NSInteger i = 0; i < titlesString.count; i++) {
            SLAlertButton *btn = [[SLAlertButton alloc] init];
            [btn setTitle:titlesString[i] forState:UIControlStateNormal];
            [self.alertWindow.buttonView addSubview:btn];
            btn.handle = blocks[i];
            btn.frame = CGRectMake(i * btnWidth + i * 1, 1, btnWidth, 39);
        }
    }
}

#pragma mark - 增加buttons

- (AlertWindow *)alertWindow {
    if (_alertWindow == nil) {
        _alertWindow = [[NSBundle mainBundle] loadNibNamed:@"AlertWindow" owner:nil options:nil].lastObject;
    }
    return _alertWindow;
}

- (UIWindow *)keyWindow {
    if (_keyWindow == nil) {
        _keyWindow = [UIApplication sharedApplication].keyWindow;
    }
    return _keyWindow;
}

- (UILabel *)alertLabel {
    if (_alertLabel == nil) {
        _alertLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, 200, 100)];
        _alertLabel.font = [UIFont systemFontOfSize:15];
        _alertLabel.textColor = YGrayColor;
        _alertLabel.numberOfLines = 0;
        _alertLabel.textAlignment = NSTextAlignmentCenter;
        
    }
    return _alertLabel;
}

- (UIColor *)color {
    if (_color == nil) {
        _color = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
    }
    return _color;
}

@end
