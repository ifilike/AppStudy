//
//  SLAlertView.h
//  SLAlertView
//
//  Created by SL🐰鱼子酱 on 15/12/3.
//  Copyright © 2015年 SL🐰鱼子酱. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SLAlertView : NSObject

+ (instancetype)sharedSLAlertView;

+ (void)showAlertWithView:(UIView *)view;
+ (void)showAlertWithView:(UIView *)view withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks;
+ (void)showAlertWithStatusString:(NSString *)string;
+ (void)showAlertWithMessageString:(NSString *)string;
+ (void)hide;
+ (void)showAlertWithStatusString:(NSString *)string withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks;
+ (void)showAlertWithImage:(UIImage *)image;
+ (void)showAlertWithImage:(UIImage *)image withButtonTitles:(NSArray *)titlesString andBlocks:(NSArray *)blocks;

+ (void)showAlertWithRegisterWithRegisterBlock:(void(^)())registerBlock LoginBlock:(void(^)())loginBlock;

@end
