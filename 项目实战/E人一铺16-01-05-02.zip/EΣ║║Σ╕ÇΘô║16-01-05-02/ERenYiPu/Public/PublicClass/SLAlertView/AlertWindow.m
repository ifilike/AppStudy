//
//  AlertWindow.m
//  SLAlertView
//
//  Created by SL🐰鱼子酱 on 15/12/3.
//  Copyright © 2015年 SL🐰鱼子酱. All rights reserved.
//

#import "AlertWindow.h"

@implementation AlertWindow



- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:CGSizeMake(5, 5)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    maskLayer.path = maskPath.CGPath;
    self.layer.mask = maskLayer;
}
//-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//
//    UIResponder *responder = self.nextResponder;
//    UIView *view = (UIView *)responder;
//    [view removeFromSuperview];
//    view = nil;
//}


@end
