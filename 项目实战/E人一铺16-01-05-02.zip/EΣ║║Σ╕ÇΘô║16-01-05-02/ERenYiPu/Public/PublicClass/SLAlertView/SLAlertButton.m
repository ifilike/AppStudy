//
//  SLAlertButton.m
//  SLAlertView
//
//  Created by SL🐰鱼子酱 on 15/12/3.
//  Copyright © 2015年 SL🐰鱼子酱. All rights reserved.
//

#import "SLAlertButton.h"

@implementation SLAlertButton

- (instancetype)init {
    if (self = [super init]) {
        [self addTarget:self action:@selector(doHandler) forControlEvents:UIControlEventTouchUpInside];
        self.backgroundColor = [UIColor whiteColor];
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    }
    return self;
}

- (void)doHandler {
    if (self.handle) {
        self.handle();
        UIResponder *responder = self.nextResponder.nextResponder.nextResponder;
        UIView *bgView = (UIView *)responder;
        [bgView removeFromSuperview];
    }
}

@end
