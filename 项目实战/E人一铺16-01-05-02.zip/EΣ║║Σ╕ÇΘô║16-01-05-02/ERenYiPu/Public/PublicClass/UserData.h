//
//  UserData.h
//  ERenYiPu
//
//  Created by mac on 15/12/27.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserData : NSObject

+ (instancetype)sharedUserData;

// 最新消息
@property (strong, nonatomic) NSArray *newsArr;
// 安全保障
@property (strong, nonatomic) NSArray *arrat;
// 查看往期
@property (strong, nonatomic) NSArray *products;
// 投资收益表
@property (strong, nonatomic) NSArray *investProfit;
// 签到收益表
@property (strong, nonatomic) NSArray *markProfit;
// 活动收益表
@property (strong, nonatomic) NSArray *activeProfit;

- (void)refreshProducts;

@end
