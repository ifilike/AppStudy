//
//  EMenuView.h
//  ERenYiPu
//
//  Created by babbage on 15/11/6.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>


@class EMenuView;
@protocol EMenuViewDelegate <NSObject>
-(void)changeMenuStatus:(NSInteger)tag;

@end
@interface EMenuView : UIView
@property(nonatomic,strong)NSMutableArray *menuArr;
@property(nonatomic,assign)CGFloat menuFont;
-(void)creatUI:(NSMutableArray *)array;
@property(nonatomic,assign)id<EMenuViewDelegate>delegate;
-(void)changeStatus:(NSInteger)sender;
@end

