//
//  PublicViewController.h
//  ERenYiPu
//
//  Created by babbage on 15/11/10.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TTTAttributedLabel;
@interface PublicViewController : UIViewController
@property(nonatomic,strong)NSString *idName;
@property(nonatomic,strong)NSString *pageTitle;

@property(nonatomic,strong)NSString *contentText;
@property(nonatomic,strong)NSString *contentTitleText;

@property(nonatomic,strong)UILabel *titleLabel;
@property(nonatomic,strong)TTTAttributedLabel *contentTextLabel;

@property(nonatomic,strong)NSString *contentId;
@end
