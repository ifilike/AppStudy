//
//  PayVIew.h
//  ERenYiPu
//
//  Created by babbage on 15/11/16.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PayVIew;
@protocol PayVIeWDelegate <NSObject>

-(void)payViewDelegateButton:(NSInteger)buttonIndex textFields:(NSString*)text;

@end

@interface PayVIew : UIView
@property(nonatomic,strong)NSString *symbol;
@property(nonatomic,assign)id<PayVIeWDelegate>delegate;
-(void)createUI:(NSString *)symbolTitle;
@end
