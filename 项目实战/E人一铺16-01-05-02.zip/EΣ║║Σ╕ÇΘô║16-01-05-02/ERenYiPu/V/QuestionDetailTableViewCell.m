//
//  QuestionDetailTableViewCell.m
//  ERenYiPu
//
//  Created by mac on 15/12/21.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "QuestionDetailTableViewCell.h"

@implementation QuestionDetailTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}

- (void)createUI
{
    [self.contentView addSubview:self.contentL];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, 2)];
    view.backgroundColor = YBackGrayColor;
    [self.contentView addSubview:view];
}

- (TTTAttributedLabel *)contentL
{
    if (_contentL == nil) {
        _contentL = [[TTTAttributedLabel alloc]initWithFrame:CGRectMake(20, 10, WINSIZEWIDTH - 40, 40)];
        _contentL.font = YFont(14);
        _contentL.textColor = YGrayColor;
        _contentL.lineSpacing = 5;
        _contentL.numberOfLines = 0;
    }
    return _contentL;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
