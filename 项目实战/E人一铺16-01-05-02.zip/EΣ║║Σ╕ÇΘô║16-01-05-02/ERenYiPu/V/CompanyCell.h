//
//  CompanyCell.h
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompanyCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView *companyImage;
@property(nonatomic,strong)UILabel *companyLab;
@end
