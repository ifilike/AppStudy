//
//  CompanyCell.m
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "CompanyCell.h"
#define WIDTH (WINSIZEWIDTH/2-WINSIZEWIDTH/20)
#define HEIGHT (WINSIZEWIDTH/2+WINSIZEWIDTH/9)
@implementation CompanyCell
-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    self.companyImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, WIDTH+WIDTH/20)];
    self.companyImage.backgroundColor = YRedColor;
    self.companyLab = [[UILabel alloc]initWithFrame:CGRectMake(0, self.companyImage.height, self.companyImage.width, HEIGHT-self.companyImage.height)];
    self.companyLab.textColor = YGrayColor;
    self.companyLab.textAlignment = NSTextAlignmentCenter;
    self.companyLab.font = YBFont(WINSIZEWIDTH/23);
    //NSLog(@"---------+++collectionCell 实现了");
    [self addSubview:self.companyImage];
    [self addSubview:self.companyLab];
}
- (void)awakeFromNib {
    
    [self createUI];
}

@end
