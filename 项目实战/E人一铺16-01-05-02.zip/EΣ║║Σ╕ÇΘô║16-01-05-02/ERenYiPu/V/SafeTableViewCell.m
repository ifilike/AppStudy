//
//  SafeTableViewCell.m
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SafeTableViewCell.h"

@implementation SafeTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    self.contentTitlt = [[UILabel alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/20, WINSIZEWIDTH-WINSIZEWIDTH/20, WINSIZEWIDTH/18)];
    self.contentTitlt.text = @"理财的一些小知识";
    self.contentTitlt.font = YFont(WINSIZEWIDTH/23);
    self.contentTitlt.textColor = YBlackColor;
    self.contectLab = [[UILabel alloc]initWithFrame:CGRectMake(self.contentTitlt.x, CGRectGetMaxY(self.contentTitlt.frame), self.contentTitlt.width, WINSIZEWIDTH/3)];
    self.contectLab.textColor = [UIColor colorWithHexString:@"acacac"];
    self.contectLab.font = YFont(WINSIZEWIDTH/24);
    
   
    self.contectLab.numberOfLines = 4;
    self.contectLab.text = @"电商要主动积极和政府相关监管部门对接，探讨如何去维护公共利益。另外，在之前一些监管的环节被新技术颠覆情况下，放弃那些环节，重新思考如何用互联网技术进行监管，去维护公共的利益。";

    NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc]initWithString:self.contectLab.text];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
    [style setLineSpacing:5];
    CGFloat textWidth = self.contectLab.width;
    NSInteger leng = textWidth;
    if (attribute.length < textWidth) {
        leng = attribute.length;
    }
    [attribute addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, leng)];
    self.contectLab.attributedText = attribute;
    [self addSubview:self.contectLab];
    [self addSubview:self.contentTitlt];
    
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
