//
//  MediuTableViewCell.m
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MediuTableViewCell.h"

@implementation MediuTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
-(void)createUI{

    self.mediuLogo = [[UIImageView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/20, WINSIZEWIDTH/6-WINSIZEWIDTH/8, WINSIZEWIDTH/2-WINSIZEWIDTH/10, WINSIZEWIDTH/4)];
    self.mediuTitle = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.mediuLogo.frame)+WINSIZEWIDTH/20, self.mediuLogo.y+WINSIZEWIDTH/50, WINSIZEWIDTH/2-WINSIZEWIDTH/20, WINSIZEWIDTH/22)];
    self.mediuTitle.text = @"左边网最新消息";
    self.mediuTitle.font = YBFont(WINSIZEWIDTH/23);
    self.mediuTitle.textColor = YBlackColor;
    self.mediuContent = [[UILabel alloc]initWithFrame:CGRectMake(self.mediuTitle.x, CGRectGetMaxY(self.mediuTitle.frame), self.mediuTitle.width, self.mediuLogo.height - self.mediuTitle.height)];
    self.mediuContent.numberOfLines = 3;

    self.mediuContent.textColor = [UIColor colorWithHexString:@"acacac"];
    self.mediuContent.text = @"电商要主动积极和政府相关监管部门对接，探讨如何去维护公共利益。另外，在之前一些监管的环节被新技术颠覆情况下，放弃那些环节，重新思考如何用互联网技术进行监管，去维护公共的利益。";
    NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc]initWithString:self.mediuContent.text];
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
    [style setLineSpacing:4];
    [attribute addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, self.mediuContent.text.length)];
    self.mediuContent.attributedText = attribute;
    self.mediuContent.font = YBFont(WINSIZEWIDTH/27);
    [self addSubview:self.mediuLogo];
    [self addSubview:self.mediuTitle];
    [self addSubview:self.mediuContent];

}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
