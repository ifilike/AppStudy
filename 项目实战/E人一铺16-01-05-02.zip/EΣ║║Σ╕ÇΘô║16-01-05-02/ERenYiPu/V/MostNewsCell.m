//
//  MostNewsCell.m
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MostNewsCell.h"

@implementation MostNewsCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
- (void)awakeFromNib {
    // Initialization code
   // [self createUI];
}
-(void)createUI{

    self.mostNewsImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH/4+WINSIZEWIDTH/16, WINSIZEWIDTH/4)];
    self.mostNewsImage.image = [UIImage imageNamed:@"news1"];
    self.label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, self.mostNewsImage.height, self.mostNewsImage.height)];
    //_label.text = @"最新消息";
    _label.textColor = [UIColor whiteColor];
    _label.numberOfLines = 0;
    _label.textAlignment = NSTextAlignmentCenter;
    _label.font = YBFont(WINSIZEWIDTH/23);
    [self.mostNewsImage addSubview:_label];
    self.contentLab = [[UILabel alloc]initWithFrame:CGRectMake(self.mostNewsImage.width+WINSIZEWIDTH/20, WINSIZEWIDTH/40, WINSIZEWIDTH-self.mostNewsImage.height*2, WINSIZEWIDTH/4-WINSIZEWIDTH/20)];
    self.contentLab.numberOfLines = 3;
    self.contentLab.text = @"电商要主动积极和政府相关监管部门对接，探讨如何去维护公共利益。另外，在之前一些监管的环节被新技术颠覆情况下，放弃那些环节，重新思考如何用互联网技术进行监管，去维护公共的利益。";
    self.contentLab.font = YFont(WINSIZEWIDTH/27);
    self.contentLab.textColor = YGrayColor;
    
    [self addSubview:self.mostNewsImage];
    [self addSubview:self.contentLab];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
