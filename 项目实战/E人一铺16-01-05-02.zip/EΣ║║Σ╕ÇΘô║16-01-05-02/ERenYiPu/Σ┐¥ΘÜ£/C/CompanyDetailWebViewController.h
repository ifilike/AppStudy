//
//  CompanyDetailWebViewController.h
//  ERenYiPu
//
//  Created by mac on 15/12/15.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompanyDetailWebViewController : UIViewController

@property (nonatomic,strong)NSString *urlStr;

@end
