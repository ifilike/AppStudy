//
//  CommonIssueDetailViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/21.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "CommonIssueDetailViewController.h"
#import "QuestionDetailTableViewCell.h"

@interface CommonIssueDetailViewController () <UITableViewDataSource,UITableViewDelegate>
{
    CGFloat labelH;    //Label高度
    NSInteger rows;
    CGFloat imgHeight ; //图片高度
}
@property (nonatomic,strong)UITableView *tableView ;

@property (nonatomic,strong)NSArray *dataArr; //数据数组

@property (nonatomic)NSInteger selectedSection;


@end

@implementation CommonIssueDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _dataArr = [NSArray array];
    rows = 0;
    //_selectedSection = [NSIndexPath indexPathForRow:100 inSection:100];
    
    [self.view addSubview:self.tableView];
    
}

- (UITableView *)tableView
{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:(UITableViewStylePlain)];
        _tableView.contentInset = UIEdgeInsetsMake(0, 0, 64, 0);
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [[UIView alloc]init];
        
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == _selectedSection) {
        return rows;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{

    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, 50)];
    view.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(20, 15, WINSIZEWIDTH - 50, 20)];
    label.textColor = [UIColor blackColor];
    label.font = YFont(18);
    label.text = [_dataArr[section] valueForKey:@"question"];
    
    UIButton *bt = [UIButton buttonWithType:UIButtonTypeCustom];
    bt.frame = CGRectMake(0, 0, WINSIZEWIDTH, 50);
    bt.tag = section + 10000;
    if (section == _selectedSection) {
        if (rows == 0) {
            [bt setImage:[UIImage imageNamed:@"commonissue_right"] forState:(UIControlStateNormal)];
        }else{
            [bt setImage:[UIImage imageNamed:@"commonissue_top"] forState:(UIControlStateNormal)];
        }
        
    }else{
        [bt setImage:[UIImage imageNamed:@"commonissue_right"] forState:(UIControlStateNormal)];
    }
    //[bt setImage:[UIImage imageNamed:@"commonissue_right"] forState:(UIControlStateNormal)];
    [bt setImageEdgeInsets:UIEdgeInsetsMake(0, WINSIZEWIDTH - 50, 0, -5)];
    
    [bt addTarget:self action:@selector(btClickAction:) forControlEvents:(UIControlEventTouchUpInside)];
    
    [view addSubview:label];
    [view addSubview:bt];
    
    return view;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_rowNum isEqualToString:@"3"]) {
        if (indexPath.section == 0) {
            return imgHeight + 10;
        }
    }
    
    NSString *textStr = [NSString stringWithFormat:@"%@",[[_dataArr objectAtIndex:indexPath.section] valueForKey:@"answer"]];
    UILabel *label = [[UILabel alloc]init];
    label.text = textStr;
    label.numberOfLines = 0;
    CGSize size = CGSizeMake(WINSIZEWIDTH - 40, 1000);
  //  CGSize labelSize = [label.text
    CGRect frame = [label textRectForBounds:CGRectMake(0, 0, size.width, size.height) limitedToNumberOfLines:0];
    labelH = frame.size.height;
    return 10 + labelH;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _dataArr.count ;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        
    }
    return [_dataArr[section] valueForKey:@"question"];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_rowNum isEqualToString:@"3"]) {
        if (indexPath.section == 0) {
            UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:nil];
            UIImage *img1 = [UIImage imageNamed:@"table01"];
            
            UIImageView *image1 = [[UIImageView alloc]initWithImage:img1];
            CGFloat rate1 = img1.size.height / img1.size.width;
            image1.frame = CGRectMake(10, 0, WINSIZEWIDTH - 20, (WINSIZEWIDTH - 20) * rate1);
            
            UIImage *img2 = [UIImage imageNamed:@"table02"];
            
            UIImageView *image2 = [[UIImageView alloc]initWithImage:img2];
            CGFloat rate2 = img2.size.height / img2.size.width;
            
            image2.frame = CGRectMake(30, CGRectGetMaxY(image1.frame) + 5, WINSIZEWIDTH - 60, (WINSIZEWIDTH - 60) * rate2);
            
            [cell.contentView addSubview:image1];
            [cell.contentView addSubview:image2];
            
            imgHeight = image1.frame.size.height + image2.frame.size.height;
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    
    [tableView registerClass:[QuestionDetailTableViewCell class] forCellReuseIdentifier:@"cell"];
    QuestionDetailTableViewCell *cell = [[QuestionDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    NSString *textStr = [NSString stringWithFormat:@"%@",[[_dataArr objectAtIndex:indexPath.section] valueForKey:@"answer"]];
    cell.contentL.text = textStr;
    CGSize size = CGSizeMake(300, 1000);
//    CGSize labelSize = [cell.contentL.text sizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:size lineBreakMode:NSLineBreakByClipping];
//    labelH = labelSize.height;
    cell.contentL.frame = CGRectMake(20, 10, WINSIZEWIDTH - 40, labelH);
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - 解析数据
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    NSString *plistPath = [[NSBundle mainBundle]pathForResource:@"commonIssue" ofType:@"plist"];
    
    NSArray *data = [NSArray arrayWithContentsOfFile:plistPath];
    
    _dataArr = [NSArray arrayWithArray:[data objectAtIndex:[_rowNum intValue]]];
    
    //[_tableView reloadData];
    
    NSLog(@"%@",data);
}

#pragma mark - 按钮点击事件
- (void)btClickAction:(UIButton *)bt
{
    if (rows == 0) {
        
        rows = 1;
        [bt setImage:[UIImage imageNamed:@"commonissue_top"] forState:(UIControlStateNormal)];
    }else {
        rows = 0;
        [bt setImage:[UIImage imageNamed:@"commonissue_right"] forState:(UIControlStateNormal)];
    }
    
    NSLog(@"%ld",(long)bt.tag - 10000);
        
    //NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:bt.tag - 10000];
        
    _selectedSection = bt.tag - 10000;
    
    [_tableView reloadData];
    
    if (rows == 1) {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:bt.tag - 10000] atScrollPosition:(UITableViewScrollPositionBottom) animated:YES];
    }
    
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
