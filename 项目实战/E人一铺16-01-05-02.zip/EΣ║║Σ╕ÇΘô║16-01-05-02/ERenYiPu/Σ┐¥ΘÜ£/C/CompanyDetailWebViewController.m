//
//  CompanyDetailWebViewController.m
//  ERenYiPu
//
//  Created by mac on 15/12/15.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "CompanyDetailWebViewController.h"

@interface CompanyDetailWebViewController ()

@end

@implementation CompanyDetailWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIWebView *webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEHEIGHT - 64)];
    webView.backgroundColor = [UIColor whiteColor];
    
    //NSString *htmlString = [NSString stringWithContentsOfFile:_urlStr encoding:NSUTF8StringEncoding error:nil];
    //[webView loadData:[NSData dataWithContentsOfFile:_urlStr] MIMEType:@"text/html" textEncodingName:@"charset=UTF-8" baseURL:nil];
    
    NSURL* url = [NSURL fileURLWithPath:_urlStr];
    NSURLRequest* request = [NSURLRequest requestWithURL:url] ;
    [webView loadRequest:request];
    
    [self.view addSubview:webView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
