//
//  SafeViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/3.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SafeViewController.h"
#import "MostNewsCell.h"
#import "SafeTableViewCell.h"
#import "MediuTableViewCell.h"
#import "CompanyCell.h"
#import "NewsModel.h"//最新消息
#import "SafeModel.h"//媒体报道
#import "KnowledgeModel.h"//安全保障
#import "SLAlertView.h"
#import "CompanyDetailWebViewController.h"
#import "CommonIssueDetailViewController.h"
#import "UserData.h"
@interface SafeViewController ()<EMenuViewDelegate,UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,UICollectionViewDataSource,UICollectionViewDelegate>
@property (nonatomic,strong) EMenuView *menuView;//菜单栏
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) UITableView *mostTableView;//最新消息
@property (nonatomic,strong) UITableView *safeTableView;//安全保障
@property (nonatomic,strong) UITableView *mediumTableView;//媒体报道
@property (nonatomic,strong) UICollectionView *companyView;//公司介绍
@property (nonatomic,strong) NSMutableArray *newsArr;//新闻
@property (nonatomic,strong) NSMutableArray *reportArr;//报道
@property (nonatomic,strong) NSMutableArray *safeArr;//安全保障

@property (nonatomic,strong) NSArray *labelArr; //label文字数组
@property (nonatomic,strong) NSArray *imageArr; //图片名数组
@end

@implementation SafeViewController
-(UICollectionView *)companyView{

    if (!_companyView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        [flowLayout setItemSize:CGSizeMake(WINSIZEWIDTH/2-WINSIZEWIDTH/20, WINSIZEWIDTH/2+WINSIZEWIDTH/9)];
        flowLayout.sectionInset = UIEdgeInsetsMake(0, WINSIZEWIDTH/30, WINSIZEWIDTH/50, WINSIZEWIDTH/30);
        _companyView = [[UICollectionView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH*3, 0, WINSIZEWIDTH, self.scrollView.height) collectionViewLayout:flowLayout];;
        _companyView.delegate = self;
        _companyView.dataSource = self;
        _companyView.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];

    }
    return _companyView;
}
-(UITableView *)mostTableView{

    if (!_mostTableView) {
        _mostTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, self.scrollView.height)];
        _mostTableView.delegate = self;
        _mostTableView.dataSource = self;
        _mostTableView.tableFooterView = [[UIView alloc]init];;
        //_mostTableView.backgroundColor = YRedColor;
    }
    return _mostTableView;
}
-(UITableView *)safeTableView{

    if (!_safeTableView) {
        _safeTableView = [[UITableView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH, 0, WINSIZEWIDTH, self.scrollView.height)];
        _safeTableView.delegate = self;
        _safeTableView.dataSource = self;
        _safeTableView.tableFooterView = [[UIView alloc]init];
        //_safeTableView.backgroundColor = YRedColor;
    }
    return _safeTableView;
}
-(UITableView *)mediumTableView{

    if (!_mediumTableView) {
        _mediumTableView = [[UITableView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH*2, 0, WINSIZEWIDTH, self.scrollView.height)];
        _mediumTableView.delegate = self;
        _mediumTableView.dataSource = self;
        _mediumTableView.tableFooterView = [[UIView alloc]init];
       // _mediumTableView.backgroundColor = YRedColor;
    }
    return _mediumTableView;
}
//菜单栏
-(EMenuView *)menuView{
    if (!_menuView) {

        _menuView = [[EMenuView alloc]initWithFrame:CGRectMake(0, 0, WINSIZEWIDTH, WINSIZEWIDTH/8)];
#warning 投资背景 应该 是 公司介绍
        _menuView.menuArr = [@[@"最新消息",@"安全保障",@"常见问题",@"公司介绍"]mutableCopy];
        
        [_menuView creatUI:_menuView.menuArr];
        _menuView.delegate = self;
    }
    return _menuView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = YBackGrayColor;
    [self.view addSubview:self.menuView];
    _labelArr = @[@"新手上路",@"注册登录篇",@"绑卡篇",@"充值/投资篇",@"活动篇",@"赎回/提现篇",@"其他问题"];
    _imageArr = @[@"commonissue1",@"commonissue2",@"commonissue3",@"commonissue4",@"commonissue5",@"commonissue6",@"commonissue7"];
    [self createUI];
//获取数
    [self getNewsData];
//    [self getReportData];
    [self getSafeData];
    // Do any additional setup after loading the view.
}
-(void)createUI{

    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, self.menuView.height+2, WINSIZEWIDTH, self.view.height-WINSIZEWIDTH/7-WINSIZEWIDTH/80-self.tabBarController.tabBar.height- self.navigationController.navigationBar.height)];
    scrollView.pagingEnabled = YES;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.bounces = NO;
    scrollView.delegate = self;
    scrollView.contentSize = CGSizeMake(WINSIZEWIDTH*4, scrollView.height);

    self.scrollView = scrollView;
    [self.scrollView addSubview:self.safeTableView];
    [self.scrollView addSubview:self.mostTableView];
    [self.scrollView addSubview:self.mediumTableView];
    [self.scrollView addSubview:self.companyView];
  //  NSLog(@"---------%@",self.mediumTableView);
    [self.view addSubview:self.scrollView];
}
#pragma mark -- tableviewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    if (tableView == self.mostTableView) {
        return _newsArr.count;
    }else if(tableView == self.safeTableView){
    
        return _safeArr.count;
    }else if(tableView == self.mediumTableView){
    
        return _imageArr.count;
    }
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if (tableView==self.mostTableView||tableView==self.safeTableView||tableView==self.mediumTableView) {
        return 1;
    }
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (tableView==self.mostTableView) {
        return WINSIZEWIDTH/4;
    }else if(tableView == self.safeTableView){
    
        return WINSIZEWIDTH/2-WINSIZEWIDTH/20;
    }else if(tableView == self.mediumTableView){
    
        return WINSIZEWIDTH/7;
    }
    return 0;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{

    return WINSIZEWIDTH/30;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (tableView == self.mostTableView) {//最新消息
        
    MostNewsCell *mostNewsCell = [tableView dequeueReusableCellWithIdentifier:@"mostNewsCell"];
    if (!mostNewsCell) {
        mostNewsCell = [[MostNewsCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"mostNewsCell"];
        
    }
        NSString *imageStr = [NSString stringWithFormat:@"news%li",indexPath.section%5+1];
        mostNewsCell.mostNewsImage.image = [UIImage imageNamed:imageStr];
        
        mostNewsCell.label.text = [[_newsArr objectAtIndex:indexPath.section] valueForKey:@"news_title"];
        NSLog(@"mostNewsCell.label.text  %@",mostNewsCell.label.text);
        mostNewsCell.contentLab.text = [[_newsArr objectAtIndex:indexPath.section]valueForKey:@"news_summary"];
        
        return mostNewsCell;
    }else if(tableView == self.safeTableView){//安全保障
    
         NSString *str = @"safeCell";
        SafeTableViewCell *safeCell = [tableView dequeueReusableCellWithIdentifier:str];
        if (!safeCell) {
            safeCell = [[SafeTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:str];
        }
        
        safeCell.contentTitlt.text = [[_safeArr objectAtIndex:indexPath.section]valueForKey:@"knowledge_title"];
        safeCell.contectLab.text = [[_safeArr objectAtIndex:indexPath.section]valueForKey:@"knowledge_content"];
        
        return safeCell;
    }else if(tableView == self.mediumTableView){//常见问题
    
        UITableViewCell *mediuCell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:nil];
        
        mediuCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        //        [cell.contentView addSubview:image];
        //        [cell.contentView addSubview:label];
        //
        mediuCell.textLabel.text = self.labelArr[indexPath.section];
        mediuCell.textLabel.font = YFont(WINSIZEWIDTH/20);
        mediuCell.textLabel.textColor =YGrayColor;
        mediuCell.imageView.image = [UIImage imageNamed:self.imageArr[indexPath.section]];
        
        
//        MediuTableViewCell *mediuCell = [tableView dequeueReusableCellWithIdentifier:str];
//        if (!mediuCell) {
//            mediuCell = [[MediuTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:str];
//        }
//
////        NSString *imageStr = [NSString stringWithFormat:@"mediu%ld",indexPath.section%3+1];
////        mediuCell.mediuLogo.image = [UIImage imageNamed:imageStr];
//        
//        NSString *headStr = [NSString stringWithFormat:@"%@%@",IMGURL,[[self.reportArr objectAtIndex:indexPath.section]valueForKey:@"report_pic"]];
//        [mediuCell.mediuLogo setImageWithURLRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:headStr]] placeholderImage:[UIImage imageNamed:@"report"] success:nil failure:nil];
//        
//        mediuCell.mediuTitle.text = [[self.reportArr objectAtIndex:indexPath.section]valueForKey:@"report_title"];
//        mediuCell.mediuContent.text = [[self.reportArr objectAtIndex:indexPath.section]valueForKey:@"report_sum"];
        
        return mediuCell;
    }
    return nil;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    PublicViewController *Publec = [PublicViewController new];
    if (tableView == self.mostTableView) {
        NewsModel *model = self.newsArr[indexPath.section];
        Publec.idName = @"news_id";
        Publec.contentText = model.news_content;
        Publec.contentTitleText = model.news_title;
        Publec.contentId = model.news_id;
        Publec.pageTitle = model.news_title;
    }else if(tableView == self.safeTableView){
        KnowledgeModel *model = self.safeArr[indexPath.section];
        Publec.pageTitle = model.knowledge_title;
        Publec.contentText = model.knowledge_content;
        Publec.contentTitleText = model.knowledge_title;
        Publec.contentId = model.knowledge_id;
        Publec.idName = @"knowledge_id";
    }else if(tableView == self.mediumTableView){
        
        CommonIssueDetailViewController *commonDetailVC = [[CommonIssueDetailViewController alloc]init];
        commonDetailVC.rowNum = [NSString stringWithFormat:@"%ld",(long)indexPath.section];
        commonDetailVC.title = _labelArr[indexPath.section];
        [self.navigationController pushViewController:commonDetailVC animated:YES];
        
//        SafeModel *model = self.reportArr[indexPath.row];
//        Publec.contentText = model.report_content;
//        Publec.contentTitleText = model.report_title;
//        Publec.contentId = model.report_id;
//        Publec.pageTitle = model.report_title;
//        Publec.idName = @"report_id";
        return;
    }
    [self.navigationController pushViewController:Publec animated:YES];
}
#pragma mark -- collection
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{

    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{

    return 4;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
#warning 干掉了公司介绍 和 高管团队
    NSArray *array = @[@"公司介绍",@"投资背景",@"高管团队",@"战略合作"];
    //NSArray *array = @[@"投资背景"];
    [self.companyView registerNib:[UINib nibWithNibName:@"CompanyCell" bundle:[NSBundle mainBundle]]forCellWithReuseIdentifier:@"collectionCell"];
    CompanyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"collectionCell" forIndexPath:indexPath];
    cell.companyLab.text = array[indexPath.row];
    NSLog(@"+++++++array:%@",array[indexPath.row]);
    NSString *imageStr = [NSString stringWithFormat:@"company%li",indexPath.row+1];
    cell.companyImage.image = [UIImage imageNamed:imageStr];
    UIView *backView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, cell.width, cell.height)];
    backView.backgroundColor = YRedColor;
    cell.selectedBackgroundView=backView;
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{

    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    NSArray *array = @[@"公司介绍",@"投资背景",@"高管团队",@"战略合作"];
//    NSArray *array = @[@"投资背景"];
    CompanyDetailWebViewController *compantWebVC = [[CompanyDetailWebViewController alloc]init];
    NSString *filePath = [[NSBundle mainBundle]pathForResource:[NSString stringWithFormat:@"gsxq%li",indexPath.row] ofType:@"html"];///Users/mac/Desktop/eRenYiPu-iOS 2/ERenYiPu/保障/gsxq0.html
    compantWebVC.urlStr = filePath;
    NSLog(@"%@",filePath);
    compantWebVC.title = array[indexPath.row];
    [self.navigationController pushViewController:compantWebVC animated:YES];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{

    if (scrollView == self.scrollView) {
        
    [ self.menuView changeStatus:(scrollView.contentOffset.x+WINSIZEWIDTH/2)/WINSIZEWIDTH+10000];
    
    }
}
#pragma mark -- 获取数据
//新闻
-(void)getNewsData{

    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"newsArrDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天
    if ([dateString isEqualToString:nowDataString]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].newsArr) {
            self.newsArr = [NSMutableArray array];
            for (NSDictionary *dic in [UserData sharedUserData].newsArr) {
                NewsModel *news = [[NewsModel alloc]init];
                news = [NewsModel objectWithKeyValues:dic];
                [self.newsArr addObject:news];
            }
            [_mostTableView reloadData];
            return;
        }
    } else {
        NSString *str = [NSString stringWithFormat:@"{\"page\":\"1\"}"];
        [IKHttpTool postWithURL:@"getNews" params:@{@"json":str} success:^(id json) {
            NSLog(@"请求newsData数据");
            
            
            [userDefaults setObject:dateString forKey:@"newsArrDateString"];
            [userDefaults synchronize];
            
            NSArray *array = json[@"data"];
            if (array) {
                [UserData sharedUserData].newsArr = array;
            }
            self.newsArr = [NSMutableArray array];
            for (NSDictionary *dic in array) {
                NewsModel *news = [[NewsModel alloc]init];
                news = [NewsModel objectWithKeyValues:dic];
                [self.newsArr addObject:news];
            }
            [_mostTableView reloadData];
            NSLog(@"------news:%lu",(unsigned long)self.newsArr.count);
        } failure:^(NSError *error) {
            
        }];
    }

}
//安全保障
-(void)getSafeData{
    
    NSUserDefaults *userDefaults = [[NSUserDefaults alloc] init];
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *nowDataString = [userDefaults objectForKey:@"arratDateString"];
    NSDate *date = [NSDate date];
    NSString *dateString = [fmt stringFromDate:date];
    // 如果保存地址是当天
    if ([dateString isEqualToString:nowDataString]) {
        // 判断本地是否拥有数据
        if ([UserData sharedUserData].arrat) {
            self.safeArr = [NSMutableArray array];
            for (NSDictionary *dic in [UserData sharedUserData].arrat) {
                KnowledgeModel *knowledge = [KnowledgeModel new];
                knowledge = [KnowledgeModel objectWithKeyValues:dic];
                [self.safeArr addObject:knowledge];
            }
            [_safeTableView reloadData];
            NSLog(@"------knowledge:%@",self.safeArr);
            return;
        }
    } else {
        NSString *str = [NSString stringWithFormat:@"{\"page\":\"1\"}"];
        [IKHttpTool postWithURL:@"getKnowledge" params:@{@"json":str} success:^(id json) {
            
            NSLog(@"请求arratDate数据");
            [userDefaults setObject:dateString forKey:@"arratDateString"];
            [userDefaults synchronize];
            
            NSArray *arrat = json[@"data"];
            if (arrat) {
                [UserData sharedUserData].arrat = arrat;
            }
            self.safeArr = [NSMutableArray array];
            for (NSDictionary *dic in arrat) {
                KnowledgeModel *knowledge = [KnowledgeModel new];
                knowledge = [KnowledgeModel objectWithKeyValues:dic];
                [self.safeArr addObject:knowledge];
            }
            [_safeTableView reloadData];
            NSLog(@"------knowledge:%@",self.safeArr);
        } failure:^(NSError *error) {
            
        }];
    }

    
}

////媒体报道
//-(void)getReportData{
//
//    NSString *str = [NSString stringWithFormat:@"{\"page\":\"1\"}"];
//    [IKHttpTool postWithURL:@"getReport" params:@{@"json":str} success:^(id json) {
//        NSArray *array = json[@"data"];
//        self.reportArr = [NSMutableArray array];
//        for (NSDictionary *dic in array) {
//            SafeModel *safe = [SafeModel new];
//            safe = [SafeModel objectWithKeyValues:dic];
//            [self.reportArr addObject:safe];
//        }
//        [_mediumTableView reloadData];
//        NSLog(@"-----report:%@",self.reportArr);
//    } failure:^(NSError *error) {
//        
//    }];
//}
-(void)changeMenuStatus:(NSInteger)tag{
    //[MBProgressHUD showSuccess:[NSString stringWithFormat:@"%ld",tag]];
    CGPoint point = CGPointMake((tag-10000)*WINSIZEWIDTH, 0);
    self.scrollView.contentOffset = point;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
