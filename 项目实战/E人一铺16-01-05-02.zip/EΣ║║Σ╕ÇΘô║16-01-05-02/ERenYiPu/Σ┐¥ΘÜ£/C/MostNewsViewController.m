//
//  MostNewsViewController.m
//  ERenYiPu
//
//  Created by babbage on 15/11/9.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "MostNewsViewController.h"

@interface MostNewsViewController ()

@end

@implementation MostNewsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"最新消息";
    self.view.backgroundColor = [UIColor colorWithHexString:@"f0f0f0"];
    [self createUI];
}
-(void)createUI{

    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(WINSIZEWIDTH/26, WINSIZEWIDTH/30, WINSIZEWIDTH-WINSIZEWIDTH/13, self.view.height-WINSIZEWIDTH/15-CGRectGetMaxY(self.navigationController.navigationBar.frame))];
    view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:view];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
