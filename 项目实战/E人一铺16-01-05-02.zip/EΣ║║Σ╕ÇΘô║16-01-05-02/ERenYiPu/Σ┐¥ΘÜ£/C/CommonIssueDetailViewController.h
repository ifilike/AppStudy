//
//  CommonIssueDetailViewController.h
//  ERenYiPu
//
//  Created by mac on 15/12/21.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommonIssueDetailViewController : UIViewController

@property (nonatomic,strong)NSString *rowNum;

@end
