//
//  SafeModel.m
//  ERenYiPu
//
//  Created by babbage on 15/11/19.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "SafeModel.h"

@implementation SafeModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    [super setValue:value forUndefinedKey:key];
}

@end
