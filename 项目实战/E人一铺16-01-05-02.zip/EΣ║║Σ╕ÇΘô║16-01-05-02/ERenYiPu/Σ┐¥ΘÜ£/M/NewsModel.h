//
//  NewsModel.h
//  ERenYiPu
//
//  Created by babbage on 15/11/19.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsModel : NSObject
@property(nonatomic,strong) NSString *news_id;
@property (nonatomic,strong) NSString *news_title;
@property (nonatomic,strong) NSString *news_summary;
@property (nonatomic,strong) NSString *news_content;
@property (nonatomic,strong) NSString *news_time;
@property (nonatomic,strong) NSString *support_number;
@end
