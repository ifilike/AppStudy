//
//  NewsModel.m
//  ERenYiPu
//
//  Created by babbage on 15/11/19.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import "NewsModel.h"

@implementation NewsModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    [super setValue:value forUndefinedKey:key];
}

@end
