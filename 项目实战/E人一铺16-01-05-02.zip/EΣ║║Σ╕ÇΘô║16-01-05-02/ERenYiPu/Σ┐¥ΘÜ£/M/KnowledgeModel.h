//
//  KnowledgeModel.h
//  ERenYiPu
//
//  Created by babbage on 15/11/19.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KnowledgeModel : NSObject
@property (nonatomic,strong) NSString *knowledge_id;
@property (nonatomic,strong) NSString *knowledge_title;
@property (nonatomic,strong) NSString *knowledge_summary;
@property (nonatomic,strong) NSString *knowledge_number;
@property (nonatomic,strong) NSString *knowledge_content;
@property (nonatomic,strong) NSString *knowledge_time;
@end
