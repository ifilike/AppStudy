//
//  SafeModel.h
//  ERenYiPu
//
//  Created by babbage on 15/11/19.
//  Copyright © 2015年 babbage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SafeModel : NSObject
@property (nonatomic,strong) NSString *report_id;
@property (nonatomic,strong) NSString *report_title;
@property (nonatomic,strong) NSString *report_pic;
@property (nonatomic,strong) NSString *report_sum;
@property (nonatomic,strong) NSString *report_content;
@property (nonatomic,strong) NSString *support_number;
@property (nonatomic,strong) NSString *report_time;
@end
