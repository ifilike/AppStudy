//
//  NSStringUtils.h
//  BJGJJ
//
//  Created by 迪远 王 on 16/1/30.
//  Copyright © 2016年 andforce. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSStringUtils : NSObject

+(BOOL) isEmpty:(NSString*)string;
@end
