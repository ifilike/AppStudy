//
//  TransDataUIViewController.h
//  BJGJJ
//
//  Created by 迪远 王 on 16/2/2.
//  Copyright © 2016年 andforce. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TransDataUIViewController : UIViewController

@property (nonatomic, strong) NSObject* data;

-(void) transData:(NSObject*)data;

@end
