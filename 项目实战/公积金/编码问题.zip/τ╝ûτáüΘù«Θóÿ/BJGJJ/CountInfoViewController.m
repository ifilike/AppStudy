//
//  CountInfoViewController.m
//  BJGJJ
//
//  Created by 迪远 王 on 16/2/2.
//  Copyright © 2016年 andforce. All rights reserved.
//

#import "CountInfoViewController.h"
#import "StatusBean.h"



@interface CountInfoViewController ()

@end

@implementation CountInfoViewController


@synthesize data;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    NSLog(@"%@", data);
    
    NSArray * st =  ((NSArray*)data);
    
    StatusBean * last = st.lastObject;
    
    
    _moneyCount.text = last.companyName;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/




@end
