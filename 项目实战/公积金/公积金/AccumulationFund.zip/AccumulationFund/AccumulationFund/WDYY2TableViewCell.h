//
//  WDYY2TableViewCell.h
//  AccumulationFund
//
//  Created by mac on 15/11/21.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WDYY2TableViewCell : UITableViewCell

@property (strong, nonatomic) UIImageView * backgroundImageView;
@property (strong, nonatomic) UILabel * infoLabel;

@end
