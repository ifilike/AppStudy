//
//  FDJSMXViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/18.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import "TQYYBackViewController.h"

@interface FDJSMXViewController : TQYYBackViewController

@property (strong, nonatomic) NSArray * dataSource;

@end
