//
//  SelectionMultipleIndicator.h
//  SelectedList
//
//  Created by mac on 15/11/14.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectionMultipleIndicator : UIView
@property (assign, nonatomic) BOOL selected;

@end
