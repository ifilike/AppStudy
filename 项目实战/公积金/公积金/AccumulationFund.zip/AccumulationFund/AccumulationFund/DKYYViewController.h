//
//  DKYYViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/16.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DKYYViewController : UIViewController

@property (strong, nonatomic) NSArray *purchaseType;
@property (strong, nonatomic) NSArray *appointmentBranch;
@end
