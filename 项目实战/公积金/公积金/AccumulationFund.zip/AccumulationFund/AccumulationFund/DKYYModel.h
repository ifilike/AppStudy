//
//  DKYYModel.h
//  AccumulationFund
//
//  Created by mac on 15/11/16.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DKYYModel : NSObject

@property (copy, nonatomic) NSString * type;
@property (copy, nonatomic) NSString * number;
@property (copy, nonatomic) NSString * reservesDate;
@property (copy, nonatomic) NSString * reservesOutlet;
@end
