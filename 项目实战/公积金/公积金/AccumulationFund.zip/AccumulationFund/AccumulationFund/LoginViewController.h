//
//  LoginViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/21.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *label1;
@property (weak, nonatomic) IBOutlet UITextField *label2;
@property (weak, nonatomic) IBOutlet UITextField *label3;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@end
