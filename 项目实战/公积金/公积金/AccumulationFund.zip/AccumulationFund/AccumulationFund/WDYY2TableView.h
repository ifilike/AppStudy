//
//  WDYY2TableView.h
//  AccumulationFund
//
//  Created by mac on 15/11/21.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WDYY2TableView : UITableView
@property (strong, nonatomic) UIView *lineView;
@end
