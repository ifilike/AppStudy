//
//  FDSJXQViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/18.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FDSJXQViewController : UIViewController

@property (copy, nonatomic) NSString *maxLoanAmount;
@property (copy, nonatomic) NSString *maxLoanDate;
@property (strong, nonatomic) NSArray *mxDataSource;


@end
