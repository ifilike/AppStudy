//
//  DKYYModel.m
//  AccumulationFund
//
//  Created by mac on 15/11/16.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import "DKYYModel.h"

@implementation DKYYModel

@end
