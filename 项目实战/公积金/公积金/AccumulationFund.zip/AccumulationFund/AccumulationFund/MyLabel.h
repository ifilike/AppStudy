//
//  MyLabel.h
//  AccumulationFund
//
//  Created by SL🐰鱼子酱 on 15/11/20.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLabel : UILabel

@end
