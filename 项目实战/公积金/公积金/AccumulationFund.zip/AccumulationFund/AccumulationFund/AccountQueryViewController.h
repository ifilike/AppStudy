//
//  AccountQueryViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/19.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccountQueryViewController : UIViewController

@property (strong, nonatomic) NSDictionary *userAccountDict;

@end
