//
//  WDYYModel.h
//  AccumulationFund
//
//  Created by mac on 15/11/14.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WDYYModel : NSObject

@property (copy, nonatomic) NSString * operationDate;
@property (copy, nonatomic) NSString * itemName;
@property (copy, nonatomic) NSString * reservesDate;
@property (copy, nonatomic) NSString * reservesOutlet;
@property (copy, nonatomic) NSString * reservesNumber;
@property (copy, nonatomic) NSString * businessInfo;

@end
