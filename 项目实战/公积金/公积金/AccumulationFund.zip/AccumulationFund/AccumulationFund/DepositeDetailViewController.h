//
//  DepositeDetailViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/19.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DepositeDetailViewController : UIViewController

@property (strong, nonatomic) NSArray *depositDetail;

@end
