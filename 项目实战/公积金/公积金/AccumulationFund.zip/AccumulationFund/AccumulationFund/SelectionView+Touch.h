//
//  SelectionView+Touch.h
//  AccumulationFund
//
//  Created by mac on 15/11/17.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import "SelectionView.h"

@interface SelectionView (Touch)

@end
