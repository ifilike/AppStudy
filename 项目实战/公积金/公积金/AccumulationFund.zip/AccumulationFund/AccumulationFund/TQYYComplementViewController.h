//
//  TQYYComplementViewController.h
//  AccumulationFund
//
//  Created by mac on 15/12/16.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TQYYComplementViewController : UIViewController
// 预约编号
@property (copy, nonatomic) NSString *yybh;
@property (copy, nonatomic) NSString *appointedDate;
@property (copy, nonatomic) NSString *appointedOutlet;
@property (copy, nonatomic) NSString *drawReasonCode;

@end
