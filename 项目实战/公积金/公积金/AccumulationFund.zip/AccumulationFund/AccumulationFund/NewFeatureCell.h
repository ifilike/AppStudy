//
//  NewFeatureCell.h
//  AccumulationFund
//
//  Created by SL🐰鱼子酱 on 15/11/14.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewFeatureCell : UICollectionViewCell
@property (assign, nonatomic) NSInteger imageIndex;
- (void)showStartButton;
@end
