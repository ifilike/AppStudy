//
//  TQYYOutletsPickerView.h
//  AccumulationFund
//
//  Created by mac on 15/12/16.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TQYYOutletsPickerView : UIPickerView

@property (strong, nonatomic) NSArray *outlets;
@property (strong, nonatomic) NSIndexPath *selectedIndexPath;

@end
