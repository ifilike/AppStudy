//
//  FundReferences.m
//  AccumulationFund
//
//  Created by mac on 15/11/13.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import "FundReferences.h"


CGFloat k_margin_vertical = 8;
CGFloat k_margin_horizontal = 12;


CGFloat k_tqyy_row_height = 30;

CGFloat k_section0_side_percent = 0.333333;
CGFloat k_collection_cell_margin = 15;





// 关于我们页面CellIcon尺寸
CGFloat k_about_cell_icon_side = 25;