//
//  TQYYViewController.h
//  AccumulationFund
//
//  Created by mac on 15/11/14.
//  Copyright © 2015年 huancun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TQYYBackViewController.h"

@interface TQYYViewController : TQYYBackViewController

@property (strong, nonatomic) NSArray * drawReason;


@end
