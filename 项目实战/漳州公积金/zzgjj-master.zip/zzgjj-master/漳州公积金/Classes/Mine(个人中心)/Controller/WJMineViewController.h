//
//  WJMineViewController.h
//  漳州公积金
//
//  Created by fengwujie on 16/1/4.
//  Copyright © 2016年 vision-soft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WJWebViewController.h"

@interface WJMineViewController : WJWebViewController

@end
