//
//  NSString+File.h
//  黑马微博
//
//  Created by apple on 14-7-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (File)
- (long long)fileSize;
@end
