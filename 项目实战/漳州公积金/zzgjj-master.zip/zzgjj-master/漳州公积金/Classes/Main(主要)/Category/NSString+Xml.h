//
//  NSString+Xml.h
//  漳州公积金
//
//  Created by fengwujie on 16/1/13.
//  Copyright © 2016年 vision-soft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Xml)


-(NSString *)stringByXmlNoteContentWithElementName:(NSString *)elementName;
@end
