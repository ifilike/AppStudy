//
//  CommonCenterItem.h
//

#import "WJCommonItem.h"

@interface CommonCenterItem : WJCommonItem

@end
