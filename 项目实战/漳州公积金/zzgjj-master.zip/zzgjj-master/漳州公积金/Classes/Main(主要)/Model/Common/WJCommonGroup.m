//
//  CommonGroup.m
//  

#import "WJCommonGroup.h"

@implementation WJCommonGroup
+ (instancetype)group
{
    return [[self alloc] init];
}
@end
