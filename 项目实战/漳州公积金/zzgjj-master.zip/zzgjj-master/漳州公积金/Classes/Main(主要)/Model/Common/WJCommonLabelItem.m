//
//  CommonLabelItem.m

#import "WJCommonLabelItem.h"

@implementation WJCommonLabelItem

@end
