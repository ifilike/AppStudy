//
//  CommonArrowItem.m
//

#import "WJCommonArrowItem.h"

@implementation WJCommonArrowItem

@end
