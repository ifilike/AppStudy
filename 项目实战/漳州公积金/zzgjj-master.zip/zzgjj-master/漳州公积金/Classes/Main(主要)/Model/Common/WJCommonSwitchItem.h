//
//  CommonSwitchItem.h
//

#import "WJCommonItem.h"

@interface WJCommonSwitchItem : WJCommonItem

@end
