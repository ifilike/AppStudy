//
//  WJVersion.m
//  漳州公积金
//
//  Created by fengwujie on 16/1/5.
//  Copyright © 2016年 vision-soft. All rights reserved.
//

#import "WJVersion.h"

@implementation WJVersion

@end
