//
//  WJCommonCenterItem.m
//

#import "WJCommonCenterItem.h"

@implementation CommonCenterItem

@end
