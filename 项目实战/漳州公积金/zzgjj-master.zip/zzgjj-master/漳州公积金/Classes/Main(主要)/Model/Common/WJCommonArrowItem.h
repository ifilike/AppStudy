//
//  CommonArrowItem.h
//

#import "WJCommonItem.h"

@interface WJCommonArrowItem : WJCommonItem

@end
