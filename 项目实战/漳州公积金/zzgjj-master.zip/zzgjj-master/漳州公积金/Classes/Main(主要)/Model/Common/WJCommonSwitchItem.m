//
//  CommonSwitchItem.m
//

#import "WJCommonSwitchItem.h"

@implementation WJCommonSwitchItem

@end
