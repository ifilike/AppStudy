//
//  CommonLabelItem.h
//

#import "WJCommonItem.h"

@interface WJCommonLabelItem : WJCommonItem
/** 右边label显示的内容 */
@property (nonatomic, copy) NSString *text;
@end
