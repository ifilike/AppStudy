//
//  SCHeader.h
//  SoapWebServices
//
//  Created by SC2 on 14-2-28.
//  Copyright (c) 2014年 北京士昌信息技术有限公司. All rights reserved.
//

#ifndef SoapWebServices_SCHeader_h
#define SoapWebServices_SCHeader_h

//#define WebServicesURL @"http://webservice.webxml.com.cn/WebServices/MobileCodeWS.asmx"

#define WebServicesURL @"http://webservice.zzgjj.gov.cn/DataServiceWeb.asmx"

#endif
