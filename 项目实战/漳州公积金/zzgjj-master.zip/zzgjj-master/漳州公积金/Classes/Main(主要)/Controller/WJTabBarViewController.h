//
//  WJTabBarViewController.m
//  漳州公积金
//  自定义底部菜单
//

#import <UIKit/UIKit.h>

@interface WJTabBarViewController : UITabBarController

@end
