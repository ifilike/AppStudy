//
//  WJNavigationController.m
//  漳州公积金
//  自定义导航控制器
//

#import <UIKit/UIKit.h>

@interface WJNavigationController : UINavigationController

@end
