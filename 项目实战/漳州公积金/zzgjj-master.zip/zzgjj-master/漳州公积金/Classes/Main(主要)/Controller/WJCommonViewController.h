//
//  WJCommonViewController.h
//

#import <UIKit/UIKit.h>

@interface WJCommonViewController : UITableViewController
- (NSMutableArray *)groups;
@end