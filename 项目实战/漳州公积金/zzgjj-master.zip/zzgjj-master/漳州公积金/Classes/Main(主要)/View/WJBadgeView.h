//
//  WJBadgeView.h
//  数字提醒控件
//

#import <UIKit/UIKit.h>

@interface WJBadgeView : UIButton
/** 提醒数字 */
@property (nonatomic, copy) NSString *badgeValue;
@end
