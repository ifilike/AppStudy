//
//  WJCalculatorViewController.h
//  漳州公积金
//
//  Created by fengwujie on 16/1/6.
//  Copyright © 2016年 vision-soft. All rights reserved.
//  贷款计算器窗体

#import <UIKit/UIKit.h>

@interface WJCalculatorViewController : UITableViewController

@end
