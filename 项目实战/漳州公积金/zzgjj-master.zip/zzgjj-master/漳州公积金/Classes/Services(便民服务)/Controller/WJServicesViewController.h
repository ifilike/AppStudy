//
//  WJServicesViewController.h
//  漳州公积金
//
//  Created by fengwujie on 16/1/4.
//  Copyright © 2016年 vision-soft. All rights reserved.
//  便民服务窗体

#import <UIKit/UIKit.h>

@interface WJServicesViewController : UIViewController

@end
